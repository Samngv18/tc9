# security-assessment-workflow

A multi-agent pipeline that assesses vendor AI security questionnaire responses and
produces a concise, vendor-shareable PDF report with traceable risk findings and a
confidence score. Orchestration is built on **LangGraph**; the LLM layer uses the
**openai** and **anthropic** SDKs directly (no LangChain wrappers). The pipeline is
wrapped in a **FastMCP** server for deployment on **Azure Container Apps**.

> **Build status: Phase 8 (FastMCP server) complete — all build phases done.**
> Every layer is in place: configuration, HTTP/LLM clients, storage, schemas,
> parsers + translation, framework registry, the five-agent pipeline, the
> LangGraph workflow, the reporting layer, and the FastMCP server with selective
> authentication. The test suite (Phase 9) was built incrementally — 151 tests,
> `mypy --strict` clean, `ruff` clean.

## Requirements

- Python **3.11+**
- [`uv`](https://docs.astral.sh/uv/) for environment and dependency management

## Setup

```bash
cd security-assessment-workflow
uv venv --python 3.12
uv pip install -e ".[dev]"
cp .env.example .env   # then fill in provider credentials as needed
```

`uv` will download an isolated Python 3.12 if one is not already available; the
system Python is left untouched.

## Configuration

All settings come from environment variables (prefix `SAW_`) and an optional
`.env` file. Provider credentials are nested groups using a `__` delimiter, e.g.
`SAW_AZURE_OPENAI__API_KEY`. See `.env.example` for the full list.

| Variable | Purpose |
| --- | --- |
| `SAW_STORAGE_ROOT` | Storage root. Local path in dev; mounted Azure Files share in production. |
| `SAW_ADMIN_TOKEN` | Bearer token for framework-management MCP tools (Phase 8). |
| `SAW_LLM_DEFAULT_PROVIDER` | `azure_openai` \| `langdock` \| `anthropic`. |
| `SAW_LLM_MAX_ATTEMPTS` | Attempts per LLM call before a typed fallback is returned. |
| `SAW_AZURE_OPENAI__*` / `SAW_LANGDOCK__*` / `SAW_ANTHROPIC__*` | Provider credentials. |

## Phase 1 checkpoint

Run the test suite:

```bash
uv run pytest -q
```

Run the smoke check (storage round-trip, retry-to-fallback path, plus one live
call per provider if credentials are configured):

```bash
uv run python scripts/smoke_phase1.py
```

## Architecture notes (Phase 1)

- **LLM layer** (`src/saw/llm/`) — direct-SDK adapters for Azure OpenAI, LangDock
  (OpenAI-compatible), and Anthropic. SDK-level retries are disabled; a single
  full-jitter exponential-backoff loop owns retry behavior. On exhausted retries
  or a non-transient error the client returns a typed `LLMFallbackResponse`
  instead of raising, so the LangGraph workflow never sees an exception.
- **HTTP** (`src/saw/http/`) — the OS trust store is injected via `truststore`;
  every `httpx` client is built with explicit timeouts and connection pooling and
  injected into the SDK clients.
- **Storage** (`src/saw/storage/`) — a `StorageBackend` protocol with a single
  filesystem implementation. The same code path serves a local directory and a
  mounted Azure Files share; only the root differs. No Blob Storage SDK is used.

## MCP server

The pipeline is exposed as a FastMCP server (`saw-mcp`, HTTP transport on port
8000). Authentication is **selective**:

| Endpoint | Auth |
| --- | --- |
| `run_assessment(inputs, supplemental?)` tool | open — no token |
| `list_active_frameworks()` tool | admin bearer token |
| `update_framework(framework_name, artifact_base64, format)` tool | admin bearer token |
| `framework-registry://active` resource | admin bearer token |
| `GET /healthz` (liveness), `GET /readyz` (readiness) | open — no token |

Protected handlers carry a `@require_admin` decorator that validates an
`Authorization: Bearer <token>` header against `SAW_ADMIN_TOKEN` (constant-time
compare; pluggable to JWT / Entra ID later). Auth failures return a generic
MCP error with no information leakage.

Tool inputs cross MCP as JSON: questionnaire and framework files are passed
base64-encoded (`content_base64` / `artifact_base64`). `update_framework`
persists the artifact, extracts controls, commits a new version, and triggers the
registry's event-driven reload before returning.

Run it locally:

```bash
uv run saw-mcp     # serves MCP over HTTP on :8000
```

## Docker & Azure Container Apps

```bash
docker build -t security-assessment-workflow .
docker run -p 8000:8000 --env-file .env \
  -v "$PWD/.saw-storage:/mnt/registry" security-assessment-workflow
```

For **Azure Container Apps**:

- Mount an **Azure Files** volume at `SAW_STORAGE_ROOT` (e.g. `/mnt/registry`) —
  the Dockerfile defaults `SAW_STORAGE_ROOT` to `/mnt/registry`. This gives
  durability across restarts and consistency across replicas with zero
  application code change; no Blob Storage SDK is required.
- If `SAW_STORAGE_ROOT` is unset, relative, or points at ephemeral container
  storage, the app logs a prominent startup warning.
- Set provider credentials (`SAW_AZURE_OPENAI__*` etc.) and `SAW_ADMIN_TOKEN` as
  ACA secrets; set `SAW_LOG_JSON=true` for structured logs.
- Wire the ACA health probes to `GET /healthz` (liveness) and `GET /readyz`
  (readiness — reports ready once the framework registry is seeded and a provider
  is configured).
- The bundled seed frameworks ship as package data, so the registry self-seeds on
  first start; subsequent `update_framework` calls version them in place.

## Project layout

```
src/saw/
├── config.py        # settings + logging bootstrap
├── http/client.py   # truststore + injected httpx clients
├── llm/             # providers, retry, tokens, diagnostics, client, translation
├── schemas/         # Pydantic v2 models (StrictModel base, extra="forbid")
├── parsers/         # XLSX / PDF / supplemental parsers + vendor-name inference
├── prompts/         # pure prompt-builder functions
├── frameworks/      # versioned registry, loader, bundled seed frameworks
├── agents/          # Reader, Completeness & Quality, Assessment, Confidence, Report
├── graph/           # LangGraph workflow + state, per-node snapshot persistence
├── reporting/       # vendor-safe filter, reportlab PDF writer, internal traceability
├── mcp_server/      # FastMCP server, tools, selective bearer-token auth, health
└── storage/         # StorageBackend protocol + filesystem implementation
scripts/smoke_phase1.py … smoke_phase8.py
tests/unit/
```
