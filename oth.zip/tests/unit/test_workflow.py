"""End-to-end LangGraph workflow orchestration."""

from __future__ import annotations

import json
from io import BytesIO
from pathlib import Path

import httpx
import openpyxl

from saw.agents import InputDocument
from saw.frameworks import FrameworkRegistry
from saw.graph import AssessmentWorkflow
from saw.schemas import FinalReport
from saw.storage import FilesystemStorage

_HEADERS = ["No", "Answered_By", "Question", "Answer", "Notes"]
_DIMENSION = {"level": "adequate", "comment": "comment"}


def _questionnaire() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(_HEADERS)
    sheet.append([1, "Al", "Do you encrypt data at rest?", "Yes, AES-256 is used.", ""])
    sheet.append([2, "Bo", "Wie verwalten Sie Zugriff?", "Wir verschluesseln alle Daten.", ""])
    sheet.append([3, "Cy", "Do you have an incident response plan?", "", ""])
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def _route(messages: list) -> str:
    """Stub LLM: route a canned reply by the agent's system prompt."""
    system = messages[0].content
    user = messages[-1].content
    if "profile the context" in system:
        return json.dumps(
            {
                "solution_type": "llm",
                "business_use_case": "AI assistant",
                "pii_handling": "unknown",
                "uses_external_tools": False,
                "model_sourcing": "proprietary",
                "open_source_models_identified": None,
                "rationale": "profiled",
            }
        )
    if "translation engine" in system:
        if "verschl" in user:
            return '{"language": "de", "is_english": false, "english_text": "We encrypt data."}'
        return '{"language": "en", "is_english": true, "english_text": "unchanged"}'
    if "COMPLETENESS" in system:
        return '{"structurally_present": true, "state": "answered", "reasoning": "answered"}'
    if "perform three tasks" in system:
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": False,
                    "category": None,
                    "offending_excerpt": None,
                    "reasoning": "neutral",
                },
                "validation": {"status": "sufficient", "rationale": "ok"},
                "quality": {
                    "clarity": _DIMENSION,
                    "relevance": _DIMENSION,
                    "sufficiency_of_detail": _DIMENSION,
                    "internal_consistency": _DIMENSION,
                    "architectural_relevance": _DIMENSION,
                    "practical_usefulness": _DIMENSION,
                    "overall_judgment": "fine",
                },
            }
        )
    if "security risk analyst" in system:
        return json.dumps(
            {
                "findings": [
                    {
                        "severity": "medium",
                        "risk_observation_internal": "weak input handling per LLM01",
                        "framework_alignment": [
                            {
                                "framework_name": "owasp_llm_top10",
                                "framework_tier": "primary",
                                "control_ids": ["LLM01"],
                                "note": "n",
                            }
                        ],
                        "vendor_safe_risk_observation": "Input validation is partially described.",
                        "vendor_safe_follow_up": "How is input validated before use?",
                    }
                ],
                "contextual_reasoning": "partial coverage",
                "no_material_risk": False,
            }
        )
    if "confidence score" in system:
        return '{"rationale": "Confidence reflects mixed but reasonable evidence."}'
    if "executive summary" in system:
        return '{"executive_summary": "The vendor shows a reasonable security posture overall."}'
    if "consolidate draft follow-up" in system:
        return '{"questions": ["How is input validated before use?"]}'
    return "{}"


def _workflow(llm_factory, tmp_path: Path, responder=_route):
    storage = FilesystemStorage(tmp_path)
    client, _ = llm_factory(responder)
    workflow = AssessmentWorkflow(
        storage=storage, registry=FrameworkRegistry(storage), llm_client=client
    )
    return workflow, storage


def test_workflow_runs_end_to_end(llm_factory, tmp_path: Path) -> None:
    workflow, _ = _workflow(llm_factory, tmp_path)
    final = workflow.run(
        "run-1", [InputDocument(filename="Acme_Questionnaire.xlsx", content=_questionnaire())]
    )
    assert isinstance(final["final_report"], FinalReport)
    assert final["final_report"].vendor_name == "Acme"
    assert len(final["parsed_records"]) == 3
    assert "confidence" in final
    assert final["assessment_results"].all_findings


def test_workflow_persists_a_snapshot_after_every_node(llm_factory, tmp_path: Path) -> None:
    workflow, storage = _workflow(llm_factory, tmp_path)
    workflow.run("run-2", [InputDocument(filename="acme.xlsx", content=_questionnaire())])
    snapshots = storage.list_dir("runs/run-2")
    assert len(snapshots) == 10
    assert snapshots[0].startswith("01_ingest_inputs")
    assert snapshots[-1].startswith("10_generate_report")
    final_snapshot = json.loads(storage.read_text("runs/run-2/10_generate_report.json"))
    assert "final_report" in final_snapshot
    assert "token_summary" in final_snapshot


def test_workflow_report_has_no_framework_references(llm_factory, tmp_path: Path) -> None:
    workflow, _ = _workflow(llm_factory, tmp_path)
    final = workflow.run("run-3", [InputDocument(filename="acme.xlsx", content=_questionnaire())])
    serialized = final["final_report"].model_dump_json()
    assert "LLM01" not in serialized
    assert "owasp" not in serialized.lower()


def test_workflow_completes_even_when_llm_is_unavailable(llm_factory, tmp_path: Path) -> None:
    # constraint #5: report generation always runs, degrading gracefully.
    workflow, _ = _workflow(
        llm_factory, tmp_path, responder=lambda _m: httpx.ConnectError("provider down")
    )
    final = workflow.run("run-4", [InputDocument(filename="acme.xlsx", content=_questionnaire())])
    assert isinstance(final["final_report"], FinalReport)
    assert "Acme" in final["final_report"].executive_summary  # templated fallback
