"""Report brevity enforcement (constraint #8)."""

from __future__ import annotations

from saw.reporting import count_sentences, count_words, truncate_sentences, truncate_words
from saw.reporting.vendor_safe_filter import VendorSafeFilter
from saw.schemas import (
    EXECUTIVE_SUMMARY_MAX_WORDS,
    FOLLOW_UP_MAX_WORDS,
    RISK_OBSERVATION_MAX_SENTENCES,
    FollowUpQuestion,
    FrameworkRegistrySnapshot,
    RiskSeverity,
    TraceabilityRow,
)


def _filter() -> VendorSafeFilter:
    return VendorSafeFilter(FrameworkRegistrySnapshot(frameworks=[]))


# --- counting / truncation helpers --------------------------------------- #


def test_count_words() -> None:
    assert count_words("one two three") == 3
    assert count_words("") == 0


def test_count_sentences() -> None:
    assert count_sentences("One. Two. Three.") == 3
    assert count_sentences("No terminal punctuation") == 1
    assert count_sentences("") == 0


def test_truncate_words() -> None:
    assert count_words(truncate_words("a b c d e", 3)) == 3
    assert truncate_words("short text", 10) == "short text"
    assert count_words(truncate_words(" ".join(["w"] * 300), 200)) <= 200


def test_truncate_sentences() -> None:
    assert count_sentences(truncate_sentences("One. Two. Three. Four.", 2)) <= 2
    assert truncate_sentences("Just one.", 3) == "Just one."


# --- enforcement via the filter ------------------------------------------ #


def test_executive_summary_truncated_to_limit(make_final_report) -> None:
    report = make_final_report(executive_summary=" ".join(["word"] * 320))
    filtered = _filter().filter_report(report)
    assert count_words(filtered.executive_summary) <= EXECUTIVE_SUMMARY_MAX_WORDS


def test_follow_up_questions_truncated_to_limit(make_final_report) -> None:
    report = make_final_report(
        follow_ups=[FollowUpQuestion(number=1, text=" ".join(["how"] * 40) + "?")]
    )
    filtered = _filter().filter_report(report)
    assert count_words(filtered.follow_up_questions[0].text) <= FOLLOW_UP_MAX_WORDS


def test_risk_observation_truncated_to_three_sentences(make_final_report) -> None:
    rows = [
        TraceabilityRow(
            question_number="1",
            question="Question?",
            response_excerpt="excerpt",
            risk_observation="One. Two. Three. Four. Five.",
            follow_up_question="Follow-up?",
            severity=RiskSeverity.low,
        )
    ]
    filtered = _filter().filter_report(make_final_report(rows=rows))
    assert (
        count_sentences(filtered.risk_summary[0].risk_observation)
        <= RISK_OBSERVATION_MAX_SENTENCES
    )


def test_compliant_report_is_not_truncated(make_final_report) -> None:
    report = make_final_report()
    filtered = _filter().filter_report(report)
    assert filtered.executive_summary == report.executive_summary
    assert filtered.follow_up_questions[0].text == report.follow_up_questions[0].text
    assert filtered.risk_summary[0].risk_observation == report.risk_summary[0].risk_observation
