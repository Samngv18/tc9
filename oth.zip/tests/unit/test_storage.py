"""Filesystem storage backend behavior."""

from __future__ import annotations

from pathlib import Path

import pytest

from saw.storage import FilesystemStorage, read_json, write_json
from saw.storage.interface import StorageBackend


def test_filesystem_storage_satisfies_protocol(tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    assert isinstance(storage, StorageBackend)


def test_text_roundtrip_creates_parent_dirs(tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    storage.write_text("runs/r1/state.txt", "hello")
    assert storage.read_text("runs/r1/state.txt") == "hello"
    assert storage.exists("runs/r1/state.txt")
    assert not storage.exists("runs/r1/missing.txt")


def test_bytes_roundtrip(tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    storage.write_bytes("frameworks/owasp/v1.pdf", b"%PDF-1.7 sample")
    assert storage.read_bytes("frameworks/owasp/v1.pdf") == b"%PDF-1.7 sample"


def test_json_helpers_roundtrip(tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    write_json(storage, "active.json", {"active_version": "v2"})
    assert read_json(storage, "active.json") == {"active_version": "v2"}


def test_list_dir_and_delete(tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    storage.write_text("d/a.txt", "a")
    storage.write_text("d/b.txt", "b")
    assert storage.list_dir("d") == ["a.txt", "b.txt"]
    storage.delete("d/a.txt")
    assert storage.list_dir("d") == ["b.txt"]
    storage.delete("d")
    assert storage.list_dir("d") == []


def test_path_traversal_is_rejected(tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    with pytest.raises(ValueError, match="escapes storage root"):
        storage.read_bytes("../../../etc/passwd")
    with pytest.raises(ValueError, match="non-empty"):
        storage.write_text("", "x")
