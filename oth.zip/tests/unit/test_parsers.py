"""Parser behavior: XLSX, PDF, supplemental documents, and vendor-name inference."""

from __future__ import annotations

from io import BytesIO

import openpyxl
import pytest
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Table, TableStyle

from saw.parsers import infer_vendor_name, parse_pdf, parse_supplemental_documents, parse_xlsx

STANDARD_HEADERS = ["No", "Answered_By", "Question", "Answer", "Notes"]
SAMPLE_ROWS = [
    [1, "Alice", "Do you encrypt data at rest?", "Yes, AES-256.", "verified"],
    [2, "Bob", "Do you process PII?", "N/A - we do not process PII.", ""],
]


def _make_xlsx(
    headers: list[str],
    rows: list[list[object]],
    *,
    sheet_title: str = "Responses",
    preamble: int = 0,
) -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = sheet_title
    for _ in range(preamble):
        sheet.append(["report generated for internal use"])
    sheet.append(headers)
    for row in rows:
        sheet.append(row)
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def _make_table_pdf(headers: list[str], rows: list[list[object]]) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    data = [headers] + [[str(c) for c in row] for row in rows]
    table = Table(data)
    table.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.75, colors.black)]))
    doc.build([table])
    return buffer.getvalue()


def _make_low_text_pdf() -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    doc.build([Paragraph(".", getSampleStyleSheet()["Normal"])])
    return buffer.getvalue()


# --- XLSX ----------------------------------------------------------------- #


def test_xlsx_parses_clean_questionnaire() -> None:
    result = parse_xlsx(_make_xlsx(STANDARD_HEADERS, SAMPLE_ROWS), filename="q.xlsx")
    assert len(result.records) == 2
    first = result.records[0]
    assert first.number == "1"
    assert first.answered_by == "Alice"
    assert first.question == "Do you encrypt data at rest?"
    assert first.original_text == "Yes, AES-256."
    assert first.notes == "verified"
    assert first.source_row == 2  # header on row 1, first data row on row 2


def test_xlsx_tolerates_column_reordering() -> None:
    headers = ["Question", "Notes", "Answer", "No", "Answered_By"]
    rows = [["Do you log access?", "n", "Yes, centrally.", 7, "Carol"]]
    result = parse_xlsx(_make_xlsx(headers, rows), filename="q.xlsx")
    assert len(result.records) == 1
    record = result.records[0]
    assert record.number == "7"
    assert record.question == "Do you log access?"
    assert record.original_text == "Yes, centrally."
    assert record.answered_by == "Carol"


def test_xlsx_warns_on_missing_column() -> None:
    headers = ["No", "Question", "Answer"]  # Answered_By and Notes absent
    result = parse_xlsx(_make_xlsx(headers, [[1, "Q?", "A."]]), filename="q.xlsx")
    assert len(result.records) == 1
    joined = " ".join(result.warnings)
    assert "answered_by" in joined
    assert "notes" in joined


def test_xlsx_warns_when_header_not_first_row() -> None:
    result = parse_xlsx(
        _make_xlsx(STANDARD_HEADERS, SAMPLE_ROWS, preamble=2), filename="q.xlsx"
    )
    assert len(result.records) == 2
    assert any("header row" in w for w in result.warnings)


def test_xlsx_with_no_recognizable_table_degrades_gracefully() -> None:
    result = parse_xlsx(_make_xlsx(["alpha", "beta"], [[1, 2]]), filename="q.xlsx")
    assert result.records == []
    assert any("no recognizable" in w for w in result.warnings)


def test_xlsx_flags_row_missing_answer() -> None:
    rows = [[1, "Dave", "Do you patch promptly?", "", ""]]
    result = parse_xlsx(_make_xlsx(STANDARD_HEADERS, rows), filename="q.xlsx")
    assert len(result.records) == 1
    assert any("no response" in w for w in result.records[0].parse_warnings)


def test_xlsx_open_failure_is_a_warning_not_an_exception() -> None:
    result = parse_xlsx(b"this is not a workbook", filename="broken.xlsx")
    assert result.records == []
    assert any("could not open" in w for w in result.warnings)


# --- PDF ------------------------------------------------------------------ #


def test_pdf_parses_table_questionnaire() -> None:
    pdf = _make_table_pdf(STANDARD_HEADERS, SAMPLE_ROWS)
    result = parse_pdf(pdf, filename="q.pdf")
    assert len(result.records) == 2
    assert result.records[0].question == "Do you encrypt data at rest?"
    assert result.records[1].original_text.startswith("N/A")


def test_pdf_warns_on_low_text_yield() -> None:
    result = parse_pdf(_make_low_text_pdf(), filename="scanned.pdf")
    assert any("low text yield" in w for w in result.warnings)


def test_pdf_open_failure_is_a_warning_not_an_exception() -> None:
    result = parse_pdf(b"%PDF-not-really", filename="broken.pdf")
    assert result.records == []
    assert result.warnings


# --- supplemental --------------------------------------------------------- #


def test_supplemental_documents_extract_text() -> None:
    xlsx = _make_xlsx(STANDARD_HEADERS, SAMPLE_ROWS)
    context = parse_supplemental_documents(
        [
            ("architecture.txt", b"Our system runs in an isolated VPC."),
            ("controls.xlsx", xlsx),
            ("notes.docx", b"\x00\x01binary"),
        ]
    )
    assert len(context.documents) == 3
    by_name = {d.filename: d for d in context.documents}
    assert "isolated VPC" in by_name["architecture.txt"].extracted_text
    assert "AES-256" in by_name["controls.xlsx"].extracted_text
    assert by_name["notes.docx"].parse_warnings  # unsupported format reported


# --- vendor name ---------------------------------------------------------- #


@pytest.mark.parametrize(
    ("filename", "expected"),
    [
        ("Acme_Corp_Security_Questionnaire_2024.xlsx", "Acme Corp"),
        ("IBM-ai-assessment.pdf", "IBM"),
        ("globex responses v2.xlsx", "Globex"),
        ("/tmp/uploads/Initech_Vendor_Review.pdf", "Initech"),
        ("security_questionnaire_2024.xlsx", "Vendor"),
    ],
)
def test_infer_vendor_name(filename: str, expected: str) -> None:
    assert infer_vendor_name(filename) == expected
