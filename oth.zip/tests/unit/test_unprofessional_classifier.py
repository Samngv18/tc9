"""Unprofessional-language classifier (Completeness & Quality agent, sub-step b)."""

from __future__ import annotations

import pytest

from saw.agents.completeness_quality import CompletenessQualityAgent
from saw.schemas import (
    CompletenessResult,
    CompletenessState,
    ParsedQuestionResponse,
    ValidationStatus,
)


def _record(text: str) -> ParsedQuestionResponse:
    return ParsedQuestionResponse(number="1", question="Do you log access?", original_text=text)


def _completeness() -> list[CompletenessResult]:
    return [
        CompletenessResult(
            question_number="1",
            structurally_present=True,
            state=CompletenessState.answered,
            reasoning="answered",
        )
    ]


def _agent(llm_factory, responder):
    client, provider = llm_factory(responder)
    return CompletenessQualityAgent(client, run_id="t"), provider


def test_flagged_response_forces_offensive_validation_status(llm_factory, make_quality_reply):
    reply = make_quality_reply(
        flagged=True,
        category="frustration",
        excerpt="this is a dumb question",
        status="partial",
    )
    agent, _ = _agent(llm_factory, lambda _m: reply)
    out = agent.assess_quality([_record("Honestly, this is a dumb question.")], _completeness())
    assert out.unprofessional[0].is_flagged is True
    assert out.unprofessional[0].category == "frustration"
    # the offending phrase is preserved internally, never echoed in the report
    assert out.unprofessional[0].offending_excerpt_internal == "this is a dumb question"
    # validation status is overridden to offensive, regardless of the LLM's status
    assert out.validations[0].status is ValidationStatus.offensive_or_unprofessional
    assert out.validations[0].unprofessional is not None


def test_neutral_response_is_not_flagged(llm_factory, make_quality_reply):
    reply = make_quality_reply(flagged=False, status="not_applicable")
    agent, _ = _agent(llm_factory, lambda _m: reply)
    out = agent.assess_quality(
        [_record("N/A - access logging is not applicable here.")], _completeness()
    )
    assert out.unprofessional[0].is_flagged is False
    assert out.validations[0].status is ValidationStatus.not_applicable
    assert out.validations[0].unprofessional is None


@pytest.mark.parametrize(
    "category", ["sarcasm", "insult", "profanity", "casual_venting", "dismissive"]
)
def test_each_unprofessional_category_is_flagged(llm_factory, make_quality_reply, category):
    reply = make_quality_reply(flagged=True, category=category, excerpt="x")
    agent, _ = _agent(llm_factory, lambda _m: reply)
    out = agent.assess_quality([_record("some response")], _completeness())
    assert out.unprofessional[0].is_flagged is True
    assert out.unprofessional[0].category == category


def test_unknown_category_falls_back_to_other(llm_factory, make_quality_reply):
    reply = make_quality_reply(flagged=True, category="grumpy", excerpt="x")
    agent, _ = _agent(llm_factory, lambda _m: reply)
    out = agent.assess_quality([_record("some response")], _completeness())
    assert out.unprofessional[0].category == "other"
