"""Completeness check (Completeness & Quality agent, sub-step a)."""

from __future__ import annotations

import httpx

from saw.agents.completeness_quality import CompletenessQualityAgent
from saw.schemas import CompletenessState, ParsedQuestionResponse


def _record(text: str, number: str = "1") -> ParsedQuestionResponse:
    return ParsedQuestionResponse(
        number=number, question="Do you encrypt data at rest?", original_text=text
    )


def _agent(llm_factory, responder, **kwargs):
    client, provider = llm_factory(responder, **kwargs)
    return CompletenessQualityAgent(client, run_id="t"), provider


def test_blank_response_is_blank_without_an_llm_call(llm_factory) -> None:
    agent, provider = _agent(llm_factory, lambda _m: "{}")
    results = agent.check_completeness([_record("   ")])
    assert results[0].state is CompletenessState.blank
    assert results[0].structurally_present is False
    assert provider.calls == 0


def test_answered_response_is_complete(llm_factory) -> None:
    reply = '{"structurally_present": true, "state": "answered", "reasoning": "real answer"}'
    agent, _ = _agent(llm_factory, lambda _m: reply)
    results = agent.check_completeness([_record("Yes, AES-256 encryption is used everywhere.")])
    assert results[0].state is CompletenessState.answered
    assert results[0].is_complete is True


def test_na_with_reasoning_is_a_valid_complete_state(llm_factory) -> None:
    reply = (
        '{"structurally_present": true, "state": "not_applicable_with_reasoning", '
        '"reasoning": "vendor processes no PII"}'
    )
    agent, _ = _agent(llm_factory, lambda _m: reply)
    results = agent.check_completeness([_record("N/A - we do not process PII.")])
    assert results[0].state is CompletenessState.not_applicable_with_reasoning
    assert results[0].is_complete is True


def test_bare_placeholder_is_not_complete(llm_factory) -> None:
    reply = '{"structurally_present": true, "state": "placeholder", "reasoning": "filler only"}'
    agent, _ = _agent(llm_factory, lambda _m: reply)
    results = agent.check_completeness([_record("TODO")])
    assert results[0].state is CompletenessState.placeholder
    assert results[0].is_complete is False


def test_completeness_degrades_gracefully(llm_factory) -> None:
    agent, _ = _agent(llm_factory, lambda _m: httpx.ConnectError("provider down"), max_attempts=1)
    results = agent.check_completeness([_record("Some substantive answer text.")])
    assert results[0].state is CompletenessState.answered
    assert "degraded" in results[0].reasoning
