"""PDF report writer."""

from __future__ import annotations

import io

import pdfplumber

from saw.reporting import render_report_pdf
from saw.schemas import RiskSeverity, TraceabilityRow


def test_render_produces_valid_pdf_bytes(make_final_report) -> None:
    pdf = render_report_pdf(make_final_report())
    assert pdf[:4] == b"%PDF"
    assert len(pdf) > 500


def test_pdf_contains_the_expected_sections(make_final_report) -> None:
    pdf = render_report_pdf(make_final_report(vendor_name="Acme"))
    with pdfplumber.open(io.BytesIO(pdf)) as document:
        text = "\n".join(page.extract_text() or "" for page in document.pages)
    assert "Acme" in text
    assert "Executive Summary" in text
    assert "Risk Summary" in text
    assert "Follow-Up Questions" in text
    assert "Appendix" in text


def test_pdf_renders_every_severity(make_final_report) -> None:
    rows = [
        TraceabilityRow(
            question_number=str(index),
            question="Question?",
            response_excerpt="excerpt",
            risk_observation="A risk observation.",
            follow_up_question="Follow-up?",
            severity=severity,
        )
        for index, severity in enumerate(RiskSeverity, start=1)
    ]
    pdf = render_report_pdf(make_final_report(rows=rows))
    assert pdf[:4] == b"%PDF"


def test_pdf_renders_prominent_reliability_notice(make_final_report) -> None:
    report = make_final_report(
        low_confidence=True, notice_text="Confidence is low; treat findings as indicative."
    )
    pdf = render_report_pdf(report)
    with pdfplumber.open(io.BytesIO(pdf)) as document:
        text = "\n".join(page.extract_text() or "" for page in document.pages)
    assert "Reliability notice" in text
