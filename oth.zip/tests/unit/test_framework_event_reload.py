"""The registry reload is event-driven only: no polling, no watcher thread."""

from __future__ import annotations

import json
import threading
from pathlib import Path

from saw.frameworks import FrameworkRegistry
from saw.schemas import SourceFormat
from saw.storage import FilesystemStorage


def _controls(control_id: str) -> bytes:
    return json.dumps([{"control_id": control_id, "title": "t", "description": "d"}]).encode()


def test_update_framework_triggers_a_synchronous_reload(tmp_path: Path) -> None:
    registry = FrameworkRegistry(FilesystemStorage(tmp_path))
    registry.seed_if_empty()
    registry.update_framework("eu_ai_act", _controls("NEW"), SourceFormat.json)
    # the reload already ran inside update_framework, before it returned
    active = {f.name: f for f in registry.snapshot().frameworks}["eu_ai_act"]
    assert active.version == "v2"
    assert [c.control_id for c in active.extracted_controls] == ["NEW"]


def test_registry_does_not_poll_storage(tmp_path: Path) -> None:
    # Two registries share one storage root. The reader must not observe the
    # writer's change until it explicitly reloads — proving reload is event-driven.
    writer = FrameworkRegistry(FilesystemStorage(tmp_path))
    writer.seed_if_empty()

    reader = FrameworkRegistry(FilesystemStorage(tmp_path))
    assert {f.name: f.version for f in reader.snapshot().frameworks}["nist_ai_rmf"] == "v1"

    writer.update_framework("nist_ai_rmf", _controls("P"), SourceFormat.json)

    # the reader has not reloaded, so its snapshot still shows v1 (no polling)
    assert {f.name: f.version for f in reader.snapshot().frameworks}["nist_ai_rmf"] == "v1"

    # an explicit, event-driven reload picks up the committed change
    reader.reload()
    assert {f.name: f.version for f in reader.snapshot().frameworks}["nist_ai_rmf"] == "v2"


def test_no_background_thread_is_spawned(tmp_path: Path) -> None:
    baseline = threading.active_count()
    registry = FrameworkRegistry(FilesystemStorage(tmp_path))
    registry.seed_if_empty()
    registry.update_framework("iso_iec_42001", _controls("T"), SourceFormat.json)
    registry.reload()
    registry.snapshot()
    assert threading.active_count() == baseline
