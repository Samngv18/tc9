"""MCP server liveness and readiness checks."""

from __future__ import annotations

from pathlib import Path

from saw.config import AzureOpenAIConfig, Settings
from saw.frameworks import FrameworkRegistry
from saw.mcp_server.health import liveness, readiness
from saw.storage import FilesystemStorage


def _settings_with_provider() -> Settings:
    return Settings(
        _env_file=None,
        azure_openai=AzureOpenAIConfig(
            endpoint="https://example.openai.azure.com",
            api_key="k",
            deployment="gpt-4o-deployment",
            model_name="gpt-4o",
        ),
    )


def test_liveness_reports_ok() -> None:
    assert liveness() == {"status": "ok"}


def test_readiness_is_ready_when_seeded_and_provider_configured(tmp_path: Path) -> None:
    registry = FrameworkRegistry(FilesystemStorage(tmp_path))
    registry.seed_if_empty()
    ready, detail = readiness(registry, _settings_with_provider())
    assert ready is True
    assert detail["status"] == "ready"
    assert detail["active_frameworks"] == 7


def test_readiness_not_ready_when_registry_is_empty(tmp_path: Path) -> None:
    registry = FrameworkRegistry(FilesystemStorage(tmp_path))  # not seeded
    ready, detail = readiness(registry, _settings_with_provider())
    assert ready is False
    assert detail["registry_loaded"] is False


def test_readiness_not_ready_without_a_configured_provider(tmp_path: Path) -> None:
    registry = FrameworkRegistry(FilesystemStorage(tmp_path))
    registry.seed_if_empty()
    ready, detail = readiness(registry, Settings(_env_file=None))
    assert ready is False
    assert detail["providers_configured"] == []
