"""Context Profiler agent: inferring the assessment context."""

from __future__ import annotations

import httpx

from saw.agents.context import ContextProfiler
from saw.schemas import ModelSourcing, ParsedQuestionResponse, PiiHandling, SolutionType


def _records() -> list[ParsedQuestionResponse]:
    return [
        ParsedQuestionResponse(
            number="1",
            question="What does your solution do?",
            original_text="A classical machine-learning fraud-detection model.",
        )
    ]


def test_context_profile_is_parsed(llm_factory) -> None:
    reply = (
        '{"solution_type": "ml_dl", "business_use_case": "fraud detection", '
        '"pii_handling": "no_pii", "uses_external_tools": false, '
        '"model_sourcing": "proprietary", "open_source_models_identified": null, '
        '"rationale": "classical ML model"}'
    )
    client, _ = llm_factory(lambda _m: reply)
    context = ContextProfiler(client, run_id="t").profile(_records())
    assert context.solution_type is SolutionType.ml_dl
    assert context.pii_handling is PiiHandling.no_pii
    assert context.model_sourcing is ModelSourcing.proprietary
    assert context.business_use_case == "fraud detection"


def test_unknown_enum_values_fall_back(llm_factory) -> None:
    reply = (
        '{"solution_type": "quantum", "pii_handling": "maybe", '
        '"model_sourcing": "???", "uses_external_tools": true, '
        '"open_source_models_identified": false, "rationale": "r"}'
    )
    client, _ = llm_factory(lambda _m: reply)
    context = ContextProfiler(client, run_id="t").profile(_records())
    assert context.solution_type is SolutionType.unknown
    assert context.pii_handling is PiiHandling.unknown
    assert context.model_sourcing is ModelSourcing.unknown
    assert context.uses_external_tools is True
    assert context.open_source_models_identified is False


def test_context_profiling_degrades_gracefully(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: httpx.ConnectError("down"), max_attempts=1)
    context = ContextProfiler(client, run_id="t").profile(_records())
    assert context.solution_type is SolutionType.unknown
    assert context.model_sourcing is ModelSourcing.unknown
