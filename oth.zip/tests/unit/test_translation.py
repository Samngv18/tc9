"""Language detection and translation behavior, with a stubbed LLM provider."""

from __future__ import annotations

import httpx

from saw.config import Settings
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.llm.translation import Translator
from saw.schemas import ParsedQuestionResponse

GERMAN = "Wir verschlüsseln alle Daten mit AES-256."
ENGLISH = "We encrypt all data at rest."


class CannedProvider:
    """Stub provider returning canned JSON keyed by a substring of the prompt."""

    name = "azure_openai"
    model = "fake-translate"

    def __init__(
        self,
        mapping: dict[str, str] | None = None,
        *,
        default: str = '{"language": "en", "is_english": true, "english_text": "ok"}',
        fail: bool = False,
    ) -> None:
        self._mapping = mapping or {}
        self._default = default
        self._fail = fail
        self.calls = 0

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        self.calls += 1
        if self._fail:
            raise httpx.ConnectError("provider unavailable")
        prompt = messages[-1].content
        content = self._default
        for needle, reply in self._mapping.items():
            if needle in prompt:
                content = reply
                break
        return RawCompletion(
            model=self.model, content=content, tokens_in=5, tokens_out=5, finish_reason="stop"
        )


def _translator(provider: CannedProvider, *, max_attempts: int = 3) -> Translator:
    settings = Settings(
        _env_file=None,
        llm_default_provider="azure_openai",
        llm_max_attempts=max_attempts,
        llm_base_delay_seconds=0.0,
        llm_max_delay_seconds=0.0,
    )
    client = LLMClient(
        settings,
        http_client=None,
        providers={"azure_openai": provider},
        sleep=lambda _: None,
    )
    return Translator(client, run_id="test-run")


def _response(text: str, number: str = "1") -> ParsedQuestionResponse:
    return ParsedQuestionResponse(number=number, question="Question?", original_text=text)


def test_english_response_is_not_translated() -> None:
    provider = CannedProvider(
        {ENGLISH: '{"language": "en", "is_english": true, "english_text": "ok"}'}
    )
    out = _translator(provider).translate_response(_response(ENGLISH))
    assert out.original_language == "en"
    assert out.translated_text is None
    assert out.is_translated is False
    assert out.assessment_text == ENGLISH


def test_non_english_response_is_translated() -> None:
    provider = CannedProvider(
        {"verschlüsseln": '{"language": "de", "is_english": false, '
         '"english_text": "We encrypt all data with AES-256."}'}
    )
    out = _translator(provider).translate_response(_response(GERMAN))
    assert out.original_language == "de"
    assert out.original_text == GERMAN  # original preserved
    assert out.is_translated is True
    assert out.assessment_text == "We encrypt all data with AES-256."


def test_translation_is_cached_within_a_run() -> None:
    provider = CannedProvider(
        {"verschlüsseln": '{"language": "de", "is_english": false, '
         '"english_text": "We encrypt all data."}'}
    )
    translator = _translator(provider)
    translator.translate_all([_response(GERMAN, "1"), _response(GERMAN, "2")])
    assert provider.calls == 1  # identical text -> one call


def test_obvious_english_token_skips_the_llm() -> None:
    provider = CannedProvider()
    out = _translator(provider).translate_response(_response("N/A"))
    assert provider.calls == 0
    assert out.original_language == "en"
    assert out.translated_text is None


def test_empty_response_needs_no_call() -> None:
    provider = CannedProvider()
    out = _translator(provider).translate_response(_response(""))
    assert provider.calls == 0
    assert out.original_language == "und"


def test_provider_fallback_degrades_gracefully() -> None:
    provider = CannedProvider(fail=True)
    out = _translator(provider, max_attempts=2).translate_response(_response(GERMAN))
    assert out.original_language == "und"
    assert out.translated_text is None
    assert out.original_text == GERMAN  # original preserved
    assert any("could not be determined" in w for w in out.parse_warnings)


def test_unparseable_reply_degrades_gracefully() -> None:
    provider = CannedProvider(default="I am sorry, I cannot do that.")
    out = _translator(provider).translate_response(_response(ENGLISH))
    assert out.original_language == "und"
    assert out.translated_text is None


def test_json_reply_inside_code_fence_is_parsed() -> None:
    fenced = '```json\n{"language": "fr", "is_english": false, ' \
             '"english_text": "We encrypt data."}\n```'
    provider = CannedProvider({"chiffrons": fenced})
    out = _translator(provider).translate_response(_response("Nous chiffrons les données."))
    assert out.original_language == "fr"
    assert out.assessment_text == "We encrypt data."
