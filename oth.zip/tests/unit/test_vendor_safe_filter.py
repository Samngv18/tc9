"""Vendor-safe filter: framework-reference stripping and zero leakage."""

from __future__ import annotations

import io

import pdfplumber

from saw.reporting import VendorSafeFilter, render_report_pdf
from saw.schemas import (
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    RiskSeverity,
    SecurityFramework,
    SourceFormat,
    TraceabilityRow,
)

# Tokens that must never appear in the vendor-facing report.
_BANNED = (
    "OWASP",
    "MITRE",
    "ATLAS",
    "NIST",
    "LLM01",
    "AML.T0051",
    "INT-SEC-01",
    "internal_company_standards",
    "ISO/IEC 42001",
    "EU AI Act",
)


def _snapshot() -> FrameworkRegistrySnapshot:
    internal = SecurityFramework(
        name="internal_company_standards",
        tier=FrameworkTier.primary,
        visibility=FrameworkVisibility.internal,
        version="v1",
        source_artifact_hash="h",
        source_format=SourceFormat.json,
        extracted_controls=[FrameworkControl(control_id="INT-SEC-01", title="t", description="d")],
    )
    public = SecurityFramework(
        name="owasp_llm_top10",
        tier=FrameworkTier.primary,
        visibility=FrameworkVisibility.public,
        version="v1",
        source_artifact_hash="h",
        source_format=SourceFormat.json,
        extracted_controls=[FrameworkControl(control_id="LLM01", title="t", description="d")],
    )
    return FrameworkRegistrySnapshot(frameworks=[internal, public])


def _leaky_rows() -> list[TraceabilityRow]:
    return [
        TraceabilityRow(
            question_number="1",
            question="How do you address OWASP LLM01 risks?",
            response_excerpt="We follow MITRE ATLAS AML.T0051 guidance.",
            risk_observation=(
                "Practices fall short of the NIST AI RMF and internal_company_standards "
                "INT-SEC-01."
            ),
            follow_up_question="How is input validated per ISO/IEC 42001 and the EU AI Act?",
            severity=RiskSeverity.high,
        )
    ]


def test_filter_strips_all_framework_references(make_final_report) -> None:
    report = make_final_report(
        executive_summary="This aligns with OWASP, MITRE ATLAS, and the NIST AI RMF.",
        rows=_leaky_rows(),
    )
    filtered = VendorSafeFilter(_snapshot()).filter_report(report)
    blob = filtered.model_dump_json()
    for token in _BANNED:
        assert token not in blob


def test_filtered_report_pdf_has_zero_framework_references(make_final_report) -> None:
    report = make_final_report(
        executive_summary="Posture relative to OWASP LLM01 and MITRE ATLAS is weak.",
        rows=_leaky_rows(),
    )
    filtered = VendorSafeFilter(_snapshot()).filter_report(report)
    pdf = render_report_pdf(filtered)
    assert pdf[:4] == b"%PDF"
    with pdfplumber.open(io.BytesIO(pdf)) as document:
        text = "\n".join(page.extract_text() or "" for page in document.pages)
    for token in _BANNED:
        assert token not in text


def test_clean_report_passes_through_unchanged(make_final_report) -> None:
    report = make_final_report(executive_summary="The vendor maintains a sound posture.")
    filtered = VendorSafeFilter(_snapshot()).filter_report(report)
    assert filtered.executive_summary == "The vendor maintains a sound posture."


def test_offensive_phrases_are_stripped(make_final_report) -> None:
    rows = [
        TraceabilityRow(
            question_number="1",
            question="Question?",
            response_excerpt="this is a dumb question and we will not answer it",
            risk_observation="The response was not constructive.",
            follow_up_question="Can you provide a substantive answer?",
            severity=RiskSeverity.low,
        )
    ]
    report = make_final_report(rows=rows)
    filtered = VendorSafeFilter(_snapshot()).filter_report(
        report, offensive_phrases=["this is a dumb question"]
    )
    assert "dumb question" not in filtered.model_dump_json()


def test_llm_scrub_runs_only_when_a_leak_is_found(llm_factory, make_final_report) -> None:
    client, provider = llm_factory(lambda _m: '{"text": "Input handling is weak."}')
    report = make_final_report(
        executive_summary="Weak input handling per OWASP LLM01.", rows=_leaky_rows()
    )
    filtered = VendorSafeFilter(_snapshot(), llm_client=client).filter_report(report)
    assert provider.calls > 0  # the scrub pass was invoked on the leak
    assert "OWASP" not in filtered.model_dump_json()


def test_find_banned_underpins_the_assertion_pass() -> None:
    vsf = VendorSafeFilter(_snapshot())
    assert vsf._find_banned("this relates to LLM01")
    assert not vsf._find_banned("a perfectly clean sentence")
