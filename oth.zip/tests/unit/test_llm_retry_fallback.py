"""Retry, backoff, and typed-fallback behavior of the LLM client."""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from saw.config import Settings
from saw.llm.client import ChatMessage, LLMClient, LLMFallbackResponse, LLMResponse
from saw.llm.diagnostics import RunDiagnostics
from saw.llm.providers import RawCompletion
from saw.llm.retry import RetryPolicy, compute_delay, is_retryable

MESSAGES = [ChatMessage(role="user", content="assess this vendor response")]


class FlakyProvider:
    """Test double: raises for the first ``fail_times`` calls, then succeeds."""

    name = "fake"
    model = "fake-model-1"

    def __init__(self, fail_times: int, exc_factory: Callable[[], BaseException]) -> None:
        self._fail_times = fail_times
        self._exc_factory = exc_factory
        self.calls = 0

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        self.calls += 1
        if self.calls <= self._fail_times:
            raise self._exc_factory()
        return RawCompletion(
            model=self.model,
            content="assessment ok",
            tokens_in=42,
            tokens_out=17,
            finish_reason="stop",
        )


def _settings(max_attempts: int = 4) -> Settings:
    # Zero delay bounds keep compute_delay at 0.0 so the suite never sleeps.
    return Settings(
        _env_file=None,
        llm_default_provider="azure_openai",
        llm_max_attempts=max_attempts,
        llm_base_delay_seconds=0.0,
        llm_max_delay_seconds=0.0,
    )


def _client(provider: FlakyProvider, max_attempts: int = 4) -> LLMClient:
    return LLMClient(
        _settings(max_attempts),
        http_client=None,
        providers={"azure_openai": provider},
        sleep=lambda _: None,
    )


def _timeout() -> BaseException:
    return httpx.ConnectTimeout("simulated network timeout")


# --- retry policy --------------------------------------------------------- #


def test_compute_delay_stays_within_bounds() -> None:
    policy = RetryPolicy(max_attempts=5, base_delay=0.5, max_delay=10.0)
    for attempt in range(6):
        delay = compute_delay(attempt, policy)
        ceiling = min(10.0, 0.5 * 2**attempt)
        assert 0.0 <= delay <= ceiling


def test_is_retryable_classification() -> None:
    assert is_retryable(httpx.ConnectTimeout("x"))
    assert is_retryable(httpx.ConnectError("x"))
    assert not is_retryable(ValueError("malformed schema"))


# --- client retry / fallback --------------------------------------------- #


def test_retries_transient_failure_then_succeeds() -> None:
    provider = FlakyProvider(fail_times=2, exc_factory=_timeout)
    result = _client(provider).complete(MESSAGES, run_id="r1", node="assess")
    assert isinstance(result, LLMResponse)
    assert result.attempts == 3
    assert provider.calls == 3
    assert result.content == "assessment ok"
    assert result.tokens_in == 42


def test_exhausting_retries_returns_typed_fallback() -> None:
    provider = FlakyProvider(fail_times=99, exc_factory=_timeout)
    result = _client(provider, max_attempts=4).complete(MESSAGES, run_id="r2")
    assert isinstance(result, LLMFallbackResponse)
    assert result.is_fallback is True
    assert result.attempts == 4
    assert provider.calls == 4
    assert result.reason == "provider_unavailable"
    assert "ConnectTimeout" in result.last_error


def test_non_retryable_error_short_circuits_to_fallback() -> None:
    provider = FlakyProvider(fail_times=99, exc_factory=lambda: ValueError("schema error"))
    result = _client(provider, max_attempts=4).complete(MESSAGES, run_id="r3")
    assert isinstance(result, LLMFallbackResponse)
    assert result.attempts == 1  # a non-transient error is not retried
    assert provider.calls == 1


def test_fallback_is_returned_never_raised() -> None:
    provider = FlakyProvider(fail_times=99, exc_factory=_timeout)
    result = _client(provider).complete(MESSAGES)  # must not raise
    assert result.is_fallback is True


def test_diagnostics_record_success_and_fallback() -> None:
    diag = RunDiagnostics(run_id="r4")
    ok = _client(FlakyProvider(0, _timeout)).complete(
        MESSAGES, run_id="r4", node="ok", diagnostics=diag
    )
    fb = _client(FlakyProvider(99, _timeout), max_attempts=2).complete(
        MESSAGES, run_id="r4", node="fb", diagnostics=diag
    )
    assert isinstance(ok, LLMResponse)
    assert isinstance(fb, LLMFallbackResponse)
    summary = diag.summary()
    assert summary.calls == 2
    assert summary.successful_calls == 1
    assert summary.fallback_calls == 1
    assert summary.total_tokens_in == 42


def test_selecting_unconfigured_provider_raises() -> None:
    client = LLMClient(
        _settings(),
        http_client=None,
        providers={"azure_openai": FlakyProvider(0, _timeout)},
    )
    with pytest.raises(ValueError, match="not configured"):
        client.complete(MESSAGES, provider="anthropic")
