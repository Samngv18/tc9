"""Report agent: vendor-safe assembly of the FinalReport."""

from __future__ import annotations

import json

import httpx

from saw.agents.report import ReportAgent
from saw.schemas import (
    AssessmentResult,
    ConfidenceFactors,
    ConfidenceScore,
    FactorAssessment,
    FrameworkAlignment,
    LanguageSummary,
    ParsedQuestionResponse,
    ResponseAssessment,
    RiskFinding,
    RiskSeverity,
    ValidationResult,
    ValidationStatus,
)

# Internal-only finding text deliberately mentions a framework and a control id.
_INTERNAL_TEXT = "aligns with control LLM01 of the OWASP framework"


def _confidence(score: float = 0.9) -> ConfidenceScore:
    factors = ConfidenceFactors(
        parse_completeness=FactorAssessment.strong,
        response_quality=FactorAssessment.strong,
        internal_consistency=FactorAssessment.strong,
        framework_coverage=FactorAssessment.strong,
        unprofessional_content_present=False,
        translated_content_present=False,
    )
    return ConfidenceScore(score=score, rationale="rationale", factors=factors)


def _assessment() -> AssessmentResult:
    finding = RiskFinding(
        question_number="1",
        severity=RiskSeverity.high,
        risk_observation_internal=_INTERNAL_TEXT,
        framework_alignment_internal=[
            FrameworkAlignment(
                framework_name="owasp_llm_top10",
                framework_tier="primary",
                control_ids=["LLM01"],
            )
        ],
        original_response_excerpt="raw vendor response text",
        risk_observation_vendor_safe="User input is not validated before use.",
        vendor_safe_follow_up="How is user input validated?",
    )
    return AssessmentResult(
        run_id="t",
        response_assessments=[
            ResponseAssessment(
                question_number="1", findings=[finding], contextual_reasoning="assessed"
            )
        ],
    )


def _records() -> list[ParsedQuestionResponse]:
    return [
        ParsedQuestionResponse(
            number="1", question="How do you handle input?", original_text="We validate some input."
        )
    ]


def _responder(_messages: object) -> str:
    return json.dumps(
        {
            "executive_summary": "A concise, vendor-safe summary of the security posture.",
            "questions": ["How is user input validated?"],
        }
    )


def test_report_includes_every_question_even_without_findings(llm_factory) -> None:
    client, _ = llm_factory(_responder)
    records = [
        ParsedQuestionResponse(
            number="1", question="How do you handle input?", original_text="We validate input."
        ),
        ParsedQuestionResponse(
            number="2", question="Do you encrypt data?", original_text="Yes, AES-256 at rest."
        ),
    ]
    assessment = AssessmentResult(
        run_id="t",
        response_assessments=[
            _assessment().response_assessments[0],  # question 1 carries a finding
            ResponseAssessment(
                question_number="2",
                findings=[],
                contextual_reasoning="adequately addressed",
                no_material_risk=True,
            ),
        ],
    )
    report = ReportAgent(client, run_id="t").build(
        vendor_name="Acme",
        records=records,
        validations=[],
        assessment=assessment,
        confidence=_confidence(),
        parse_warnings=[],
        language_summary=LanguageSummary(total_responses=2, translated_responses=0),
    )
    # every question appears in the summary, including the one with no finding
    assert [row.question_number for row in report.risk_summary] == ["1", "2"]
    no_risk_row = report.risk_summary[1]
    assert "No material security risk" in no_risk_row.risk_observation
    assert no_risk_row.severity is RiskSeverity.informational
    assert no_risk_row.follow_up_question == ""


def test_report_uses_only_vendor_safe_fields(llm_factory) -> None:
    client, _ = llm_factory(_responder)
    report = ReportAgent(client, run_id="t").build(
        vendor_name="Acme",
        records=_records(),
        validations=[
            ValidationResult(question_number="1", status=ValidationStatus.partial, rationale="r")
        ],
        assessment=_assessment(),
        confidence=_confidence(),
        parse_warnings=[],
        language_summary=LanguageSummary(total_responses=1, translated_responses=0),
    )
    assert len(report.risk_summary) == 1
    assert report.risk_summary[0].risk_observation == "User input is not validated before use."
    # internal framework references never reach the assembled report
    serialized = report.model_dump_json()
    assert "LLM01" not in serialized
    assert "OWASP" not in serialized


def test_report_follow_ups_are_numbered(llm_factory) -> None:
    client, _ = llm_factory(_responder)
    report = ReportAgent(client, run_id="t").build(
        vendor_name="Acme",
        records=_records(),
        validations=[],
        assessment=_assessment(),
        confidence=_confidence(),
        parse_warnings=[],
        language_summary=LanguageSummary(total_responses=1, translated_responses=0),
    )
    assert report.follow_up_questions[0].number == 1
    assert report.follow_up_questions[0].text == "How is user input validated?"


def test_reliability_notice_is_prominent_on_low_confidence_and_unprofessional(llm_factory) -> None:
    client, _ = llm_factory(_responder)
    report = ReportAgent(client, run_id="t").build(
        vendor_name="Acme",
        records=_records(),
        validations=[
            ValidationResult(
                question_number="1",
                status=ValidationStatus.offensive_or_unprofessional,
                rationale="r",
            )
        ],
        assessment=_assessment(),
        confidence=_confidence(score=0.2),
        parse_warnings=[],
        language_summary=LanguageSummary(total_responses=1, translated_responses=0),
    )
    assert report.reliability_notice.is_prominent is True
    assert report.reliability_notice.low_confidence is True
    assert report.reliability_notice.has_unprofessional_responses is True


def test_report_degrades_to_a_templated_summary(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: httpx.ConnectError("down"), max_attempts=1)
    report = ReportAgent(client, run_id="t").build(
        vendor_name="Acme",
        records=_records(),
        validations=[],
        assessment=_assessment(),
        confidence=_confidence(),
        parse_warnings=[],
        language_summary=LanguageSummary(total_responses=1, translated_responses=0),
    )
    assert "Acme" in report.executive_summary
    # follow-ups fall back to the per-finding drafts when consolidation degrades
    assert report.follow_up_questions[0].text == "How is user input validated?"
