"""Assessment agent: framework-aware risk findings."""

from __future__ import annotations

import json

import httpx

from saw.agents.assessment import AssessmentAgent
from saw.schemas import (
    AssessmentContext,
    DocumentFormat,
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    ParsedQuestionResponse,
    PiiHandling,
    RiskSeverity,
    SecurityFramework,
    SolutionType,
    SourceFormat,
    SupplementalContext,
    SupplementalDocument,
)

_FINDING_JSON = json.dumps(
    {
        "findings": [
            {
                "severity": "high",
                "risk_observation_internal": "weak input handling relative to LLM01",
                "framework_alignment": [
                    {
                        "framework_name": "owasp_llm_top10",
                        "framework_tier": "primary",
                        "control_ids": ["LLM01"],
                        "note": "input validation",
                    }
                ],
                "vendor_safe_risk_observation": "User input is not consistently validated.",
                "vendor_safe_follow_up": "How is user input validated before use?",
            }
        ],
        "contextual_reasoning": "input handling is only partially addressed",
        "no_material_risk": False,
    }
)


def _snapshot() -> FrameworkRegistrySnapshot:
    framework = SecurityFramework(
        name="owasp_llm_top10",
        tier=FrameworkTier.primary,
        visibility=FrameworkVisibility.public,
        version="v1",
        source_artifact_hash="hash",
        source_format=SourceFormat.json,
        extracted_controls=[
            FrameworkControl(control_id="LLM01", title="Prompt Injection", description="desc")
        ],
    )
    return FrameworkRegistrySnapshot(frameworks=[framework])


def _record(
    text: str = "We sanitize all model inputs.", number: str = "1"
) -> ParsedQuestionResponse:
    return ParsedQuestionResponse(
        number=number, question="How do you handle inputs?", original_text=text
    )


def test_assessment_produces_findings(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: _FINDING_JSON)
    result = AssessmentAgent(client, run_id="t").assess([_record()], _snapshot())
    assert len(result.response_assessments) == 1
    finding = result.all_findings[0]
    assert finding.severity is RiskSeverity.high
    assert finding.risk_observation_vendor_safe.startswith("User input")
    assert finding.framework_alignment_internal[0].control_ids == ["LLM01"]
    assert finding.original_response_excerpt  # excerpt populated by the agent


def test_blank_response_yields_a_deterministic_finding(llm_factory) -> None:
    client, provider = llm_factory(lambda _m: _FINDING_JSON)
    result = AssessmentAgent(client, run_id="t").assess([_record("   ")], _snapshot())
    assert provider.calls == 0  # no LLM call for a blank response
    assert "did not provide a response" in result.all_findings[0].risk_observation_vendor_safe


def test_assessment_degrades_gracefully(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: httpx.ConnectError("down"), max_attempts=1)
    result = AssessmentAgent(client, run_id="t").assess([_record()], _snapshot())
    assert result.response_assessments[0].findings == []
    assert "degraded" in result.response_assessments[0].contextual_reasoning


def test_supporting_documents_reach_the_assessment_prompt(llm_factory) -> None:
    captured: dict[str, str] = {}

    def responder(messages: list) -> str:
        if "security risk analyst" in messages[0].content:
            captured["prompt"] = messages[-1].content
        return _FINDING_JSON

    client, _ = llm_factory(responder)
    supplemental = SupplementalContext(
        documents=[
            SupplementalDocument(
                filename="dpa.md",
                fmt=DocumentFormat.txt,
                extracted_text="The DPA confirms data is encrypted with AES-256.",
            )
        ]
    )
    AssessmentAgent(client, run_id="t").assess([_record()], _snapshot(), supplemental)
    assert "The DPA confirms data is encrypted with AES-256." in captured["prompt"]


def test_assessment_context_reaches_the_prompt(llm_factory) -> None:
    captured: dict[str, str] = {}

    def responder(messages: list) -> str:
        if "security risk analyst" in messages[0].content:
            captured["user"] = messages[-1].content
            captured["system"] = messages[0].content
        return _FINDING_JSON

    client, _ = llm_factory(responder)
    context = AssessmentContext(
        solution_type=SolutionType.ml_dl, pii_handling=PiiHandling.no_pii
    )
    AssessmentAgent(client, run_id="t").assess([_record()], _snapshot(), None, context)
    # the context is carried into the user prompt
    assert "ml_dl" in captured["user"]
    assert "no_pii" in captured["user"]
    # the calibration rules (incl. the open-source provenance rule) are in the system prompt
    assert "open-source" in captured["system"]
