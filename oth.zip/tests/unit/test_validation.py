"""Context-aware validation (Completeness & Quality agent, sub-step c)."""

from __future__ import annotations

import httpx
import pytest

from saw.agents.completeness_quality import CompletenessQualityAgent
from saw.schemas import (
    CompletenessResult,
    CompletenessState,
    ParsedQuestionResponse,
    ValidationStatus,
)


def _record(text: str = "An answer.") -> ParsedQuestionResponse:
    return ParsedQuestionResponse(number="1", question="Question?", original_text=text)


def _completeness() -> list[CompletenessResult]:
    return [
        CompletenessResult(
            question_number="1",
            structurally_present=True,
            state=CompletenessState.answered,
            reasoning="answered",
        )
    ]


def _agent(llm_factory, responder, **kwargs):
    client, provider = llm_factory(responder, **kwargs)
    return CompletenessQualityAgent(client, run_id="t"), provider


@pytest.mark.parametrize(
    "status",
    ["complete", "sufficient", "partial", "incomplete", "unclear", "not_applicable", "pending"],
)
def test_validation_status_is_passed_through(llm_factory, make_quality_reply, status):
    agent, _ = _agent(llm_factory, lambda _m: make_quality_reply(status=status))
    out = agent.assess_quality([_record()], _completeness())
    assert out.validations[0].status is ValidationStatus(status)


def test_unknown_status_falls_back_to_pending(llm_factory, make_quality_reply):
    agent, _ = _agent(llm_factory, lambda _m: make_quality_reply(status="bizarre"))
    out = agent.assess_quality([_record()], _completeness())
    assert out.validations[0].status is ValidationStatus.pending


def test_validation_degrades_to_pending(llm_factory):
    agent, _ = _agent(llm_factory, lambda _m: httpx.ConnectError("down"), max_attempts=1)
    out = agent.assess_quality([_record()], _completeness())
    assert out.validations[0].status is ValidationStatus.pending
    assert "degraded" in out.validations[0].rationale
