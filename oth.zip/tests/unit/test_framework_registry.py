"""Framework registry: seeding, versioned uploads, and PDF/JSON ingestion."""

from __future__ import annotations

import json
from io import BytesIO
from pathlib import Path

import pytest
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate

from saw.config import Settings
from saw.frameworks import CATALOG_FRAMEWORK_NAMES, FrameworkLoadError, FrameworkRegistry
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.schemas import FrameworkTier, FrameworkVisibility, SourceFormat
from saw.storage import FilesystemStorage


def _registry(tmp_path: Path, *, llm_client: LLMClient | None = None) -> FrameworkRegistry:
    return FrameworkRegistry(FilesystemStorage(tmp_path), llm_client=llm_client)


def _controls_json(*control_ids: str) -> bytes:
    return json.dumps(
        [
            {"control_id": cid, "title": f"Title {cid}", "description": "desc"}
            for cid in control_ids
        ]
    ).encode()


class _StubProvider:
    """Provider stub returning a fixed completion (used for PDF extraction)."""

    name = "azure_openai"
    model = "stub"

    def __init__(self, content: str) -> None:
        self._content = content
        self.calls = 0

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        self.calls += 1
        return RawCompletion(
            model="stub", content=self._content, tokens_in=10, tokens_out=10, finish_reason="stop"
        )


def _llm_client(content: str) -> LLMClient:
    settings = Settings(
        _env_file=None,
        llm_default_provider="azure_openai",
        llm_max_attempts=1,
        llm_base_delay_seconds=0.0,
        llm_max_delay_seconds=0.0,
    )
    return LLMClient(
        settings,
        http_client=None,
        providers={"azure_openai": _StubProvider(content)},
        sleep=lambda _: None,
    )


def _make_pdf(text: str) -> bytes:
    buffer = BytesIO()
    SimpleDocTemplate(buffer, pagesize=letter).build(
        [Paragraph(text, getSampleStyleSheet()["Normal"])]
    )
    return buffer.getvalue()


# --- seeding -------------------------------------------------------------- #


def test_seed_populates_all_catalog_frameworks(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    seeded = registry.seed_if_empty()
    assert set(seeded) == set(CATALOG_FRAMEWORK_NAMES)
    frameworks = registry.snapshot().frameworks
    assert len(frameworks) == 7
    assert all(f.version == "v1" and f.extracted_controls for f in frameworks)


def test_seeding_is_idempotent(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    assert registry.seed_if_empty() == []  # nothing re-seeded
    assert all(f.version == "v1" for f in registry.snapshot().frameworks)


def test_seed_assigns_catalog_tier_and_visibility(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    by_name = {f.name: f for f in registry.snapshot().frameworks}
    assert by_name["owasp_llm_top10"].tier is FrameworkTier.primary
    assert by_name["nist_ai_rmf"].tier is FrameworkTier.secondary
    assert by_name["internal_company_standards"].visibility is FrameworkVisibility.internal


def test_snapshot_splits_primary_and_secondary(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    snapshot = registry.snapshot()
    assert {f.name for f in snapshot.primary} == {
        "owasp_llm_top10",
        "owasp_agentic_top10",
        "mitre_atlas",
        "internal_company_standards",
    }
    assert len(snapshot.secondary) == 3


# --- JSON uploads --------------------------------------------------------- #


def test_json_upload_bumps_version_and_swaps_active(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    framework = registry.update_framework(
        "owasp_llm_top10", _controls_json("LLM01", "LLM-NEW"), SourceFormat.json
    )
    assert framework.version == "v2"
    active = {f.name: f for f in registry.snapshot().frameworks}["owasp_llm_top10"]
    assert active.version == "v2"
    assert {c.control_id for c in active.extracted_controls} == {"LLM01", "LLM-NEW"}


def test_repeated_uploads_increment_the_version(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    assert registry.update_framework("mitre_atlas", _controls_json("A"), "json").version == "v2"
    assert registry.update_framework("mitre_atlas", _controls_json("B"), "json").version == "v3"


def test_tier_and_visibility_preserved_across_updates(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    updated = registry.update_framework(
        "internal_company_standards", _controls_json("X"), SourceFormat.json
    )
    assert updated.version == "v2"
    assert updated.tier is FrameworkTier.primary
    assert updated.visibility is FrameworkVisibility.internal


def test_invalid_json_is_rejected_and_commits_nothing(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    registry.seed_if_empty()
    with pytest.raises(FrameworkLoadError):
        registry.update_framework("owasp_llm_top10", b"{not valid json", SourceFormat.json)
    # the active version is unchanged
    active = {f.name: f for f in registry.snapshot().frameworks}["owasp_llm_top10"]
    assert active.version == "v1"


# --- PDF uploads ---------------------------------------------------------- #


def test_pdf_upload_extracts_controls_via_llm(tmp_path: Path) -> None:
    extracted = json.dumps(
        {"controls": [{"control_id": "AML.T9999", "title": "Test", "description": "d"}]}
    )
    registry = _registry(tmp_path, llm_client=_llm_client(extracted))
    framework = registry.update_framework(
        "mitre_atlas", _make_pdf("ATLAS framework. Technique AML.T9999."), SourceFormat.pdf
    )
    assert framework.version == "v1"
    assert framework.source_format is SourceFormat.pdf
    assert framework.extracted_controls[0].control_id == "AML.T9999"


def test_pdf_upload_without_llm_client_fails(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    with pytest.raises(FrameworkLoadError):
        registry.update_framework("mitre_atlas", _make_pdf("text"), SourceFormat.pdf)


def test_unknown_framework_name_is_rejected(tmp_path: Path) -> None:
    registry = _registry(tmp_path)
    with pytest.raises(FrameworkLoadError):
        registry.update_framework("not_a_real_framework", _controls_json("A"), SourceFormat.json)
