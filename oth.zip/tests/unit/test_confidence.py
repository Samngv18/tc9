"""Confidence agent: deterministic scoring and graceful rationale degradation."""

from __future__ import annotations

import httpx

from saw.agents.confidence import ConfidenceAgent
from saw.schemas import (
    AssessmentResult,
    CompletenessResult,
    CompletenessState,
    ConfidenceBand,
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    ParsedQuestionResponse,
    QualityAssessmentResult,
    QualityDimension,
    QualityLevel,
    ResponseAssessment,
    SecurityFramework,
    SourceFormat,
    ValidationResult,
    ValidationStatus,
)

_RATIONALE = '{"rationale": "Confidence reflects the available evidence."}'


def _snapshot() -> FrameworkRegistrySnapshot:
    framework = SecurityFramework(
        name="owasp_llm_top10",
        tier=FrameworkTier.primary,
        visibility=FrameworkVisibility.public,
        version="v1",
        source_artifact_hash="hash",
        source_format=SourceFormat.json,
        extracted_controls=[FrameworkControl(control_id="LLM01", title="t", description="d")],
    )
    return FrameworkRegistrySnapshot(frameworks=[framework])


def _quality(level: QualityLevel) -> QualityAssessmentResult:
    dimension = QualityDimension(level=level, comment="comment")
    return QualityAssessmentResult(
        question_number="1",
        clarity=dimension,
        relevance=dimension,
        sufficiency_of_detail=dimension,
        internal_consistency=dimension,
        architectural_relevance=dimension,
        practical_usefulness=dimension,
        overall_judgment="overall",
    )


def _inputs(
    *,
    status: ValidationStatus = ValidationStatus.complete,
    level: QualityLevel = QualityLevel.strong,
    translated: bool = False,
) -> dict[str, object]:
    record = ParsedQuestionResponse(
        number="1",
        question="question",
        original_text="original",
        original_language="de" if translated else "en",
        translated_text="english text" if translated else None,
    )
    return {
        "records": [record],
        "completeness": [
            CompletenessResult(
                question_number="1",
                structurally_present=True,
                state=CompletenessState.answered,
                reasoning="r",
            )
        ],
        "validations": [ValidationResult(question_number="1", status=status, rationale="r")],
        "quality": [_quality(level)],
        "assessment": AssessmentResult(
            run_id="t",
            response_assessments=[
                ResponseAssessment(
                    question_number="1", findings=[], contextual_reasoning="assessed"
                )
            ],
        ),
        "framework_snapshot": _snapshot(),
    }


def test_confidence_score_is_deterministic(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: _RATIONALE)
    agent = ConfidenceAgent(client, run_id="t")
    first = agent.score(**_inputs())
    second = agent.score(**_inputs())
    assert first.score == second.score


def test_strong_inputs_yield_high_confidence(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: _RATIONALE)
    score = ConfidenceAgent(client, run_id="t").score(**_inputs())
    assert score.band is ConfidenceBand.high


def test_unprofessional_content_lowers_the_score(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: _RATIONALE)
    agent = ConfidenceAgent(client, run_id="t")
    clean = agent.score(**_inputs())
    flagged = agent.score(**_inputs(status=ValidationStatus.offensive_or_unprofessional))
    assert flagged.score < clean.score
    assert flagged.factors.unprofessional_content_present is True


def test_rationale_degrades_to_a_template(llm_factory) -> None:
    client, _ = llm_factory(lambda _m: httpx.ConnectError("down"), max_attempts=1)
    score = ConfidenceAgent(client, run_id="t").score(**_inputs())
    assert "Confidence" in score.rationale  # templated rationale
    assert 0.0 <= score.score <= 1.0
