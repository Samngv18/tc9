"""Qualitative quality assessment (Completeness & Quality agent, sub-step d)."""

from __future__ import annotations

import httpx

from saw.agents.completeness_quality import CompletenessQualityAgent
from saw.schemas import (
    CompletenessResult,
    CompletenessState,
    ParsedQuestionResponse,
    QualityLevel,
)


def _record() -> ParsedQuestionResponse:
    return ParsedQuestionResponse(number="1", question="Question?", original_text="A real answer.")


def _completeness() -> list[CompletenessResult]:
    return [
        CompletenessResult(
            question_number="1",
            structurally_present=True,
            state=CompletenessState.answered,
            reasoning="answered",
        )
    ]


def _agent(llm_factory, responder, **kwargs):
    client, provider = llm_factory(responder, **kwargs)
    return CompletenessQualityAgent(client, run_id="t"), provider


def test_quality_dimensions_are_mapped(llm_factory, make_quality_reply):
    agent, _ = _agent(llm_factory, lambda _m: make_quality_reply(level="strong", overall="solid"))
    out = agent.assess_quality([_record()], _completeness())
    quality = out.quality[0]
    assert quality.clarity.level is QualityLevel.strong
    assert quality.architectural_relevance.level is QualityLevel.strong
    assert quality.practical_usefulness.level is QualityLevel.strong
    assert quality.overall_judgment == "solid"


def test_unknown_level_falls_back_to_not_assessable(llm_factory, make_quality_reply):
    agent, _ = _agent(llm_factory, lambda _m: make_quality_reply(level="amazing"))
    out = agent.assess_quality([_record()], _completeness())
    assert out.quality[0].clarity.level is QualityLevel.not_assessable


def test_quality_degrades_gracefully(llm_factory):
    agent, _ = _agent(llm_factory, lambda _m: httpx.ConnectError("down"), max_attempts=1)
    out = agent.assess_quality([_record()], _completeness())
    assert out.quality[0].clarity.level is QualityLevel.not_assessable
    assert "degraded" in out.quality[0].overall_judgment
