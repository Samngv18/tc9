"""MCP selective bearer-token authentication."""

from __future__ import annotations

import pytest
from fastmcp.exceptions import ToolError

from saw.config import Settings
from saw.mcp_server import auth


def test_extract_bearer_token() -> None:
    assert auth.extract_bearer_token({"Authorization": "Bearer abc123"}) == "abc123"
    assert auth.extract_bearer_token({"authorization": "bearer abc123"}) == "abc123"
    assert auth.extract_bearer_token({"Authorization": "Basic abc123"}) is None
    assert auth.extract_bearer_token({}) is None
    assert auth.extract_bearer_token({"Authorization": "Bearer   "}) is None


def test_is_valid_admin_token() -> None:
    assert auth.is_valid_admin_token("secret", "secret") is True
    assert auth.is_valid_admin_token("wrong", "secret") is False
    assert auth.is_valid_admin_token(None, "secret") is False
    assert auth.is_valid_admin_token("secret", None) is False


def test_check_admin_access_accepts_a_valid_token() -> None:
    auth.check_admin_access({"Authorization": "Bearer secret"}, "secret")  # must not raise


def test_check_admin_access_rejects_missing_or_invalid_tokens() -> None:
    with pytest.raises(auth.AuthError):
        auth.check_admin_access({}, "secret")
    with pytest.raises(auth.AuthError):
        auth.check_admin_access({"Authorization": "Bearer wrong"}, "secret")


def test_require_admin_allows_a_valid_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        auth, "get_http_headers", lambda **_k: {"authorization": "Bearer secret"}
    )
    monkeypatch.setattr(
        auth, "get_settings", lambda: Settings(_env_file=None, admin_token="secret")
    )

    @auth.require_admin
    def protected() -> str:
        return "ran"

    assert protected() == "ran"


def test_require_admin_rejects_a_missing_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(auth, "get_http_headers", lambda **_k: {})
    monkeypatch.setattr(
        auth, "get_settings", lambda: Settings(_env_file=None, admin_token="secret")
    )

    @auth.require_admin
    def protected() -> str:
        return "ran"

    with pytest.raises(ToolError):
        protected()
