"""Schema construction, derived behavior, and serialization round-trips."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from saw.schemas import (
    AssessmentResult,
    CompletenessResult,
    CompletenessState,
    ConfidenceBand,
    ConfidenceFactors,
    ConfidenceScore,
    FactorAssessment,
    FinalReport,
    FollowUpQuestion,
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    LanguageSummary,
    ParsedQuestionResponse,
    QualityAssessmentResult,
    QualityDimension,
    QualityLevel,
    ReliabilityNotice,
    ResponseAssessment,
    RiskFinding,
    RiskSeverity,
    SecurityFramework,
    SourceFormat,
    TraceabilityRow,
    UnprofessionalClassification,
    ValidationStatus,
)


def _factors(*, weak: bool = False) -> ConfidenceFactors:
    level = FactorAssessment.weak if weak else FactorAssessment.adequate
    return ConfidenceFactors(
        parse_completeness=level,
        response_quality=level,
        internal_consistency=level,
        framework_coverage=level,
        unprofessional_content_present=False,
        translated_content_present=False,
    )


def _finding(question_number: str) -> RiskFinding:
    return RiskFinding(
        question_number=question_number,
        severity=RiskSeverity.low,
        risk_observation_internal="internal note",
        original_response_excerpt="excerpt",
        risk_observation_vendor_safe="vendor-safe note",
        vendor_safe_follow_up="follow-up?",
    )


def _sample_report() -> FinalReport:
    confidence = ConfidenceScore(score=0.3, rationale="limited detail", factors=_factors(weak=True))
    return FinalReport(
        run_id="run-1",
        vendor_name="Acme",
        executive_summary="Short summary of vendor security posture.",
        confidence=confidence,
        reliability_notice=ReliabilityNotice(
            confidence_band=ConfidenceBand.low,
            rationale="low confidence due to sparse responses",
            has_unprofessional_responses=True,
            low_confidence=True,
        ),
        risk_summary=[
            TraceabilityRow(
                question_number="1",
                question="How is data stored?",
                response_excerpt="In a database.",
                risk_observation="Encryption is unspecified.",
                follow_up_question="Is stored data encrypted at rest?",
                severity=RiskSeverity.medium,
            )
        ],
        follow_up_questions=[FollowUpQuestion(number=1, text="Is stored data encrypted at rest?")],
        parse_warnings=["row 4: column order differed from template"],
        language_summary=LanguageSummary(
            total_responses=10, translated_responses=3, detected_languages=["en", "de"]
        ),
    )


# --- enums / states ------------------------------------------------------- #


def test_validation_status_has_exactly_eight_members() -> None:
    assert {s.value for s in ValidationStatus} == {
        "complete",
        "sufficient",
        "partial",
        "incomplete",
        "unclear",
        "not_applicable",
        "pending",
        "offensive_or_unprofessional",
    }


@pytest.mark.parametrize(
    ("state", "expected"),
    [
        (CompletenessState.answered, True),
        (CompletenessState.not_applicable_with_reasoning, True),
        (CompletenessState.tbd_with_reasoning, True),
        (CompletenessState.blank, False),
        (CompletenessState.placeholder, False),
    ],
)
def test_completeness_result_is_complete(state: CompletenessState, expected: bool) -> None:
    result = CompletenessResult(
        question_number="1", structurally_present=True, state=state, reasoning="r"
    )
    assert result.is_complete is expected


# --- records -------------------------------------------------------------- #


def test_parsed_response_assessment_text_prefers_translation() -> None:
    untranslated = ParsedQuestionResponse(number="1", question="q", original_text="hallo")
    assert untranslated.is_translated is False
    assert untranslated.assessment_text == "hallo"

    translated = ParsedQuestionResponse(
        number="2",
        question="q",
        original_text="hallo",
        original_language="de",
        translated_text="hello",
    )
    assert translated.is_translated is True
    assert translated.assessment_text == "hello"


# --- confidence ----------------------------------------------------------- #


@pytest.mark.parametrize(
    ("score", "band"),
    [
        (0.0, ConfidenceBand.low),
        (0.49, ConfidenceBand.low),
        (0.5, ConfidenceBand.medium),
        (0.79, ConfidenceBand.medium),
        (0.8, ConfidenceBand.high),
        (1.0, ConfidenceBand.high),
    ],
)
def test_confidence_band_is_derived_from_score(score: float, band: ConfidenceBand) -> None:
    # An explicitly passed band must be overridden by the score-derived one.
    cs = ConfidenceScore(score=score, band=ConfidenceBand.high, rationale="r", factors=_factors())
    assert cs.band is band


def test_confidence_score_out_of_range_is_rejected() -> None:
    with pytest.raises(ValidationError):
        ConfidenceScore(score=1.5, rationale="r", factors=_factors())


# --- risk findings -------------------------------------------------------- #


def test_risk_finding_separates_internal_and_vendor_safe_fields() -> None:
    finding = _finding("3")
    dumped = finding.model_dump()
    assert "risk_observation_internal" in dumped
    assert "framework_alignment_internal" in dumped
    assert "original_response_excerpt" in dumped
    assert "risk_observation_vendor_safe" in dumped
    assert "vendor_safe_follow_up" in dumped
    assert finding.risk_observation_internal != finding.risk_observation_vendor_safe


def test_assessment_result_collects_all_findings() -> None:
    result = AssessmentResult(
        run_id="r",
        response_assessments=[
            ResponseAssessment(
                question_number="1",
                findings=[_finding("1"), _finding("1")],
                contextual_reasoning="x",
            ),
            ResponseAssessment(
                question_number="2", findings=[_finding("2")], contextual_reasoning="y"
            ),
        ],
    )
    assert len(result.all_findings) == 3


# --- quality -------------------------------------------------------------- #


def test_quality_assessment_result_constructs_with_six_dimensions() -> None:
    dim = QualityDimension(level=QualityLevel.adequate, comment="ok")
    quality = QualityAssessmentResult(
        question_number="1",
        clarity=dim,
        relevance=dim,
        sufficiency_of_detail=dim,
        internal_consistency=dim,
        architectural_relevance=dim,
        practical_usefulness=dim,
        overall_judgment="reasonable",
    )
    assert quality.clarity.level is QualityLevel.adequate


# --- frameworks ----------------------------------------------------------- #


def test_framework_snapshot_splits_primary_and_secondary() -> None:
    primary = SecurityFramework(
        name="fw-a",
        tier=FrameworkTier.primary,
        visibility=FrameworkVisibility.public,
        version="v1",
        source_artifact_hash="h1",
        source_format=SourceFormat.json,
        extracted_controls=[FrameworkControl(control_id="C1", title="t", description="d")],
    )
    secondary = SecurityFramework(
        name="fw-b",
        tier=FrameworkTier.secondary,
        visibility=FrameworkVisibility.public,
        version="v1",
        source_artifact_hash="h2",
        source_format=SourceFormat.pdf,
    )
    snapshot = FrameworkRegistrySnapshot(frameworks=[primary, secondary])
    assert [f.name for f in snapshot.primary] == ["fw-a"]
    assert [f.name for f in snapshot.secondary] == ["fw-b"]


# --- report --------------------------------------------------------------- #


def test_reliability_notice_prominence() -> None:
    quiet = ReliabilityNotice(confidence_band=ConfidenceBand.high, rationale="ok")
    assert quiet.is_prominent is False
    loud = ReliabilityNotice(
        confidence_band=ConfidenceBand.high, rationale="ok", significant_translation=True
    )
    assert loud.is_prominent is True


@pytest.mark.parametrize(
    ("total", "translated", "expected"),
    [(10, 3, True), (10, 1, False), (0, 0, False)],
)
def test_language_summary_significant_translation(
    total: int, translated: int, expected: bool
) -> None:
    summary = LanguageSummary(total_responses=total, translated_responses=translated)
    assert summary.significant_translation is expected


def test_final_report_json_round_trip() -> None:
    report = _sample_report()
    restored = FinalReport.model_validate_json(report.model_dump_json())
    assert restored == report
    assert restored.confidence.band is ConfidenceBand.low


# --- strictness ----------------------------------------------------------- #


def test_unknown_fields_are_rejected() -> None:
    with pytest.raises(ValidationError):
        UnprofessionalClassification(
            question_number="1",
            is_flagged=False,
            reasoning="ok",
            bogus_field=123,  # type: ignore[call-arg]
        )
