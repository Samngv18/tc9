"""MCP tool logic: assessment runs and framework management."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

import openpyxl

from saw.agents import InputDocument
from saw.config import Settings
from saw.frameworks import FrameworkRegistry
from saw.mcp_server.tools import AssessmentTools
from saw.schemas import SourceFormat
from saw.storage import FilesystemStorage


def _questionnaire() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(["No", "Answered_By", "Question", "Answer", "Notes"])
    sheet.append([1, "Al", "Do you encrypt data at rest?", "Yes, with AES-256.", ""])
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def _tools(routing_llm, storage: FilesystemStorage) -> AssessmentTools:
    client, _ = routing_llm()
    registry = FrameworkRegistry(storage)
    registry.seed_if_empty()
    return AssessmentTools(
        storage=storage, registry=registry, llm_client=client, settings=Settings(_env_file=None)
    )


def test_run_assessment_produces_and_persists_a_report(routing_llm, tmp_path: Path) -> None:
    storage = FilesystemStorage(tmp_path)
    tools = _tools(routing_llm, storage)
    result = tools.run_assessment(
        [InputDocument(filename="Acme_Questionnaire.xlsx", content=_questionnaire())]
    )
    assert result["vendor_name"] == "Acme"
    assert result["confidence_band"] in {"low", "medium", "high"}
    assert storage.exists(str(result["report_pdf_path"]))
    assert storage.exists(f"runs/{result['run_id']}/traceability_internal.json")


def test_list_active_frameworks(routing_llm, tmp_path: Path) -> None:
    tools = _tools(routing_llm, FilesystemStorage(tmp_path))
    result = tools.list_active_frameworks()
    assert result["count"] == 7
    names = {framework["name"] for framework in result["frameworks"]}
    assert "owasp_llm_top10" in names


def test_update_framework_bumps_the_version(routing_llm, tmp_path: Path) -> None:
    tools = _tools(routing_llm, FilesystemStorage(tmp_path))
    artifact = b'[{"control_id": "X-NEW", "title": "Title", "description": "desc"}]'
    result = tools.update_framework("owasp_llm_top10", artifact, SourceFormat.json)
    assert result["version"] == "v2"
    assert result["control_count"] == 1
    assert result["visibility"] == "public"
