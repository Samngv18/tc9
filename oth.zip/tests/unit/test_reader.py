"""Reader agent: parsing orchestration, translation, and normalization."""

from __future__ import annotations

from saw.agents.reader import InputDocument, ReaderAgent

HEADERS = ["No", "Answered_By", "Question", "Answer", "Notes"]


def _english(_messages: object) -> str:
    return '{"language": "en", "is_english": true, "english_text": "unchanged"}'


def test_reader_parses_and_normalizes(llm_factory, make_xlsx) -> None:
    xlsx = make_xlsx(HEADERS, [[1, "Al", "Encrypt at rest?", "Yes, with AES-256 everywhere.", ""]])
    client, _ = llm_factory(_english)
    result = ReaderAgent(client, run_id="r1").read(
        [InputDocument(filename="Acme_Security_Questionnaire.xlsx", content=xlsx)]
    )
    assert result.vendor_name == "Acme"
    assert len(result.records) == 1
    assert result.records[0].question == "Encrypt at rest?"
    assert result.language_summary.total_responses == 1


def test_reader_translates_non_english_responses(llm_factory, make_xlsx) -> None:
    xlsx = make_xlsx(HEADERS, [[1, "Bruno", "Zugriff?", "Wir verschlusseln alle Daten.", ""]])

    def responder(messages: list) -> str:
        if "verschlusseln" in messages[-1].content:
            return '{"language": "de", "is_english": false, "english_text": "We encrypt all data."}'
        return _english(messages)

    client, _ = llm_factory(responder)
    result = ReaderAgent(client, run_id="r2").read(
        [InputDocument(filename="globex.xlsx", content=xlsx)]
    )
    record = result.records[0]
    assert record.is_translated is True
    assert record.original_language == "de"
    assert record.assessment_text == "We encrypt all data."
    assert result.language_summary.translated_responses == 1


def test_reader_with_no_sources_degrades_gracefully(llm_factory) -> None:
    client, _ = llm_factory(_english)
    result = ReaderAgent(client, run_id="r3").read([])
    assert result.records == []
    assert result.vendor_name == "Vendor"
    assert any("no question" in warning for warning in result.parse_warnings)


def test_reader_warns_on_unsupported_format(llm_factory) -> None:
    client, _ = llm_factory(_english)
    result = ReaderAgent(client, run_id="r4").read(
        [InputDocument(filename="notes.docx", content=b"data")]
    )
    assert any("unsupported" in warning for warning in result.parse_warnings)
