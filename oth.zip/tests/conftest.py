"""Shared pytest fixtures for the test suite."""

from __future__ import annotations

import json
from io import BytesIO

import openpyxl
import pytest

from saw.config import Settings
from saw.llm.client import LLMClient
from saw.llm.providers import RawCompletion
from saw.schemas import (
    ConfidenceFactors,
    ConfidenceScore,
    FactorAssessment,
    FinalReport,
    FollowUpQuestion,
    LanguageSummary,
    ReliabilityNotice,
    RiskSeverity,
    TraceabilityRow,
)


class _ScriptedProvider:
    """Provider stub: a responder maps the messages to canned content (or an error)."""

    name = "azure_openai"
    model = "stub"

    def __init__(self, responder):
        self._responder = responder
        self.calls = 0

    def complete(self, messages, *, max_tokens, temperature):
        self.calls += 1
        outcome = self._responder(messages)
        if isinstance(outcome, BaseException):
            raise outcome
        return RawCompletion(
            model="stub", content=outcome, tokens_in=10, tokens_out=10, finish_reason="stop"
        )


@pytest.fixture
def llm_factory():
    """Return a builder for an LLMClient backed by a scripted stub provider."""

    def _build(responder, *, max_attempts=1):
        settings = Settings(
            _env_file=None,
            llm_default_provider="azure_openai",
            llm_max_attempts=max_attempts,
            llm_base_delay_seconds=0.0,
            llm_max_delay_seconds=0.0,
        )
        provider = _ScriptedProvider(responder)
        client = LLMClient(
            settings, http_client=None, providers={"azure_openai": provider}, sleep=lambda _: None
        )
        return client, provider

    return _build


@pytest.fixture
def make_xlsx():
    """Return a builder for in-memory XLSX questionnaire bytes."""

    def _build(headers, rows, *, sheet_title="Responses"):
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = sheet_title
        sheet.append(headers)
        for row in rows:
            sheet.append(row)
        buffer = BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()

    return _build


@pytest.fixture
def make_quality_reply():
    """Return a builder for the quality-node combined JSON reply."""

    def _build(
        *,
        flagged=False,
        category=None,
        excerpt=None,
        unprof_reason="no unprofessional language",
        status="sufficient",
        rationale="adequately answered",
        level="adequate",
        overall="reasonable response",
    ):
        dimension = {"level": level, "comment": "comment"}
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": flagged,
                    "category": category,
                    "offending_excerpt": excerpt,
                    "reasoning": unprof_reason,
                },
                "validation": {"status": status, "rationale": rationale},
                "quality": {
                    "clarity": dimension,
                    "relevance": dimension,
                    "sufficiency_of_detail": dimension,
                    "internal_consistency": dimension,
                    "architectural_relevance": dimension,
                    "practical_usefulness": dimension,
                    "overall_judgment": overall,
                },
            }
        )

    return _build


@pytest.fixture
def make_final_report():
    """Return a builder for a FinalReport with sensible, overridable defaults."""

    def _build(
        *,
        run_id="test-run",
        vendor_name="Acme",
        executive_summary="A concise vendor-safe summary of the security posture.",
        confidence_score=0.7,
        rows=None,
        follow_ups=None,
        parse_warnings=None,
        notice_text="",
        has_unprofessional=False,
        low_confidence=False,
    ):
        factors = ConfidenceFactors(
            parse_completeness=FactorAssessment.adequate,
            response_quality=FactorAssessment.adequate,
            internal_consistency=FactorAssessment.adequate,
            framework_coverage=FactorAssessment.adequate,
            unprofessional_content_present=has_unprofessional,
            translated_content_present=False,
        )
        confidence = ConfidenceScore(
            score=confidence_score, rationale="Confidence rationale text.", factors=factors
        )
        if rows is None:
            rows = [
                TraceabilityRow(
                    question_number="1",
                    question="How is data stored?",
                    response_excerpt="In a managed database.",
                    risk_observation="Encryption at rest is not specified.",
                    follow_up_question="Is stored data encrypted at rest?",
                    severity=RiskSeverity.medium,
                )
            ]
        if follow_ups is None:
            follow_ups = [FollowUpQuestion(number=1, text="Is stored data encrypted at rest?")]
        return FinalReport(
            run_id=run_id,
            vendor_name=vendor_name,
            executive_summary=executive_summary,
            confidence=confidence,
            reliability_notice=ReliabilityNotice(
                confidence_band=confidence.band,
                rationale=confidence.rationale,
                has_unprofessional_responses=has_unprofessional,
                low_confidence=low_confidence,
                notice_text=notice_text,
            ),
            risk_summary=rows,
            follow_up_questions=follow_ups,
            parse_warnings=parse_warnings or [],
            language_summary=LanguageSummary(total_responses=1, translated_responses=0),
        )

    return _build


def _agent_route(messages: list) -> str:
    """Per-agent routing stub: a canned reply keyed by the system prompt."""
    system = messages[0].content
    user = messages[-1].content
    if "profile the context" in system:
        return json.dumps(
            {
                "solution_type": "llm",
                "business_use_case": "AI assistant",
                "pii_handling": "unknown",
                "uses_external_tools": False,
                "model_sourcing": "proprietary",
                "open_source_models_identified": None,
                "rationale": "profiled from responses",
            }
        )
    if "translation engine" in system:
        if "verschl" in user:
            return '{"language": "de", "is_english": false, "english_text": "We encrypt data."}'
        return '{"language": "en", "is_english": true, "english_text": "unchanged"}'
    if "COMPLETENESS" in system:
        return '{"structurally_present": true, "state": "answered", "reasoning": "answered"}'
    if "perform three tasks" in system:
        dimension = {"level": "adequate", "comment": "comment"}
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": False,
                    "category": None,
                    "offending_excerpt": None,
                    "reasoning": "neutral",
                },
                "validation": {"status": "sufficient", "rationale": "ok"},
                "quality": {
                    "clarity": dimension,
                    "relevance": dimension,
                    "sufficiency_of_detail": dimension,
                    "internal_consistency": dimension,
                    "architectural_relevance": dimension,
                    "practical_usefulness": dimension,
                    "overall_judgment": "fine",
                },
            }
        )
    if "security risk analyst" in system:
        return json.dumps(
            {
                "findings": [
                    {
                        "severity": "medium",
                        "risk_observation_internal": "weak input handling",
                        "framework_alignment": [],
                        "vendor_safe_risk_observation": "Input validation is partial.",
                        "vendor_safe_follow_up": "How is input validated?",
                    }
                ],
                "contextual_reasoning": "partial coverage",
                "no_material_risk": False,
            }
        )
    if "confidence score" in system:
        return '{"rationale": "Confidence is moderate."}'
    if "executive summary" in system:
        return '{"executive_summary": "A reasonable security posture overall."}'
    if "consolidate draft follow-up" in system:
        return '{"questions": ["How is input validated?"]}'
    return "{}"


@pytest.fixture
def routing_llm(llm_factory):
    """Return a builder for an LLMClient backed by the per-agent routing stub."""

    def _build():
        return llm_factory(_agent_route)

    return _build
