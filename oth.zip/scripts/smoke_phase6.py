"""Phase 6 smoke check — end-to-end LangGraph run on a multi-language fixture.

    uv run python scripts/smoke_phase6.py

Uses a deterministic stub LLM so the run is offline and every intermediate state
snapshot persisted to <storage>/runs/{run_id}/ is visible.
"""

from __future__ import annotations

import json
import sys
import tempfile
from io import BytesIO
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import openpyxl

from saw.agents import InputDocument
from saw.config import Settings, configure_logging, get_settings
from saw.frameworks import FrameworkRegistry
from saw.graph import AssessmentWorkflow
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.storage import FilesystemStorage

_DIMENSION = {"level": "adequate", "comment": "reasonable detail"}


def _route(messages: list[ChatMessage]) -> str:
    system = messages[0].content
    user = messages[-1].content
    if "translation engine" in system:
        if "verschl" in user:
            return '{"language": "de", "is_english": false, "english_text": "We encrypt all data."}'
        return '{"language": "en", "is_english": true, "english_text": "unchanged"}'
    if "COMPLETENESS" in system:
        return '{"structurally_present": true, "state": "answered", "reasoning": "answered"}'
    if "perform three tasks" in system:
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": False,
                    "category": None,
                    "offending_excerpt": None,
                    "reasoning": "neutral tone",
                },
                "validation": {"status": "sufficient", "rationale": "adequately answered"},
                "quality": {
                    "clarity": _DIMENSION,
                    "relevance": _DIMENSION,
                    "sufficiency_of_detail": _DIMENSION,
                    "internal_consistency": _DIMENSION,
                    "architectural_relevance": _DIMENSION,
                    "practical_usefulness": _DIMENSION,
                    "overall_judgment": "a reasonable response",
                },
            }
        )
    if "security risk analyst" in system:
        return json.dumps(
            {
                "findings": [
                    {
                        "severity": "medium",
                        "risk_observation_internal": "input validation partly described per LLM01",
                        "framework_alignment": [
                            {
                                "framework_name": "owasp_llm_top10",
                                "framework_tier": "primary",
                                "control_ids": ["LLM01"],
                                "note": "input handling",
                            }
                        ],
                        "vendor_safe_risk_observation": (
                            "Input validation practices are only partially described."
                        ),
                        "vendor_safe_follow_up": "How is all external input validated before use?",
                    }
                ],
                "contextual_reasoning": "partial coverage of input handling",
                "no_material_risk": False,
            }
        )
    if "confidence score" in system:
        return '{"rationale": "Confidence is moderate given clear but uneven detail."}'
    if "executive summary" in system:
        return json.dumps(
            {
                "executive_summary": (
                    "The vendor's responses indicate a generally reasonable security posture, "
                    "with some areas requiring further detail."
                )
            }
        )
    if "consolidate draft follow-up" in system:
        return '{"questions": ["How is all external input validated before use?"]}'
    return "{}"


class _StubProvider:
    name = "azure_openai"
    model = "stub"

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        return RawCompletion(
            model="stub",
            content=_route(messages),
            tokens_in=10,
            tokens_out=10,
            finish_reason="stop",
        )


def _questionnaire() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(["No", "Answered_By", "Question", "Answer", "Notes"])
    sheet.append([1, "Alice", "Do you encrypt data at rest?",
                  "Yes, all data is encrypted with AES-256.", ""])
    sheet.append([2, "Bruno", "Wie verwalten Sie Zugriffsrechte?",
                  "Wir verschluesseln Daten und nutzen RBAC.", ""])
    sheet.append([3, "Chloe", "Do you have an incident response plan?", "", ""])
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def main() -> None:
    configure_logging(get_settings())
    settings = Settings(_env_file=None, llm_default_provider="azure_openai", llm_max_attempts=1)
    with tempfile.TemporaryDirectory() as tmp:
        storage = FilesystemStorage(tmp)
        client = LLMClient(
            settings,
            http_client=None,
            providers={"azure_openai": _StubProvider()},
            sleep=lambda _: None,
        )
        workflow = AssessmentWorkflow(
            storage=storage, registry=FrameworkRegistry(storage), llm_client=client
        )
        run_id = "smoke-phase6"
        document = InputDocument(
            filename="Globex_Security_Questionnaire.xlsx", content=_questionnaire()
        )
        final = workflow.run(run_id, [document])

        print("\n== intermediate state snapshots ==")
        for name in storage.list_dir(f"runs/{run_id}"):
            snapshot = json.loads(storage.read_text(f"runs/{run_id}/{name}"))
            keys = sorted(k for k in snapshot if k not in {"run_id", "inputs"})
            print(f"  {name}  ->  {', '.join(keys)}")

        report = final["final_report"]
        print("\n== final report ==")
        print(f"  vendor={report.vendor_name}  confidence={report.confidence.band.value}")
        print(f"  risk rows={len(report.risk_summary)}  "
              f"follow-ups={len(report.follow_up_questions)}")
        print(f"  reliability notice prominent={report.reliability_notice.is_prominent}")
        leaked = [t for t in ("LLM01", "OWASP") if t in report.model_dump_json()]
        print(f"  framework references in report: {leaked or 'none'}")
        print(f"  executive summary: {report.executive_summary}")

    print("\nphase 6 smoke check complete.\n")


if __name__ == "__main__":
    main()
