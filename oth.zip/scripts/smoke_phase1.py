"""Phase 1 smoke check.

    uv run python scripts/smoke_phase1.py

Demonstrates, with no external dependencies required:
  * settings load + logging bootstrap,
  * filesystem storage round-trip,
  * the retry/backoff path degrading to a typed LLMFallbackResponse.

If provider credentials are present in the environment it additionally performs
one real call per configured provider.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

# Dev convenience: import `saw` from the source tree without relying on an
# editable install (which `uv run` does not always honor for src layouts).
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import httpx

from saw.config import Settings, configure_logging, get_settings
from saw.http.client import build_sync_client
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.llm.providers import RawCompletion
from saw.storage.filesystem import build_storage


class _AlwaysFailProvider:
    """Provider stand-in that is always unreachable — exercises the fallback path."""

    name = "demo-unreachable"
    model = "demo-model"

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        raise httpx.ConnectError("simulated unreachable provider")


def _demo_storage() -> None:
    print("\n== storage ==")
    with tempfile.TemporaryDirectory() as tmp:
        storage = build_storage(Settings(_env_file=None, storage_root=tmp))
        storage.write_text("runs/demo/state.json", '{"ok": true}')
        print("  root:        ", storage.root)
        print("  write+read:  ", storage.read_text("runs/demo/state.json"))
        print("  list_dir:    ", storage.list_dir("runs/demo"))


def _demo_fallback(settings: Settings) -> None:
    print("\n== retry -> typed fallback (forced failure) ==")
    diag = RunDiagnostics(run_id="smoke")
    client = LLMClient(
        settings,
        http_client=None,
        providers={settings.llm_default_provider: _AlwaysFailProvider()},
        sleep=lambda _: None,
    )
    result = client.complete(
        [ChatMessage(role="user", content="ping")],
        run_id="smoke",
        node="smoke",
        diagnostics=diag,
    )
    print(f"  is_fallback={result.is_fallback} attempts={result.attempts}")
    print("  run summary:", diag.summary().model_dump())


def _demo_live_providers(settings: Settings) -> None:
    print("\n== providers ==")
    configured = settings.configured_providers()
    if not configured:
        print("  no provider credentials in env — set SAW_*__API_KEY in .env for a live call")
        return
    http_client = build_sync_client(settings)
    try:
        client = LLMClient(settings, http_client)
        for name in configured:
            diag = RunDiagnostics(run_id="smoke-live")
            result = client.complete(
                [ChatMessage(role="user", content="Reply with the single word: ready")],
                provider=name,
                max_tokens=16,
                run_id="smoke-live",
                node=name,
                diagnostics=diag,
            )
            status = "FALLBACK" if result.is_fallback else "OK"
            print(f"  {name}: {status} -> {result.content!r}")
    finally:
        http_client.close()


def main() -> None:
    settings = get_settings()
    configure_logging(settings)
    _demo_storage()
    _demo_fallback(settings)
    _demo_live_providers(settings)
    print("\nphase 1 smoke check complete.\n")


if __name__ == "__main__":
    main()
