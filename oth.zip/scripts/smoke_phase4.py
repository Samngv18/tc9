"""Phase 4 smoke check.

    uv run python scripts/smoke_phase4.py

Seeds a fresh framework registry, lists the active set, uploads a revised JSON
version of one framework, and confirms the event-driven reload — with no polling
or watcher thread.
"""

from __future__ import annotations

import json
import sys
import tempfile
import threading
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from saw.config import configure_logging, get_settings
from saw.frameworks import FrameworkRegistry
from saw.schemas import SourceFormat
from saw.storage import FilesystemStorage

_REVISED_OWASP = json.dumps(
    [
        {"control_id": "LLM01", "title": "Prompt Injection",
         "description": "Revised description committed as v2.", "category": "Input"},
        {"control_id": "LLM11", "title": "New Emerging Risk",
         "description": "A control added in the revised upload.", "category": "New"},
    ]
).encode()


def main() -> None:
    configure_logging(get_settings())
    baseline_threads = threading.active_count()

    with tempfile.TemporaryDirectory() as tmp:
        registry = FrameworkRegistry(FilesystemStorage(tmp))

        print("\n== seed (first startup) ==")
        seeded = registry.seed_if_empty()
        print(f"  seeded {len(seeded)} frameworks")
        for framework in registry.snapshot().frameworks:
            print(
                f"  {framework.name:28s} {framework.tier.value:9s} "
                f"{framework.visibility.value:8s} {framework.version}  "
                f"controls={len(framework.extracted_controls)}"
            )

        print("\n== event-driven update (JSON upload) ==")
        updated = registry.update_framework("owasp_llm_top10", _REVISED_OWASP, SourceFormat.json)
        print(f"  owasp_llm_top10 committed -> {updated.version}  "
              f"controls={len(updated.extracted_controls)}")
        active = {f.name: f for f in registry.snapshot().frameworks}["owasp_llm_top10"]
        print(f"  snapshot after reload: version={active.version}  "
              f"(reload ran inside update_framework)")

        print("\n== idempotent re-seed ==")
        print(f"  re-running seed_if_empty() seeded: {registry.seed_if_empty()}")

        print("\n== no polling ==")
        print(f"  threads before={baseline_threads}  after={threading.active_count()}  "
              f"(no watcher or polling thread)")

    print("\nphase 4 smoke check complete.\n")


if __name__ == "__main__":
    main()
