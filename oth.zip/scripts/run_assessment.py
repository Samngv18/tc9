"""Run an end-to-end AI security assessment on a questionnaire XLSX.

    uv run python scripts/run_assessment.py [--stub] [PATH_TO_XLSX]

With provider credentials in the environment the configured LLM is used. With
--stub, or when no provider is configured, a deterministic content-aware stub
LLM runs the full pipeline offline. Produces a vendor-safe PDF report.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from saw.agents import InputDocument
from saw.config import Settings, configure_logging, get_settings
from saw.frameworks import FrameworkRegistry
from saw.graph import AssessmentWorkflow
from saw.http.client import build_sync_client
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.reporting import build_internal_traceability, render_report_pdf
from saw.storage import FilesystemStorage

_PROJECT = Path(__file__).resolve().parents[1]
_DEFAULT_XLSX = _PROJECT / "samples" / "Anthropic_AI_Security_Questionnaire.xlsx"
_DEFAULT_SUPPLEMENTAL = [
    _PROJECT / "samples" / "anthropic_dpa.md",
    _PROJECT / "samples" / "anthropic_architecture.md",
]
_REPORT_OUT = _PROJECT / "samples" / "sample_assessment_report.pdf"
_BANNED = ("OWASP", "MITRE", "ATLAS", "NIST", "LLM01", "AML.T", "ISO/IEC", "INT-SEC")


# --- content-aware stub LLM (used offline / with --stub) -------------------- #


def _response_text(user_prompt: str) -> str:
    after = user_prompt.split("Vendor response:")[-1]
    return after.split("Completeness state")[0].strip()


def _translate(user_prompt: str) -> str:
    if "Subunternehmer" in user_prompt:
        return json.dumps(
            {
                "language": "de",
                "is_english": False,
                "english_text": (
                    "Our sub-processors are established cloud infrastructure providers. "
                    "A complete and current list is disclosed in the data processing "
                    "agreement."
                ),
            }
        )
    return json.dumps({"language": "en", "is_english": True, "english_text": "unchanged"})


def _completeness(user_prompt: str) -> str:
    text = _response_text(user_prompt).lower()
    if text.startswith("tbd"):
        return json.dumps(
            {
                "structurally_present": True,
                "state": "tbd_with_reasoning",
                "reasoning": "the vendor states this is pending and gives a timeframe",
            }
        )
    if text.startswith("n/a"):
        return json.dumps(
            {
                "structurally_present": True,
                "state": "not_applicable_with_reasoning",
                "reasoning": "the vendor explains why this does not apply",
            }
        )
    return json.dumps(
        {
            "structurally_present": True,
            "state": "answered",
            "reasoning": "a substantive answer is present",
        }
    )


def _quality(user_prompt: str) -> str:
    text = _response_text(user_prompt)
    low = text.lower()
    flagged = any(token in low for token in ("ridiculous", "dumb", "not going to spell"))
    if flagged:
        unprofessional = {
            "is_flagged": True,
            "category": "dismissive",
            "offending_excerpt": "this is a ridiculous question",
            "reasoning": "the response is dismissive and not professional",
        }
        validation = {"status": "partial", "rationale": "tone obscures the actual answer"}
        level = "weak"
    elif low.startswith("n/a"):
        unprofessional = {
            "is_flagged": False,
            "category": None,
            "offending_excerpt": None,
            "reasoning": "neutral tone",
        }
        validation = {
            "status": "not_applicable",
            "rationale": "the question does not apply and the vendor explains why",
        }
        level = "adequate"
    elif len(text) < 45:
        unprofessional = {
            "is_flagged": False,
            "category": None,
            "offending_excerpt": None,
            "reasoning": "neutral tone",
        }
        validation = {"status": "incomplete", "rationale": "the response lacks specific detail"}
        level = "weak"
    else:
        unprofessional = {
            "is_flagged": False,
            "category": None,
            "offending_excerpt": None,
            "reasoning": "neutral, professional tone",
        }
        validation = {"status": "sufficient", "rationale": "the response adequately answers it"}
        level = "adequate"
    dimension = {"level": level, "comment": "assessed"}
    return json.dumps(
        {
            "unprofessional": unprofessional,
            "validation": validation,
            "quality": {
                "clarity": dimension,
                "relevance": dimension,
                "sufficiency_of_detail": dimension,
                "internal_consistency": dimension,
                "architectural_relevance": dimension,
                "practical_usefulness": dimension,
                "overall_judgment": "assessed",
            },
        }
    )


def _assessment(user_prompt: str) -> str:
    text = _response_text(user_prompt)
    low = text.lower()
    weak = any(token in low for token in ("ridiculous", "tbd", "sometimes", "basic review"))
    detailed = len(text) > 90 and not weak
    if low.startswith("n/a") or detailed:
        return json.dumps(
            {
                "findings": [],
                "contextual_reasoning": "the response adequately describes the relevant controls",
                "no_material_risk": True,
            }
        )
    return json.dumps(
        {
            "findings": [
                {
                    "severity": "medium",
                    "risk_observation_internal": "insufficient detail to confirm the control",
                    "framework_alignment": [],
                    "vendor_safe_risk_observation": (
                        "The response does not provide enough detail to confirm that adequate "
                        "controls are in place for this area."
                    ),
                    "vendor_safe_follow_up": (
                        "Can you describe the specific controls and how they are tested?"
                    ),
                }
            ],
            "contextual_reasoning": "the response is too brief or unclear to rule out risk",
            "no_material_risk": False,
        }
    )


def _stub_route(messages: list[ChatMessage]) -> str:
    system = messages[0].content
    user = messages[-1].content
    if "profile the context" in system:
        return json.dumps(
            {
                "solution_type": "llm",
                "business_use_case": "large language model API platform",
                "pii_handling": "no_pii",
                "uses_external_tools": False,
                "model_sourcing": "proprietary",
                "open_source_models_identified": None,
                "rationale": (
                    "the vendor provides a proprietary LLM API and states it does not "
                    "process special categories of personal data"
                ),
            }
        )
    if "translation engine" in system:
        return _translate(user)
    if "the COMPLETENESS" in system:
        return _completeness(user)
    if "perform three tasks" in system:
        return _quality(user)
    if "security risk analyst" in system:
        return _assessment(user)
    if "confidence score" in system:
        return json.dumps(
            {
                "rationale": (
                    "Confidence is moderate: several responses are detailed and professional, "
                    "but others are brief, pending, or did not meet disclosure norms."
                )
            }
        )
    if "executive summary" in system:
        return json.dumps(
            {
                "executive_summary": (
                    "The vendor's responses describe encryption, data handling, tenant "
                    "isolation, incident response, and change management. Most responses are "
                    "detailed and consistent with the supporting documents provided; a small "
                    "number are still pending or lack detail and are flagged for follow-up. "
                    "Overall the assessment indicates a reasonable security posture with a "
                    "few specific items to clarify."
                )
            }
        )
    if "consolidate draft follow-up" in system:
        drafts = [line[2:].strip() for line in user.splitlines() if line.startswith("- ")]
        return json.dumps({"questions": drafts or ["Can you provide additional detail?"]})
    return "{}"


class _StubProvider:
    name = "azure_openai"
    model = "stub"

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        return RawCompletion(
            model="stub",
            content=_stub_route(messages),
            tokens_in=20,
            tokens_out=20,
            finish_reason="stop",
        )


def _build_llm(settings: Settings, use_stub: bool) -> LLMClient:
    if use_stub:
        return LLMClient(
            settings,
            http_client=None,
            providers={settings.llm_default_provider: _StubProvider()},
            sleep=lambda _: None,
        )
    return LLMClient(settings, build_sync_client(settings))


# --- runner ---------------------------------------------------------------- #


def main() -> None:
    argv = sys.argv[1:]
    force_stub = "--stub" in argv
    positional = [arg for arg in argv if not arg.startswith("--")]
    if positional:
        xlsx_path = Path(positional[0])
        supplemental_paths = [Path(p) for p in positional[1:]]
    else:
        xlsx_path = _DEFAULT_XLSX
        supplemental_paths = list(_DEFAULT_SUPPLEMENTAL)
    if not xlsx_path.exists():
        print(f"questionnaire not found: {xlsx_path}")
        print("generate it with: uv run python scripts/make_sample_questionnaire.py")
        sys.exit(1)

    settings = get_settings()
    configure_logging(settings)
    use_stub = force_stub or not settings.configured_providers()
    llm = _build_llm(settings, use_stub)
    mode = "stub LLM (offline)" if use_stub else f"live provider: {settings.llm_default_provider}"

    supplemental_docs: list[InputDocument] = []
    for path in supplemental_paths:
        if path.exists():
            supplemental_docs.append(
                InputDocument(filename=path.name, content=path.read_bytes())
            )
        else:
            print(f"  supporting document not found, skipped: {path}")

    print(f"\nQuestionnaire:        {xlsx_path.name}")
    print(f"Supporting documents: {[d.filename for d in supplemental_docs] or 'none'}")
    print(f"LLM mode:             {mode}")

    storage = FilesystemStorage(_PROJECT / ".saw-runs")
    registry = FrameworkRegistry(storage, llm_client=llm)
    registry.seed_if_empty()
    workflow = AssessmentWorkflow(storage=storage, registry=registry, llm_client=llm)

    run_id = "sample-run"
    document = InputDocument(filename=xlsx_path.name, content=xlsx_path.read_bytes())
    final = workflow.run(run_id, [document], supplemental_docs or None)

    records = final["parsed_records"]
    completeness = {item.question_number: item for item in final["completeness_results"]}
    validations = {item.question_number: item for item in final["validations"]}
    findings_by_question: dict[str, int] = {}
    for response_assessment in final["assessment_results"].response_assessments:
        findings_by_question[response_assessment.question_number] = len(
            response_assessment.findings
        )

    print(f"\nVendor: {final['vendor_name']}   Responses: {len(records)}")
    supplemental_ctx = final.get("supplemental_context")
    if supplemental_ctx is not None and supplemental_ctx.documents:
        print("Supporting documents ingested into the assessment:")
        for doc in supplemental_ctx.documents:
            print(f"  {doc.filename}  ({doc.fmt.value}, {len(doc.extracted_text)} chars)")
    context = final.get("assessment_context")
    if context is not None:
        print("\nAssessment context (calibrates how responses are judged):")
        print(f"  solution type:  {context.solution_type.value}")
        print(f"  use case:       {context.business_use_case}")
        print(f"  PII handling:   {context.pii_handling.value}")
        print(f"  model sourcing: {context.model_sourcing.value}")
    print(f"\n{'#':<3} {'lang':<5} {'completeness':<30} {'validation':<26} findings")
    print("-" * 78)
    for record in records:
        comp = completeness.get(record.number)
        valid = validations.get(record.number)
        print(
            f"{record.number:<3} {record.original_language:<5} "
            f"{(comp.state.value if comp else '-'):<30} "
            f"{(valid.status.value if valid else '-'):<26} "
            f"{findings_by_question.get(record.number, 0)}"
        )

    confidence = final["confidence"]
    report = final["final_report"]
    finding_count = sum(findings_by_question.values())
    print(f"\nConfidence: {confidence.band.value} (score {confidence.score:.2f})")
    print(f"Summary rows: {len(report.risk_summary)} (all questions)   "
          f"Risk findings: {finding_count}   "
          f"Follow-up questions: {len(report.follow_up_questions)}")
    print(f"Reliability notice prominent: {report.reliability_notice.is_prominent}")
    print(f"\nExecutive summary:\n  {report.executive_summary}")

    pdf = render_report_pdf(report)
    _REPORT_OUT.write_bytes(pdf)
    traceability = build_internal_traceability(
        run_id=run_id,
        vendor_name=report.vendor_name,
        records=records,
        assessment=final["assessment_results"],
        validations=final["validations"],
    )
    storage.write_text(
        f"runs/{run_id}/traceability_internal.json", traceability.model_dump_json(indent=2)
    )

    leaked = [token for token in _BANNED if token in report.model_dump_json()]
    print(f"\nVendor-safe PDF report: {_REPORT_OUT}  ({len(pdf)} bytes)")
    print(f"Framework references in report: {leaked or 'none'}")
    print(f"Run artifacts (per-node snapshots, internal traceability): "
          f"{storage.root}/runs/{run_id}/")
    if use_stub:
        print("\nNote: this run used the offline stub LLM. Configure a provider in .env "
              "and re-run without --stub for a live assessment.")
    print()


if __name__ == "__main__":
    main()
