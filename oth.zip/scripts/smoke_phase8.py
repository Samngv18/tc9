"""Phase 8 smoke check — MCP tools, selective auth, health, and server build.

    uv run python scripts/smoke_phase8.py

Exercises the MCP layer offline (non-blocking): the three tool handlers via a
stub LLM, the bearer-token auth check, the health probes, the active-frameworks
resource, and a FastMCP server build. `uv run saw-mcp` starts the real HTTP
server (MCP tools plus /healthz and /readyz).
"""

from __future__ import annotations

import json
import sys
from io import BytesIO
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import openpyxl

from saw.agents import InputDocument
from saw.config import Settings, configure_logging, get_settings
from saw.frameworks import FrameworkRegistry
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.mcp_server.auth import AuthError, check_admin_access
from saw.mcp_server.health import liveness, readiness
from saw.mcp_server.resources import active_frameworks_view
from saw.mcp_server.server import create_server
from saw.mcp_server.tools import AssessmentTools
from saw.schemas import SourceFormat
from saw.storage import FilesystemStorage

_DIMENSION = {"level": "adequate", "comment": "reasonable detail"}


def _route(messages: list[ChatMessage]) -> str:
    system = messages[0].content
    if "translation engine" in system:
        return '{"language": "en", "is_english": true, "english_text": "unchanged"}'
    if "COMPLETENESS" in system:
        return '{"structurally_present": true, "state": "answered", "reasoning": "answered"}'
    if "perform three tasks" in system:
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": False,
                    "category": None,
                    "offending_excerpt": None,
                    "reasoning": "neutral",
                },
                "validation": {"status": "sufficient", "rationale": "ok"},
                "quality": {
                    "clarity": _DIMENSION,
                    "relevance": _DIMENSION,
                    "sufficiency_of_detail": _DIMENSION,
                    "internal_consistency": _DIMENSION,
                    "architectural_relevance": _DIMENSION,
                    "practical_usefulness": _DIMENSION,
                    "overall_judgment": "fine",
                },
            }
        )
    if "security risk analyst" in system:
        return json.dumps(
            {
                "findings": [
                    {
                        "severity": "medium",
                        "risk_observation_internal": "weak input handling",
                        "framework_alignment": [],
                        "vendor_safe_risk_observation": "Input validation is partial.",
                        "vendor_safe_follow_up": "How is input validated?",
                    }
                ],
                "contextual_reasoning": "partial coverage",
                "no_material_risk": False,
            }
        )
    if "confidence score" in system:
        return '{"rationale": "Confidence is moderate."}'
    if "executive summary" in system:
        return '{"executive_summary": "A reasonable security posture overall."}'
    if "consolidate draft follow-up" in system:
        return '{"questions": ["How is input validated?"]}'
    return "{}"


class _StubProvider:
    name = "azure_openai"
    model = "stub"

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        return RawCompletion(
            model="stub",
            content=_route(messages),
            tokens_in=10,
            tokens_out=10,
            finish_reason="stop",
        )


def _questionnaire() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(["No", "Answered_By", "Question", "Answer", "Notes"])
    sheet.append([1, "Alice", "Do you encrypt data at rest?", "Yes, with AES-256.", ""])
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def main() -> None:
    configure_logging(get_settings())
    storage_root = Path.cwd() / ".saw-smoke8"
    settings = Settings(_env_file=None, storage_root=storage_root, admin_token="demo-admin-token")
    storage = FilesystemStorage(storage_root)
    client = LLMClient(
        settings,
        http_client=None,
        providers={"azure_openai": _StubProvider()},
        sleep=lambda _: None,
    )
    registry = FrameworkRegistry(storage)
    registry.seed_if_empty()
    tools = AssessmentTools(
        storage=storage, registry=registry, llm_client=client, settings=settings
    )

    print("\n== tool: run_assessment (open, no auth) ==")
    result = tools.run_assessment(
        [InputDocument(filename="Acme_Security_Questionnaire.xlsx", content=_questionnaire())]
    )
    print(f"  run_id={result['run_id']}  vendor={result['vendor_name']}  "
          f"confidence={result['confidence_band']}")
    print(f"  report PDF persisted at: {result['report_pdf_path']}")

    print("\n== tool: list_active_frameworks (admin) ==")
    print(f"  active frameworks: {tools.list_active_frameworks()['count']}")

    print("\n== tool: update_framework (admin) ==")
    update = tools.update_framework(
        "owasp_llm_top10",
        b'[{"control_id": "LLM-X", "title": "New", "description": "added"}]',
        SourceFormat.json,
    )
    print(f"  owasp_llm_top10 -> {update['version']}  controls={update['control_count']}")

    print("\n== selective auth ==")
    try:
        check_admin_access({"Authorization": "Bearer demo-admin-token"}, settings.admin_token)
        print("  valid bearer token: accepted")
    except AuthError:
        print("  valid bearer token: REJECTED (unexpected)")
    try:
        check_admin_access({"Authorization": "Bearer wrong"}, settings.admin_token)
        print("  invalid bearer token: accepted (unexpected)")
    except AuthError:
        print("  invalid bearer token: rejected")

    print("\n== health ==")
    print(f"  /healthz -> {liveness()}")
    ready, detail = readiness(registry, settings)
    print(f"  /readyz  -> ready={ready}  {detail}")

    print("\n== resource: framework_registry://active (admin) ==")
    view = active_frameworks_view(registry)
    print(f"  frameworks in resource view: {view['count']}")

    print("\n== FastMCP server build ==")
    create_server(settings)
    print("  create_server() succeeded; `uv run saw-mcp` serves it over HTTP on :8000")

    print("\nphase 8 smoke check complete.\n")


if __name__ == "__main__":
    main()
