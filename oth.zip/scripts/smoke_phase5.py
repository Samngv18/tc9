"""Phase 5 smoke check — runs all five agents on a small questionnaire.

    uv run python scripts/smoke_phase5.py

Uses a built-in deterministic stub LLM so the full agent chain runs offline and
its intermediate output is visible at every stage. Provider credentials are not
used; the per-agent LLM behavior is covered by the unit test suite.
"""

from __future__ import annotations

import json
import sys
from io import BytesIO
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import openpyxl

from saw.agents import (
    AssessmentAgent,
    CompletenessQualityAgent,
    ConfidenceAgent,
    InputDocument,
    ReaderAgent,
    ReportAgent,
)
from saw.config import Settings, configure_logging, get_settings
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.schemas import (
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    SecurityFramework,
    SourceFormat,
)

_DIMENSION = {"level": "adequate", "comment": "reasonable detail"}


def _stub_response(messages: list[ChatMessage]) -> str:
    """Route a canned JSON reply based on the agent's system prompt."""
    system = messages[0].content
    user = messages[-1].content
    if "translation engine" in system:
        if "verschl" in user:
            return json.dumps(
                {
                    "language": "de",
                    "is_english": False,
                    "english_text": "We encrypt data and use role-based access control.",
                }
            )
        return json.dumps({"language": "en", "is_english": True, "english_text": "unchanged"})
    if "COMPLETENESS" in system:
        return json.dumps(
            {
                "structurally_present": True,
                "state": "answered",
                "reasoning": "a substantive answer is present",
            }
        )
    if "perform three tasks" in system:
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": False,
                    "category": None,
                    "offending_excerpt": None,
                    "reasoning": "neutral, professional tone",
                },
                "validation": {"status": "sufficient", "rationale": "adequately answered"},
                "quality": {
                    "clarity": _DIMENSION,
                    "relevance": _DIMENSION,
                    "sufficiency_of_detail": _DIMENSION,
                    "internal_consistency": _DIMENSION,
                    "architectural_relevance": _DIMENSION,
                    "practical_usefulness": _DIMENSION,
                    "overall_judgment": "a reasonable response",
                },
            }
        )
    if "security risk analyst" in system:
        return json.dumps(
            {
                "findings": [
                    {
                        "severity": "medium",
                        "risk_observation_internal": "input validation only partially described",
                        "framework_alignment": [
                            {
                                "framework_name": "owasp_llm_top10",
                                "framework_tier": "primary",
                                "control_ids": ["LLM01"],
                                "note": "input handling",
                            }
                        ],
                        "vendor_safe_risk_observation": (
                            "Input validation practices are only partially described."
                        ),
                        "vendor_safe_follow_up": (
                            "How is all external input validated before it is used?"
                        ),
                    }
                ],
                "contextual_reasoning": "partial coverage of input handling",
                "no_material_risk": False,
            }
        )
    if "confidence score" in system:
        return json.dumps(
            {"rationale": "Confidence is moderate given generally clear but uneven detail."}
        )
    if "executive summary" in system:
        return json.dumps(
            {
                "executive_summary": (
                    "The vendor's responses indicate a generally reasonable security posture, "
                    "with some areas requiring additional detail before risks can be fully "
                    "ruled out."
                )
            }
        )
    if "consolidate draft follow-up" in system:
        return json.dumps(
            {"questions": ["How is all external input validated before it is used?"]}
        )
    return "{}"


class _StubProvider:
    name = "azure_openai"
    model = "stub"

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        return RawCompletion(
            model="stub",
            content=_stub_response(messages),
            tokens_in=10,
            tokens_out=10,
            finish_reason="stop",
        )


def _questionnaire() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(["No", "Answered_By", "Question", "Answer", "Notes"])
    sheet.append([1, "Alice", "Do you encrypt data at rest?",
                  "Yes, all data is encrypted with AES-256.", ""])
    sheet.append([2, "Bruno", "Wie verwalten Sie Zugriffsrechte?",
                  "Wir verschluesseln Daten und nutzen RBAC.", ""])
    sheet.append([3, "Chloe", "Do you have an incident response plan?", "", ""])
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def _snapshot() -> FrameworkRegistrySnapshot:
    framework = SecurityFramework(
        name="owasp_llm_top10",
        tier=FrameworkTier.primary,
        visibility=FrameworkVisibility.public,
        version="v1",
        source_artifact_hash="hash",
        source_format=SourceFormat.json,
        extracted_controls=[
            FrameworkControl(control_id="LLM01", title="Prompt Injection", description="desc")
        ],
    )
    return FrameworkRegistrySnapshot(frameworks=[framework])


def main() -> None:
    configure_logging(get_settings())
    settings = Settings(_env_file=None, llm_default_provider="azure_openai", llm_max_attempts=1)
    client = LLMClient(
        settings,
        http_client=None,
        providers={"azure_openai": _StubProvider()},
        sleep=lambda _: None,
    )
    run_id = "smoke-phase5"

    print("\n== Agent 1: Reader ==")
    reader = ReaderAgent(client, run_id=run_id)
    reader_result = reader.read([InputDocument(filename="Globex_Security_Questionnaire.xlsx",
                                               content=_questionnaire())])
    records = reader_result.records
    print(f"  vendor={reader_result.vendor_name}  records={len(records)}  "
          f"translated={reader_result.language_summary.translated_responses}")
    for record in records:
        print(f"  [{record.number}] lang={record.original_language} -> {record.assessment_text!r}")

    print("\n== Agent 2: Completeness & Quality ==")
    cq_agent = CompletenessQualityAgent(client, run_id=run_id)
    completeness = cq_agent.check_completeness(records)
    for result in completeness:
        print(f"  [{result.question_number}] completeness={result.state.value}")
    quality_output = cq_agent.assess_quality(records, completeness)
    for validation in quality_output.validations:
        print(f"  [{validation.question_number}] validation={validation.status.value}")

    print("\n== Agent 3: Assessment ==")
    assessment = AssessmentAgent(client, run_id=run_id).assess(records, _snapshot())
    for response_assessment in assessment.response_assessments:
        for finding in response_assessment.findings:
            print(f"  [{response_assessment.question_number}] {finding.severity.value}: "
                  f"{finding.risk_observation_vendor_safe}")

    print("\n== Agent 4: Confidence ==")
    confidence = ConfidenceAgent(client, run_id=run_id).score(
        records=records, completeness=completeness, validations=quality_output.validations,
        quality=quality_output.quality, assessment=assessment, framework_snapshot=_snapshot(),
    )
    print(f"  score={confidence.score:.2f}  band={confidence.band.value}")
    print(f"  rationale={confidence.rationale}")

    print("\n== Agent 5: Report ==")
    report = ReportAgent(client, run_id=run_id).build(
        vendor_name=reader_result.vendor_name,
        records=records,
        validations=quality_output.validations,
        assessment=assessment,
        confidence=confidence,
        parse_warnings=reader_result.parse_warnings,
        language_summary=reader_result.language_summary,
    )
    print(f"  executive summary: {report.executive_summary}")
    print(f"  risk rows={len(report.risk_summary)}  follow-ups={len(report.follow_up_questions)}")
    print(f"  reliability notice prominent={report.reliability_notice.is_prominent}")
    leaked = [t for t in ("LLM01", "OWASP", "owasp_llm_top10") if t in report.model_dump_json()]
    print(f"  framework references in report: {leaked or 'none'}")

    print("\nphase 5 smoke check complete.\n")


if __name__ == "__main__":
    main()
