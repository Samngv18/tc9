"""Generate a sample vendor AI security questionnaire (XLSX) for testing.

    uv run python scripts/make_sample_questionnaire.py

Writes samples/Anthropic_AI_Security_Questionnaire.xlsx in the required column
pattern (No, Answered_By, Question, Answer, Notes), with Anthropic as the
assessed vendor. The responses deliberately exercise the full pipeline: strong
answers that the supporting documents corroborate, a multi-language answer, an
N/A with reasoning, a TBD, and a brief/incomplete answer.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Dev convenience: keep the path consistent with the other scripts.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import openpyxl

_HEADERS = ["No", "Answered_By", "Question", "Answer", "Notes"]

_ROWS: list[list[object]] = [
    [
        1,
        "Karen Liu",
        "Is customer data encrypted in transit and at rest?",
        "Yes. All customer data is encrypted in transit using TLS 1.2 or higher and at "
        "rest using AES-256. Key management and rotation are described in the attached "
        "Data Processing Agreement.",
        "",
    ],
    [
        2,
        "Karen Liu",
        "Is customer data submitted through the API used to train your models?",
        "No. Data submitted through the Claude API is not used to train our models. This "
        "commitment is set out contractually in our Data Processing Agreement.",
        "",
    ],
    [
        3,
        "Lukas Brandt",
        "Welche Subunternehmer verarbeiten personenbezogene Kundendaten?",
        "Unsere Subunternehmer sind etablierte Cloud-Infrastrukturanbieter. Eine "
        "vollständige und aktuelle Liste wird im Auftragsverarbeitungsvertrag "
        "offengelegt.",
        "answered in German",
    ],
    [
        4,
        "Maria Santos",
        "How do you defend against prompt injection attacks?",
        "TBD - a formal prompt-injection threat model is still being documented. Current "
        "measures include input handling, separation of system instructions from user "
        "content, and safety classifiers.",
        "",
    ],
    [
        5,
        "Maria Santos",
        "Do you intentionally process special categories of personal data?",
        "N/A - the API is not designed to process special categories of personal data; "
        "customers control and are responsible for the content they submit.",
        "",
    ],
    [
        6,
        "Noah Kim",
        "What is your retention period for API inputs and outputs?",
        "API inputs and outputs are retained for a limited operational period and then "
        "deleted. Zero-retention processing is available to eligible customers. "
        "Retention terms are set out in the Data Processing Agreement.",
        "",
    ],
    [
        7,
        "Noah Kim",
        "How is tenant isolation enforced between customers?",
        "Each API request is processed in an isolated compute environment and customer "
        "data is logically separated between tenants, as described in the architecture "
        "overview.",
        "",
    ],
    [
        8,
        "Priya Nair",
        "What human oversight governs model behavior and safety?",
        "Model behavior is shaped by reinforcement learning from human feedback and by "
        "ongoing safety evaluations performed before each release.",
        "",
    ],
    [
        9,
        "Priya Nair",
        "Describe your security incident and personal data breach notification process.",
        "We maintain a documented incident response plan and notify affected customers of "
        "personal data breaches without undue delay and within 72 hours, as set out in "
        "the Data Processing Agreement.",
        "",
    ],
    [
        10,
        "Omar Haddad",
        "Do you hold independent third-party security certifications?",
        "Yes. We maintain SOC 2 Type II. Audit reports are available to customers under a "
        "non-disclosure agreement.",
        "",
    ],
    [
        11,
        "Omar Haddad",
        "How are model and infrastructure changes tested before release?",
        "Changes follow a staged rollout with model evaluations and regression testing in "
        "a pre-production environment before reaching production.",
        "",
    ],
    [
        12,
        "Rachel Adeyemi",
        "What logging do you retain for API requests, and for how long?",
        "We retain operational logs.",
        "brief answer",
    ],
]


def main() -> None:
    samples_dir = Path(__file__).resolve().parents[1] / "samples"
    samples_dir.mkdir(parents=True, exist_ok=True)
    out_path = samples_dir / "Anthropic_AI_Security_Questionnaire.xlsx"

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Vendor Responses"
    sheet.append(_HEADERS)
    for row in _ROWS:
        sheet.append(row)
    workbook.save(out_path)

    # Remove the earlier non-Anthropic sample if it is still present.
    (samples_dir / "sample_vendor_questionnaire.xlsx").unlink(missing_ok=True)

    print(f"wrote {out_path}")
    print(f"  {len(_ROWS)} responses across columns: {', '.join(_HEADERS)}")
    print("  supporting documents: samples/anthropic_dpa.md, samples/anthropic_architecture.md")


if __name__ == "__main__":
    main()
