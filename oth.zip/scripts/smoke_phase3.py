"""Phase 3 smoke check.

    uv run python scripts/smoke_phase3.py

Builds a multi-language questionnaire in memory, parses it, infers the vendor
name, and prints the normalized records. If provider credentials are present it
also runs the translation layer and shows the translations attached.
"""

from __future__ import annotations

import sys
from io import BytesIO
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import openpyxl

from saw.config import configure_logging, get_settings
from saw.http.client import build_sync_client
from saw.llm.client import LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.llm.translation import Translator
from saw.parsers import infer_vendor_name, parse_xlsx

_HEADERS = ["No", "Answered_By", "Question", "Answer", "Notes"]
_ROWS: list[list[object]] = [
    [1, "Alice", "Do you encrypt data at rest?", "Yes, all data is encrypted with AES-256.", ""],
    [2, "Bruno", "Wie verwalten Sie Zugriffsrechte?",
     "Wir verwenden rollenbasierte Zugriffskontrolle fur alle Systeme.", "de"],
    [3, "Chloe", "Comment gerez-vous les incidents?",
     "Nous disposons d'un plan de reponse aux incidents teste chaque trimestre.", "fr"],
    [4, "Dana", "Do you process PII?", "N/A", ""],
]


def _build_multilang_xlsx() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(_HEADERS)
    for row in _ROWS:
        sheet.append(row)
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def main() -> None:
    settings = get_settings()
    configure_logging(settings)

    filename = "Globex_AI_Security_Questionnaire_2025.xlsx"
    print("\n== parse ==")
    print("  vendor name inferred:", infer_vendor_name(filename))
    result = parse_xlsx(_build_multilang_xlsx(), filename=filename)
    print(f"  sheet={result.detected_sheet}  records={len(result.records)}  "
          f"warnings={len(result.warnings)}")
    for record in result.records:
        print(f"  [{record.number}] {record.question}")
        print(f"      answer: {record.original_text}")

    print("\n== translation ==")
    configured = settings.configured_providers()
    if not configured:
        print("  no provider credentials in env — set SAW_*__API_KEY in .env for live "
              "translation")
        return
    http_client = build_sync_client(settings)
    try:
        diagnostics = RunDiagnostics(run_id="smoke-phase3")
        translator = Translator(
            LLMClient(settings, http_client), run_id="smoke-phase3", diagnostics=diagnostics
        )
        for record in translator.translate_all(result.records):
            marker = "TRANSLATED" if record.is_translated else "english"
            print(f"  [{record.number}] lang={record.original_language} ({marker})")
            if record.is_translated:
                print(f"      original:   {record.original_text}")
                print(f"      translated: {record.translated_text}")
        print("  run summary:", diagnostics.summary().model_dump())
    finally:
        http_client.close()

    print("\nphase 3 smoke check complete.\n")


if __name__ == "__main__":
    main()
