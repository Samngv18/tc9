"""Phase 7 smoke check — vendor-safe filtering and PDF report generation.

    uv run python scripts/smoke_phase7.py

Runs the full workflow offline (stub LLM), renders the vendor-safe PDF report,
confirms zero framework references, builds the internal traceability record, and
demonstrates the vendor-safe filter on a deliberately leaky snippet.
"""

from __future__ import annotations

import json
import sys
import tempfile
from io import BytesIO
from pathlib import Path

# Dev convenience: import `saw` from the source tree without an editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import openpyxl
import pdfplumber

from saw.agents import InputDocument
from saw.config import Settings, configure_logging, get_settings
from saw.frameworks import FrameworkRegistry
from saw.graph import AssessmentWorkflow
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.providers import RawCompletion
from saw.reporting import VendorSafeFilter, build_internal_traceability, render_report_pdf
from saw.schemas import RiskSeverity, TraceabilityRow
from saw.storage import FilesystemStorage

_DIMENSION = {"level": "adequate", "comment": "reasonable detail"}
_BANNED = ("OWASP", "MITRE", "ATLAS", "NIST", "LLM01", "AML.T", "ISO/IEC", "INT-SEC")


def _route(messages: list[ChatMessage]) -> str:
    system = messages[0].content
    user = messages[-1].content
    if "translation engine" in system:
        if "verschl" in user:
            return '{"language": "de", "is_english": false, "english_text": "We encrypt all data."}'
        return '{"language": "en", "is_english": true, "english_text": "unchanged"}'
    if "COMPLETENESS" in system:
        return '{"structurally_present": true, "state": "answered", "reasoning": "answered"}'
    if "perform three tasks" in system:
        return json.dumps(
            {
                "unprofessional": {
                    "is_flagged": False,
                    "category": None,
                    "offending_excerpt": None,
                    "reasoning": "neutral tone",
                },
                "validation": {"status": "sufficient", "rationale": "adequately answered"},
                "quality": {
                    "clarity": _DIMENSION,
                    "relevance": _DIMENSION,
                    "sufficiency_of_detail": _DIMENSION,
                    "internal_consistency": _DIMENSION,
                    "architectural_relevance": _DIMENSION,
                    "practical_usefulness": _DIMENSION,
                    "overall_judgment": "a reasonable response",
                },
            }
        )
    if "security risk analyst" in system:
        return json.dumps(
            {
                "findings": [
                    {
                        "severity": "medium",
                        "risk_observation_internal": "input validation partly described per LLM01",
                        "framework_alignment": [
                            {
                                "framework_name": "owasp_llm_top10",
                                "framework_tier": "primary",
                                "control_ids": ["LLM01"],
                                "note": "input handling",
                            }
                        ],
                        "vendor_safe_risk_observation": (
                            "Input validation practices are only partially described."
                        ),
                        "vendor_safe_follow_up": "How is all external input validated before use?",
                    }
                ],
                "contextual_reasoning": "partial coverage of input handling",
                "no_material_risk": False,
            }
        )
    if "confidence score" in system:
        return '{"rationale": "Confidence is moderate given clear but uneven detail."}'
    if "executive summary" in system:
        return json.dumps(
            {
                "executive_summary": (
                    "The vendor's responses indicate a generally reasonable security posture, "
                    "with some areas requiring further detail."
                )
            }
        )
    if "consolidate draft follow-up" in system:
        return '{"questions": ["How is all external input validated before use?"]}'
    return "{}"


class _StubProvider:
    name = "azure_openai"
    model = "stub"

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        return RawCompletion(
            model="stub",
            content=_route(messages),
            tokens_in=10,
            tokens_out=10,
            finish_reason="stop",
        )


def _questionnaire() -> bytes:
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Responses"
    sheet.append(["No", "Answered_By", "Question", "Answer", "Notes"])
    sheet.append([1, "Alice", "Do you encrypt data at rest?",
                  "Yes, all data is encrypted with AES-256.", ""])
    sheet.append([2, "Bruno", "Wie verwalten Sie Zugriffsrechte?",
                  "Wir verschluesseln Daten und nutzen RBAC.", ""])
    sheet.append([3, "Chloe", "Do you have an incident response plan?", "", ""])
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def main() -> None:
    configure_logging(get_settings())
    settings = Settings(_env_file=None, llm_default_provider="azure_openai", llm_max_attempts=1)
    with tempfile.TemporaryDirectory() as tmp:
        storage = FilesystemStorage(tmp)
        client = LLMClient(
            settings,
            http_client=None,
            providers={"azure_openai": _StubProvider()},
            sleep=lambda _: None,
        )
        workflow = AssessmentWorkflow(
            storage=storage, registry=FrameworkRegistry(storage), llm_client=client
        )
        run_id = "smoke-phase7"
        document = InputDocument(
            filename="Globex_Security_Questionnaire.xlsx", content=_questionnaire()
        )
        final = workflow.run(run_id, [document])
        report = final["final_report"]

        print("\n== vendor-safe report ==")
        print(f"  vendor={report.vendor_name}  risk rows={len(report.risk_summary)}")
        leaked_model = [token for token in _BANNED if token in report.model_dump_json()]
        print(f"  framework references in report model: {leaked_model or 'none'}")

        pdf = render_report_pdf(report)
        pdf_path = Path(tempfile.gettempdir()) / "saw-phase7-report.pdf"
        pdf_path.write_bytes(pdf)
        with pdfplumber.open(BytesIO(pdf)) as opened:
            pdf_text = "\n".join(page.extract_text() or "" for page in opened.pages)
        leaked_pdf = [token for token in _BANNED if token in pdf_text]
        print(f"  rendered PDF: {pdf_path}  ({len(pdf)} bytes)")
        print(f"  framework references in rendered PDF: {leaked_pdf or 'none'}")

        print("\n== internal traceability (NOT shared with the vendor) ==")
        traceability = build_internal_traceability(
            run_id=run_id,
            vendor_name=report.vendor_name,
            records=final["parsed_records"],
            assessment=final["assessment_results"],
            validations=final["validations"],
        )
        print(f"  entries={len(traceability.entries)}")
        for entry in traceability.entries:
            controls = ", ".join(
                cid for alignment in entry.framework_alignment for cid in alignment.control_ids
            )
            print(f"  [{entry.question_number}] lang={entry.original_language}  "
                  f"internal control refs: {controls or 'none'}")

        print("\n== filter demonstration (deliberate leak) ==")
        leaky = TraceabilityRow(
            question_number="X",
            question="OWASP LLM01 coverage?",
            response_excerpt="We follow MITRE ATLAS AML.T0051.",
            risk_observation="Practices fall short of the NIST AI RMF guidance.",
            follow_up_question="How is input validated?",
            severity=RiskSeverity.high,
        )
        vsf = VendorSafeFilter(final["framework_snapshot"])
        print(f"  before: {leaky.risk_observation}")
        print(f"  after:  {vsf.filter_text(leaky.risk_observation)}")

    print("\nphase 7 smoke check complete.\n")


if __name__ == "__main__":
    main()
