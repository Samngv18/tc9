"""Pre-flight token estimation.

Estimates are advisory (prompt sizing, budgeting). The token counts returned by
the provider response are authoritative and are what diagnostics record.
"""

from __future__ import annotations

import structlog
import tiktoken

log = structlog.get_logger(__name__)

_DEFAULT_ENCODING = "cl100k_base"

# ~4 tokens of structural framing per chat message (role markers, separators).
_PER_MESSAGE_OVERHEAD = 4


def _encoding(model: str) -> tiktoken.Encoding:
    try:
        return tiktoken.encoding_for_model(model)
    except KeyError:
        return tiktoken.get_encoding(_DEFAULT_ENCODING)


def estimate_tokens(text: str, model: str = "gpt-4o") -> int:
    """Best-effort token estimate for a string."""
    if not text:
        return 0
    try:
        return len(_encoding(model).encode(text))
    except Exception as exc:  # estimation must never block an actual call
        log.warning("token_estimate_fallback", model=model, error=str(exc))
        return max(1, len(text) // 4)


def estimate_messages_tokens(messages: list[dict[str, str]], model: str = "gpt-4o") -> int:
    """Best-effort token estimate for a list of chat messages."""
    return sum(
        estimate_tokens(m.get("content", ""), model) + _PER_MESSAGE_OVERHEAD for m in messages
    )
