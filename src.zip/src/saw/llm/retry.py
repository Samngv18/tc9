"""Retry policy: transient-error classification and full-jitter exponential backoff."""

from __future__ import annotations

import random
from dataclasses import dataclass

import httpx

# HTTP status codes treated as transient and worth retrying.
RETRYABLE_STATUS = frozenset({408, 409, 425, 429, 500, 502, 503, 504})

# Exception class names that indicate a transient failure. The openai and
# anthropic SDKs expose identically named classes, so name matching covers both
# without importing every SDK exception tree.
RETRYABLE_EXC_NAMES = frozenset(
    {
        "APIConnectionError",
        "APITimeoutError",
        "APIConnectionTimeoutError",
        "RateLimitError",
        "InternalServerError",
    }
)


@dataclass(frozen=True)
class RetryPolicy:
    """Bounds for retrying a single LLM call."""

    max_attempts: int
    base_delay: float
    max_delay: float

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        if self.base_delay < 0 or self.max_delay < 0:
            raise ValueError("delay bounds must be >= 0")


def is_retryable(exc: BaseException) -> bool:
    """Return True if ``exc`` represents a transient failure worth retrying."""
    status = getattr(exc, "status_code", None)
    if isinstance(status, int) and status in RETRYABLE_STATUS:
        return True
    if type(exc).__name__ in RETRYABLE_EXC_NAMES:
        return True
    return isinstance(exc, (httpx.TimeoutException, httpx.TransportError))


def compute_delay(
    attempt: int, policy: RetryPolicy, *, rng: random.Random | None = None
) -> float:
    """Full-jitter exponential backoff delay (seconds) for a zero-based attempt index.

    The delay is drawn uniformly from ``[0, min(max_delay, base_delay * 2**attempt)]``,
    which spreads retries and avoids thundering-herd retry storms.
    """
    if attempt < 0:
        raise ValueError("attempt must be >= 0")
    rand = rng or random
    ceiling = min(policy.max_delay, policy.base_delay * (2**attempt))
    return rand.uniform(0.0, ceiling)
