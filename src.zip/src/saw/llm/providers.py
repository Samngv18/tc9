"""Provider adapters over the openai and anthropic SDKs.

Each adapter exposes a uniform ``complete`` method returning a ``RawCompletion``.
SDK-level retries are disabled (``max_retries=0``) so the single retry/backoff
loop in :mod:`saw.llm.client` is the only one in effect. SDK clients are built
lazily so importing this module never requires credentials.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Protocol, cast, runtime_checkable

import httpx
from pydantic import BaseModel

from saw.config import AnthropicConfig, AzureOpenAIConfig, LangDockConfig

if TYPE_CHECKING:
    from anthropic import Anthropic
    from anthropic.types import MessageParam
    from openai import AzureOpenAI, OpenAI
    from openai.types.chat import ChatCompletionMessageParam


class ChatMessage(BaseModel):
    """A single chat message crossing an agent/provider boundary."""

    role: Literal["system", "user", "assistant"]
    content: str


class RawCompletion(BaseModel):
    """Provider-agnostic completion result before client-side normalization."""

    model: str
    content: str
    tokens_in: int
    tokens_out: int
    finish_reason: str | None = None


@runtime_checkable
class Provider(Protocol):
    """Structural interface every provider adapter satisfies."""

    name: str
    model: str

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion: ...


class AzureOpenAIProvider:
    """Azure OpenAI chat-completions adapter."""

    name = "azure_openai"

    def __init__(self, config: AzureOpenAIConfig, http_client: httpx.Client) -> None:
        if not config.is_configured:
            raise ValueError("Azure OpenAI provider is not configured")
        self._config = config
        self._http_client = http_client
        # Reported model is the underlying model name; the API is routed by deployment.
        self.model = config.model_name or config.deployment or ""
        self._client: AzureOpenAI | None = None

    def _sdk(self) -> AzureOpenAI:
        if self._client is None:
            from openai import AzureOpenAI

            self._client = AzureOpenAI(
                azure_endpoint=self._config.endpoint or "",
                api_key=self._config.api_key,
                api_version=self._config.api_version,
                http_client=self._http_client,
                max_retries=0,
            )
        return self._client

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        payload = cast(
            "list[ChatCompletionMessageParam]",
            [{"role": m.role, "content": m.content} for m in messages],
        )
        resp = self._sdk().chat.completions.create(
            # Azure routes by deployment name; the `model` argument is the deployment.
            model=self._config.deployment or "",
            messages=payload,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        choice = resp.choices[0]
        usage = resp.usage
        return RawCompletion(
            model=resp.model or self.model,
            content=choice.message.content or "",
            tokens_in=usage.prompt_tokens if usage else 0,
            tokens_out=usage.completion_tokens if usage else 0,
            finish_reason=choice.finish_reason,
        )


class LangDockProvider:
    """LangDock adapter over the OpenAI-compatible chat-completions API."""

    name = "langdock"

    def __init__(self, config: LangDockConfig, http_client: httpx.Client) -> None:
        if not config.is_configured:
            raise ValueError("LangDock provider is not configured")
        self._config = config
        self._http_client = http_client
        self.model = config.model
        self._client: OpenAI | None = None

    def _sdk(self) -> OpenAI:
        if self._client is None:
            from openai import OpenAI

            self._client = OpenAI(
                base_url=self._config.base_url,
                api_key=self._config.api_key,
                http_client=self._http_client,
                max_retries=0,
            )
        return self._client

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        payload = cast(
            "list[ChatCompletionMessageParam]",
            [{"role": m.role, "content": m.content} for m in messages],
        )
        resp = self._sdk().chat.completions.create(
            model=self._config.model,
            messages=payload,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        choice = resp.choices[0]
        usage = resp.usage
        return RawCompletion(
            model=resp.model or self.model,
            content=choice.message.content or "",
            tokens_in=usage.prompt_tokens if usage else 0,
            tokens_out=usage.completion_tokens if usage else 0,
            finish_reason=choice.finish_reason,
        )


class AnthropicProvider:
    """Anthropic Messages-API adapter."""

    name = "anthropic"

    def __init__(self, config: AnthropicConfig, http_client: httpx.Client) -> None:
        if not config.is_configured:
            raise ValueError("Anthropic provider is not configured")
        self._config = config
        self._http_client = http_client
        self.model = config.model
        self._client: Anthropic | None = None

    def _sdk(self) -> Anthropic:
        if self._client is None:
            from anthropic import Anthropic

            self._client = Anthropic(
                api_key=self._config.api_key,
                http_client=self._http_client,
                max_retries=0,
            )
        return self._client

    def complete(
        self, messages: list[ChatMessage], *, max_tokens: int, temperature: float
    ) -> RawCompletion:
        # The Messages API takes `system` separately from the conversation turns.
        system = "\n\n".join(m.content for m in messages if m.role == "system")
        turns = cast(
            "list[MessageParam]",
            [
                {"role": m.role, "content": m.content}
                for m in messages
                if m.role != "system"
            ],
        )
        sdk = self._sdk()
        if system:
            resp = sdk.messages.create(
                model=self._config.model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system,
                messages=turns,
            )
        else:
            resp = sdk.messages.create(
                model=self._config.model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=turns,
            )
        from anthropic.types import TextBlock

        text = "".join(
            block.text for block in resp.content if isinstance(block, TextBlock)
        )
        return RawCompletion(
            model=resp.model,
            content=text,
            tokens_in=resp.usage.input_tokens,
            tokens_out=resp.usage.output_tokens,
            finish_reason=resp.stop_reason,
        )
