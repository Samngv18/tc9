"""Per-call diagnostics and run-level token/cost summaries."""

from __future__ import annotations

import structlog
from pydantic import BaseModel

log = structlog.get_logger(__name__)


class CallDiagnostic(BaseModel):
    """A single LLM call outcome."""

    run_id: str
    node: str = "-"
    provider: str
    model: str
    attempts: int
    success: bool
    is_fallback: bool = False
    tokens_in: int = 0
    tokens_out: int = 0
    duration_ms: float
    error: str | None = None


class RunTokenSummary(BaseModel):
    """Aggregate of every LLM call in a run."""

    run_id: str
    calls: int
    successful_calls: int
    fallback_calls: int
    total_tokens_in: int
    total_tokens_out: int
    total_duration_ms: float


class RunDiagnostics:
    """Collects per-call diagnostics for one run and produces a summary.

    Each recorded call emits one structured log line keyed by ``run_id``/``node``.
    """

    def __init__(self, run_id: str) -> None:
        self.run_id = run_id
        self._calls: list[CallDiagnostic] = []

    def record(self, call: CallDiagnostic) -> None:
        self._calls.append(call)
        log.info(
            "llm_call",
            run_id=call.run_id,
            node=call.node,
            provider=call.provider,
            model=call.model,
            attempts=call.attempts,
            success=call.success,
            is_fallback=call.is_fallback,
            tokens_in=call.tokens_in,
            tokens_out=call.tokens_out,
            duration_ms=round(call.duration_ms, 1),
            error=call.error,
        )

    @property
    def calls(self) -> list[CallDiagnostic]:
        return list(self._calls)

    def summary(self) -> RunTokenSummary:
        return RunTokenSummary(
            run_id=self.run_id,
            calls=len(self._calls),
            successful_calls=sum(1 for c in self._calls if c.success),
            fallback_calls=sum(1 for c in self._calls if c.is_fallback),
            total_tokens_in=sum(c.tokens_in for c in self._calls),
            total_tokens_out=sum(c.tokens_out for c in self._calls),
            total_duration_ms=sum(c.duration_ms for c in self._calls),
        )
