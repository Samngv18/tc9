"""Per-response language detection and translation to English.

Non-English vendor responses are translated before assessment; the original text
and language are preserved for internal traceability. Results are cached within a
run so repeated answers (``N/A``, ``Yes``, ...) cost at most one call. A degraded
LLM never raises — translation falls back to the original text with a warning.
"""

from __future__ import annotations

import json

import structlog
from pydantic import BaseModel, ValidationError

from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.translation import translation_system_prompt, translation_user_prompt
from saw.schemas import ParsedQuestionResponse, StrictModel

log = structlog.get_logger(__name__)

# Short, unambiguous English tokens that never need an LLM round-trip.
_OBVIOUS_ENGLISH = frozenset(
    {"n/a", "na", "n.a.", "not applicable", "yes", "no", "tbd", "tba", "none", "n/k",
     "true", "false", "ok", "pending", "unknown", "not available"}
)
_MAX_TRANSLATION_TOKENS = 3000


class TranslationOutcome(StrictModel):
    """Result of detecting and (if needed) translating one piece of text."""

    language: str  # ISO 639-1 code, or "und" when undetermined
    is_english: bool
    translated_text: str | None  # English translation; None when already English
    degraded: bool = False  # the LLM could not produce a usable result


class _TranslationReply(BaseModel):
    """Lenient parse of the translation LLM's JSON reply (extra keys ignored)."""

    language: str
    is_english: bool
    english_text: str


def _braced(text: str) -> str | None:
    start, end = text.find("{"), text.rfind("}")
    return text[start : end + 1] if 0 <= start < end else None


def _extract_json_object(content: str) -> dict[str, object] | None:
    """Parse a JSON object from an LLM reply, tolerating surrounding prose/fences."""
    text = content.strip()
    for candidate in (text, _braced(text)):
        if candidate is None:
            continue
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return parsed
    return None


class Translator:
    """Detects language and translates responses, caching by exact text within a run."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        provider: ProviderName | None = None,
        diagnostics: RunDiagnostics | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._provider = provider
        self._diagnostics = diagnostics
        self._cache: dict[str, TranslationOutcome] = {}

    def detect_and_translate(self, text: str) -> TranslationOutcome:
        """Detect the language of ``text`` and translate it to English if needed."""
        key = text.strip()
        if not key:
            return TranslationOutcome(language="und", is_english=True, translated_text=None)
        if key.lower() in _OBVIOUS_ENGLISH:
            return TranslationOutcome(language="en", is_english=True, translated_text=None)
        if key in self._cache:
            return self._cache[key]
        outcome = self._call_llm(key)
        self._cache[key] = outcome
        return outcome

    def translate_response(self, response: ParsedQuestionResponse) -> ParsedQuestionResponse:
        """Return a copy of ``response`` with language fields populated."""
        outcome = self.detect_and_translate(response.original_text)
        warnings = list(response.parse_warnings)
        if outcome.degraded:
            warnings.append(
                "language could not be determined; response assessed in its original form"
            )
        return response.model_copy(
            update={
                "original_language": outcome.language,
                "translated_text": outcome.translated_text,
                "parse_warnings": warnings,
            }
        )

    def translate_all(
        self, responses: list[ParsedQuestionResponse]
    ) -> list[ParsedQuestionResponse]:
        """Translate every response, reusing the within-run cache."""
        return [self.translate_response(r) for r in responses]

    def _call_llm(self, text: str) -> TranslationOutcome:
        messages = [
            ChatMessage(role="system", content=translation_system_prompt()),
            ChatMessage(role="user", content=translation_user_prompt(text)),
        ]
        result = self._llm.complete(
            messages,
            provider=self._provider,
            max_tokens=_MAX_TRANSLATION_TOKENS,
            temperature=0.0,
            run_id=self._run_id,
            node="translate",
            diagnostics=self._diagnostics,
        )
        if result.is_fallback:
            log.warning("translation_degraded", run_id=self._run_id, reason=result.reason)
            return TranslationOutcome(
                language="und", is_english=True, translated_text=None, degraded=True
            )

        parsed = _extract_json_object(result.content)
        if parsed is None:
            log.warning("translation_unparseable", run_id=self._run_id)
            return TranslationOutcome(
                language="und", is_english=True, translated_text=None, degraded=True
            )
        try:
            reply = _TranslationReply.model_validate(parsed)
        except ValidationError as exc:
            log.warning("translation_invalid_schema", run_id=self._run_id, error=str(exc))
            return TranslationOutcome(
                language="und", is_english=True, translated_text=None, degraded=True
            )

        language = (reply.language or "und").strip().lower()
        is_english = reply.is_english or language in {"en", "eng", "english"}
        return TranslationOutcome(
            language="en" if is_english else language,
            is_english=is_english,
            translated_text=None if is_english else reply.english_text,
        )
