"""Direct-SDK LLM client layer.

No LangChain wrappers: the ``openai`` and ``anthropic`` SDKs are used directly.
Retry/backoff and the typed degraded-state fallback live here; LangGraph only
orchestrates and never sees a raised provider error.
"""
