"""Unified LLM client: provider selection, retry/backoff, typed degraded fallback.

A call retries transient failures with full-jitter backoff. If every attempt is
exhausted (or the failure is non-transient) the client returns a typed
:class:`LLMFallbackResponse` rather than raising — downstream agents and the
LangGraph workflow treat it as a known degraded state and never see an exception.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Literal

import httpx
import structlog
from pydantic import BaseModel

from saw.config import ProviderName, Settings
from saw.llm.diagnostics import CallDiagnostic, RunDiagnostics
from saw.llm.providers import (
    AnthropicProvider,
    AzureOpenAIProvider,
    ChatMessage,
    LangDockProvider,
    Provider,
)
from saw.llm.retry import RetryPolicy, compute_delay, is_retryable

log = structlog.get_logger(__name__)

__all__ = ["ChatMessage", "LLMClient", "LLMFallbackResponse", "LLMResponse", "LLMResult"]


class LLMResponse(BaseModel):
    """A successful LLM completion."""

    is_fallback: Literal[False] = False
    provider: str
    model: str
    content: str
    tokens_in: int
    tokens_out: int
    finish_reason: str | None = None
    attempts: int


class LLMFallbackResponse(BaseModel):
    """Typed degraded result returned when a provider is unavailable.

    Downstream agents inspect ``is_fallback`` and degrade gracefully (lowering the
    confidence score, adding a reliability notice). This is never raised.
    """

    is_fallback: Literal[True] = True
    provider: str
    model: str
    reason: str
    attempts: int
    last_error: str
    content: str = ""


LLMResult = LLMResponse | LLMFallbackResponse


class LLMClient:
    """Retry-aware client over one or more provider adapters."""

    def __init__(
        self,
        settings: Settings,
        http_client: httpx.Client | None,
        *,
        providers: dict[str, Provider] | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._settings = settings
        self._policy = RetryPolicy(
            max_attempts=settings.llm_max_attempts,
            base_delay=settings.llm_base_delay_seconds,
            max_delay=settings.llm_max_delay_seconds,
        )
        self._sleep = sleep
        self._default: ProviderName = settings.llm_default_provider
        if providers is not None:
            self._providers = providers
        else:
            if http_client is None:
                raise ValueError("http_client is required unless providers are injected")
            self._providers = self._build_providers(settings, http_client)

    @staticmethod
    def _build_providers(
        settings: Settings, http_client: httpx.Client
    ) -> dict[str, Provider]:
        providers: dict[str, Provider] = {}
        if settings.azure_openai.is_configured:
            providers["azure_openai"] = AzureOpenAIProvider(settings.azure_openai, http_client)
        if settings.langdock.is_configured:
            providers["langdock"] = LangDockProvider(settings.langdock, http_client)
        if settings.anthropic.is_configured:
            providers["anthropic"] = AnthropicProvider(settings.anthropic, http_client)
        return providers

    @property
    def available_providers(self) -> list[str]:
        return sorted(self._providers)

    def _select(self, provider: ProviderName | None) -> Provider:
        name = provider or self._default
        if name not in self._providers:
            # A missing provider is a deployment/config error, not a runtime
            # provider failure — fail fast rather than degrading silently.
            raise ValueError(
                f"Provider {name!r} is not configured. "
                f"Available: {self.available_providers or '[]'}"
            )
        return self._providers[name]

    def complete(
        self,
        messages: list[ChatMessage],
        *,
        provider: ProviderName | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.0,
        run_id: str = "-",
        node: str = "-",
        diagnostics: RunDiagnostics | None = None,
    ) -> LLMResult:
        """Run a completion, retrying transient failures; never raises on failure."""
        prov = self._select(provider)
        start = time.monotonic()
        last_error = "no attempt was made"
        attempt = 0

        for attempt in range(self._policy.max_attempts):
            try:
                raw = prov.complete(
                    messages, max_tokens=max_tokens, temperature=temperature
                )
            except Exception as exc:  # classified below, then degraded to a typed value
                last_error = f"{type(exc).__name__}: {exc}"
                retryable = is_retryable(exc)
                log.warning(
                    "llm_call_failed",
                    run_id=run_id,
                    node=node,
                    provider=prov.name,
                    attempt=attempt + 1,
                    retryable=retryable,
                    error=last_error,
                )
                if not retryable or attempt == self._policy.max_attempts - 1:
                    break
                self._sleep(compute_delay(attempt, self._policy))
                continue

            duration_ms = (time.monotonic() - start) * 1000.0
            response = LLMResponse(
                provider=prov.name,
                model=raw.model,
                content=raw.content,
                tokens_in=raw.tokens_in,
                tokens_out=raw.tokens_out,
                finish_reason=raw.finish_reason,
                attempts=attempt + 1,
            )
            self._emit(
                diagnostics,
                CallDiagnostic(
                    run_id=run_id,
                    node=node,
                    provider=prov.name,
                    model=raw.model,
                    attempts=attempt + 1,
                    success=True,
                    tokens_in=raw.tokens_in,
                    tokens_out=raw.tokens_out,
                    duration_ms=duration_ms,
                ),
            )
            return response

        duration_ms = (time.monotonic() - start) * 1000.0
        log.error(
            "llm_fallback",
            run_id=run_id,
            node=node,
            provider=prov.name,
            attempts=attempt + 1,
            error=last_error,
        )
        self._emit(
            diagnostics,
            CallDiagnostic(
                run_id=run_id,
                node=node,
                provider=prov.name,
                model=prov.model,
                attempts=attempt + 1,
                success=False,
                is_fallback=True,
                duration_ms=duration_ms,
                error=last_error,
            ),
        )
        return LLMFallbackResponse(
            provider=prov.name,
            model=prov.model,
            reason="provider_unavailable",
            attempts=attempt + 1,
            last_error=last_error,
        )

    @staticmethod
    def _emit(diagnostics: RunDiagnostics | None, call: CallDiagnostic) -> None:
        if diagnostics is not None:
            diagnostics.record(call)
