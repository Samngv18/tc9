"""Assessment context — the business and technical framing the assessment is calibrated to.

The same questionnaire response can be a risk or a non-issue depending on what
the solution actually is. A fine-tuning question is irrelevant to a classical
ML/DL product; stringent personal-data controls are not required when no
personal data is processed. This context captures that framing so the
Assessment and Completeness & Quality agents can reason in it.
"""

from __future__ import annotations

from enum import StrEnum

from saw.schemas._base import StrictModel


class SolutionType(StrEnum):
    """The kind of AI solution being assessed."""

    ml_dl = "ml_dl"  # classical machine learning / deep learning
    llm = "llm"  # large language model based
    agentic = "agentic"  # autonomous, tool-using
    unknown = "unknown"


class ModelSourcing(StrEnum):
    """Where the solution's model(s) come from."""

    proprietary = "proprietary"
    open_source = "open_source"
    third_party_api = "third_party_api"
    mixed = "mixed"
    unknown = "unknown"


class PiiHandling(StrEnum):
    """Whether the solution processes personal data."""

    processes_pii = "processes_pii"
    no_pii = "no_pii"
    unknown = "unknown"


class AssessmentContext(StrictModel):
    """The context an assessment is calibrated against.

    Any field left ``unknown`` causes that aspect to be assessed without special
    calibration, so an undetermined context degrades to ordinary assessment.
    """

    solution_type: SolutionType = SolutionType.unknown
    business_use_case: str = "not determined"
    pii_handling: PiiHandling = PiiHandling.unknown
    uses_external_tools: bool = False
    model_sourcing: ModelSourcing = ModelSourcing.unknown
    # True: open-source/third-party model source named; False: used but not named;
    # None: not applicable (e.g. fully proprietary) or undetermined.
    open_source_models_identified: bool | None = None
    rationale: str = "assessment context was not determined"
