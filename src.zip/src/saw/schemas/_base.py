"""Shared base model for every schema."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class StrictModel(BaseModel):
    """Base model for every cross-boundary schema.

    ``extra="forbid"`` rejects unknown fields so a malformed or hallucinated dict
    never silently crosses an agent boundary.
    """

    model_config = ConfigDict(extra="forbid")
