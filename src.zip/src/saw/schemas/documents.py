"""Input document schemas: the primary questionnaire and supplemental context."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from saw.schemas._base import StrictModel


class DocumentFormat(StrEnum):
    """Supported input document formats.

    Primary questionnaires are ``xlsx`` or ``pdf``; ``txt`` covers plain-text and
    markdown supplemental documents.
    """

    xlsx = "xlsx"
    pdf = "pdf"
    txt = "txt"


class SourceDocument(StrictModel):
    """A primary input questionnaire file (XLSX or PDF)."""

    filename: str
    fmt: DocumentFormat
    byte_size: int
    sha256: str
    # storage-relative path where the raw bytes were persisted for traceability
    stored_path: str | None = None


class SupplementalDocument(StrictModel):
    """A single optional supporting document accompanying the questionnaire."""

    filename: str
    fmt: DocumentFormat
    extracted_text: str
    parse_warnings: list[str] = Field(default_factory=list)


class SupplementalContext(StrictModel):
    """Aggregated context extracted from all supplemental documents."""

    documents: list[SupplementalDocument] = Field(default_factory=list)
    combined_summary: str | None = None

    @property
    def is_empty(self) -> bool:
        return not self.documents
