"""Normalized questionnaire records emitted by the Reader agent."""

from __future__ import annotations

from pydantic import Field

from saw.schemas._base import StrictModel


class ParsedQuestionResponse(StrictModel):
    """One normalized question/answer row from a parsed questionnaire.

    Multi-language support: when the original answer is not English it is
    translated and stored in ``translated_text``; the original text and language
    are preserved for internal traceability only.
    """

    number: str
    question: str
    original_text: str
    # ISO 639-1 language code of the original answer ("en", "de", ...); "und" if undetermined.
    original_language: str = "en"
    # English translation, present only when the original answer is non-English.
    translated_text: str | None = None
    answered_by: str | None = None
    notes: str | None = None
    # row index in the source XLSX, for traceability back to the input
    source_row: int | None = None
    parse_warnings: list[str] = Field(default_factory=list)

    @property
    def is_translated(self) -> bool:
        return self.translated_text is not None

    @property
    def assessment_text(self) -> str:
        """Text the assessment operates on: the English translation when present."""
        return self.translated_text if self.translated_text is not None else self.original_text
