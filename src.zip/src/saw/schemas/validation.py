"""Completeness and validation schemas (Completeness & Quality agent, sub-steps a-c)."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from saw.schemas._base import StrictModel


class ValidationStatus(StrEnum):
    """Semantic adequacy outcome for a response. Eight context-aware statuses."""

    complete = "complete"
    sufficient = "sufficient"
    partial = "partial"
    incomplete = "incomplete"
    unclear = "unclear"
    not_applicable = "not_applicable"
    pending = "pending"
    offensive_or_unprofessional = "offensive_or_unprofessional"


class CompletenessState(StrEnum):
    """Structural/presence outcome for a response.

    ``not_applicable_with_reasoning`` and ``tbd_with_reasoning`` are valid
    completeness states — N/A and TBD with reasoning are not failures.
    """

    answered = "answered"
    not_applicable_with_reasoning = "not_applicable_with_reasoning"
    tbd_with_reasoning = "tbd_with_reasoning"
    blank = "blank"
    placeholder = "placeholder"


_COMPLETE_STATES = frozenset(
    {
        CompletenessState.answered,
        CompletenessState.not_applicable_with_reasoning,
        CompletenessState.tbd_with_reasoning,
    }
)


class CompletenessResult(StrictModel):
    """Sub-step (a): structural/presence check, distinct from semantic validation."""

    question_number: str
    structurally_present: bool
    state: CompletenessState
    reasoning: str

    @property
    def is_complete(self) -> bool:
        return self.state in _COMPLETE_STATES


UnprofessionalCategory = Literal[
    "frustration",
    "dismissive",
    "insult",
    "profanity",
    "sarcasm",
    "casual_venting",
    "other",
]


class UnprofessionalClassification(StrictModel):
    """Sub-step (b): flags language outside professional B2B disclosure norms.

    The offending excerpt is retained for the internal reliability notice only and
    is never echoed into the vendor-facing report.
    """

    question_number: str
    is_flagged: bool
    category: UnprofessionalCategory | None = None
    offending_excerpt_internal: str | None = None
    reasoning: str


class ValidationResult(StrictModel):
    """Sub-step (c): context-aware semantic adequacy of a response."""

    question_number: str
    status: ValidationStatus
    rationale: str
    # populated when the unprofessional classifier flagged the response
    unprofessional: UnprofessionalClassification | None = None
