"""Quality assessment schema (Completeness & Quality agent, sub-step d)."""

from __future__ import annotations

from enum import StrEnum

from saw.schemas._base import StrictModel


class QualityLevel(StrEnum):
    """Qualitative judgment level for a single quality dimension."""

    strong = "strong"
    adequate = "adequate"
    weak = "weak"
    not_assessable = "not_assessable"


class QualityDimension(StrictModel):
    """A single qualitative judgment: a level plus a short justification."""

    level: QualityLevel
    comment: str


class QualityAssessmentResult(StrictModel):
    """Sub-step (d): qualitative expert judgment across six dimensions.

    Deliberately qualitative — there is no numeric checklist scoring.
    """

    question_number: str
    clarity: QualityDimension
    relevance: QualityDimension
    sufficiency_of_detail: QualityDimension
    internal_consistency: QualityDimension
    architectural_relevance: QualityDimension
    practical_usefulness: QualityDimension
    overall_judgment: str
