"""Pydantic v2 schemas for every artifact crossing an agent boundary.

Every model derives from :class:`StrictModel` (``extra="forbid"``) so no untyped
or malformed dict passes silently between agents.
"""

from saw.schemas._base import StrictModel
from saw.schemas.assessment import (
    AssessmentResult,
    FrameworkAlignment,
    ResponseAssessment,
    RiskFinding,
    RiskSeverity,
)
from saw.schemas.confidence import (
    ConfidenceBand,
    ConfidenceFactors,
    ConfidenceScore,
    FactorAssessment,
    band_for_score,
)
from saw.schemas.context import (
    AssessmentContext,
    ModelSourcing,
    PiiHandling,
    SolutionType,
)
from saw.schemas.documents import (
    DocumentFormat,
    SourceDocument,
    SupplementalContext,
    SupplementalDocument,
)
from saw.schemas.frameworks import (
    ActiveVersionPointer,
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    SecurityFramework,
    SourceFormat,
)
from saw.schemas.quality import QualityAssessmentResult, QualityDimension, QualityLevel
from saw.schemas.records import ParsedQuestionResponse
from saw.schemas.report import (
    EXECUTIVE_SUMMARY_MAX_WORDS,
    FOLLOW_UP_MAX_WORDS,
    RISK_OBSERVATION_MAX_SENTENCES,
    FinalReport,
    FollowUpQuestion,
    LanguageSummary,
    ReliabilityNotice,
    TraceabilityRow,
)
from saw.schemas.validation import (
    CompletenessResult,
    CompletenessState,
    UnprofessionalCategory,
    UnprofessionalClassification,
    ValidationResult,
    ValidationStatus,
)

__all__ = [
    "EXECUTIVE_SUMMARY_MAX_WORDS",
    "FOLLOW_UP_MAX_WORDS",
    "RISK_OBSERVATION_MAX_SENTENCES",
    "ActiveVersionPointer",
    "AssessmentContext",
    "AssessmentResult",
    "CompletenessResult",
    "CompletenessState",
    "ConfidenceBand",
    "ConfidenceFactors",
    "ConfidenceScore",
    "DocumentFormat",
    "FactorAssessment",
    "FinalReport",
    "FollowUpQuestion",
    "FrameworkAlignment",
    "FrameworkControl",
    "FrameworkRegistrySnapshot",
    "FrameworkTier",
    "FrameworkVisibility",
    "LanguageSummary",
    "ModelSourcing",
    "ParsedQuestionResponse",
    "PiiHandling",
    "QualityAssessmentResult",
    "QualityDimension",
    "QualityLevel",
    "ReliabilityNotice",
    "ResponseAssessment",
    "RiskFinding",
    "RiskSeverity",
    "SecurityFramework",
    "SolutionType",
    "SourceDocument",
    "SourceFormat",
    "StrictModel",
    "SupplementalContext",
    "SupplementalDocument",
    "TraceabilityRow",
    "UnprofessionalCategory",
    "UnprofessionalClassification",
    "ValidationResult",
    "ValidationStatus",
    "band_for_score",
]
