"""Final report schema — the vendor-shareable assessment artifact."""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import Field

from saw.schemas._base import StrictModel
from saw.schemas.assessment import RiskSeverity
from saw.schemas.confidence import ConfidenceBand, ConfidenceScore

# Brevity limits (constraint #8). Enforced in the report prompts and asserted by
# tests; intentionally NOT raising validators here, so report generation always
# runs even if a section drifts over the limit.
EXECUTIVE_SUMMARY_MAX_WORDS = 200
FOLLOW_UP_MAX_WORDS = 25
RISK_OBSERVATION_MAX_SENTENCES = 3

# A run is treated as having "significant translation" at or above this share.
_SIGNIFICANT_TRANSLATION_RATIO = 0.25


class TraceabilityRow(StrictModel):
    """One row of the risk-summary table: question -> response -> risk -> follow-up.

    All fields are vendor-safe. ``risk_observation`` is <= 3 sentences.
    """

    question_number: str
    question: str
    response_excerpt: str
    risk_observation: str
    follow_up_question: str
    severity: RiskSeverity


class FollowUpQuestion(StrictModel):
    """A single vendor-safe follow-up question (<= 25 words, single question)."""

    number: int
    text: str


class LanguageSummary(StrictModel):
    """Appendix language summary. Language codes only — no original-language text."""

    total_responses: int
    translated_responses: int
    detected_languages: list[str] = Field(default_factory=list)

    @property
    def significant_translation(self) -> bool:
        if self.total_responses == 0:
            return False
        return self.translated_responses / self.total_responses >= _SIGNIFICANT_TRANSLATION_RATIO


class ReliabilityNotice(StrictModel):
    """Confidence band, rationale, and a prominent notice when reliability is reduced."""

    confidence_band: ConfidenceBand
    rationale: str
    has_unprofessional_responses: bool = False
    low_confidence: bool = False
    significant_translation: bool = False
    notice_text: str = ""

    @property
    def is_prominent(self) -> bool:
        return (
            self.has_unprofessional_responses
            or self.low_confidence
            or self.significant_translation
        )


class FinalReport(StrictModel):
    """The vendor-shareable assessment report.

    Contains only vendor-safe content; every section additionally passes through
    the ``vendor_safe_filter`` before persistence (Phase 7).
    """

    run_id: str
    vendor_name: str
    generated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    executive_summary: str
    confidence: ConfidenceScore
    reliability_notice: ReliabilityNotice
    risk_summary: list[TraceabilityRow] = Field(default_factory=list)
    follow_up_questions: list[FollowUpQuestion] = Field(default_factory=list)
    parse_warnings: list[str] = Field(default_factory=list)
    language_summary: LanguageSummary
