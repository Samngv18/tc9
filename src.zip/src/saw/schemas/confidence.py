"""Confidence score schema (Confidence agent)."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, model_validator

from saw.schemas._base import StrictModel


class ConfidenceBand(StrEnum):
    """Coarse confidence band derived from the numeric score."""

    low = "low"
    medium = "medium"
    high = "high"


class FactorAssessment(StrEnum):
    """Qualitative assessment of a single confidence factor."""

    strong = "strong"
    adequate = "adequate"
    weak = "weak"


# Score thresholds: low [0.0, 0.5), medium [0.5, 0.8), high [0.8, 1.0].
_LOW_CEILING = 0.5
_HIGH_FLOOR = 0.8


def band_for_score(score: float) -> ConfidenceBand:
    """Map a numeric confidence score to its band."""
    if score < _LOW_CEILING:
        return ConfidenceBand.low
    if score < _HIGH_FLOOR:
        return ConfidenceBand.medium
    return ConfidenceBand.high


class ConfidenceFactors(StrictModel):
    """The inputs the confidence score is synthesized from."""

    parse_completeness: FactorAssessment
    response_quality: FactorAssessment
    internal_consistency: FactorAssessment
    framework_coverage: FactorAssessment
    unprofessional_content_present: bool
    translated_content_present: bool


class ConfidenceScore(StrictModel):
    """Reliability of the assessment's conclusions, not just data completeness.

    ``band`` is always derived from ``score``; any value passed in is overridden.
    """

    score: float = Field(ge=0.0, le=1.0)
    band: ConfidenceBand = ConfidenceBand.low
    rationale: str
    factors: ConfidenceFactors

    @model_validator(mode="after")
    def _derive_band(self) -> ConfidenceScore:
        self.band = band_for_score(self.score)
        return self
