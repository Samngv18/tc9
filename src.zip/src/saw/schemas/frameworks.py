"""Framework registry data models.

These are the *data* schemas. The stateful, event-reloaded ``FrameworkRegistry``
singleton (Phase 4) lives in ``saw.frameworks.registry`` and hands out an
immutable :class:`FrameworkRegistrySnapshot`.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum

from pydantic import Field

from saw.schemas._base import StrictModel


class FrameworkTier(StrEnum):
    """Assessment weight tier. Primary frameworks weigh more than secondary."""

    primary = "primary"
    secondary = "secondary"


class FrameworkVisibility(StrEnum):
    """Whether a framework is public or company-internal IP."""

    public = "public"
    internal = "internal"


class SourceFormat(StrEnum):
    """Format of the stored source artifact for a framework version."""

    pdf = "pdf"
    json = "json"


class FrameworkControl(StrictModel):
    """A single control / risk item within a framework."""

    control_id: str
    title: str
    description: str
    category: str | None = None


class SecurityFramework(StrictModel):
    """A versioned framework: metadata plus LLM-extracted structured controls."""

    name: str
    tier: FrameworkTier
    visibility: FrameworkVisibility
    version: str
    source_artifact_hash: str
    source_format: SourceFormat
    extracted_controls: list[FrameworkControl] = Field(default_factory=list)
    uploaded_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ActiveVersionPointer(StrictModel):
    """Contents of a framework's ``active.json`` pointer file."""

    active_version: str


class FrameworkRegistrySnapshot(StrictModel):
    """Immutable view of the active framework set at a point in time."""

    loaded_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    frameworks: list[SecurityFramework] = Field(default_factory=list)

    @property
    def primary(self) -> list[SecurityFramework]:
        return [f for f in self.frameworks if f.tier is FrameworkTier.primary]

    @property
    def secondary(self) -> list[SecurityFramework]:
        return [f for f in self.frameworks if f.tier is FrameworkTier.secondary]
