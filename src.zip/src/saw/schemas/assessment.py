"""Security assessment schemas: risk findings and their aggregates."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import Field

from saw.schemas._base import StrictModel


class RiskSeverity(StrEnum):
    """Severity of a risk finding. Bound to report color coding in Phase 7."""

    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"
    informational = "informational"


class FrameworkAlignment(StrictModel):
    """Internal-only: the framework controls a finding aligns to.

    Company IP. Never rendered in the vendor-facing report.
    """

    framework_name: str
    framework_tier: Literal["primary", "secondary"]
    control_ids: list[str] = Field(default_factory=list)
    note: str = ""


class RiskFinding(StrictModel):
    """A single risk finding for one response.

    Internal fields carry framework/control traceability (company IP). Vendor-safe
    fields use plain security language only. The ``vendor_safe_filter`` operates on
    the vendor-safe fields; internal fields never reach the report.
    """

    question_number: str
    severity: RiskSeverity

    # --- internal-only (never rendered in the vendor report) ---
    risk_observation_internal: str
    framework_alignment_internal: list[FrameworkAlignment] = Field(default_factory=list)
    original_response_excerpt: str

    # --- vendor-safe (plain security language; pass through vendor_safe_filter) ---
    risk_observation_vendor_safe: str
    vendor_safe_follow_up: str


class ResponseAssessment(StrictModel):
    """The assessment of one response: findings plus contextual reasoning.

    Non-compliance with any single framework is not an automatic failure — the
    contextual reasoning records why the agent reached its conclusion.
    """

    question_number: str
    findings: list[RiskFinding] = Field(default_factory=list)
    contextual_reasoning: str
    no_material_risk: bool = False


class AssessmentResult(StrictModel):
    """Run-level aggregate of every response assessment."""

    run_id: str
    response_assessments: list[ResponseAssessment] = Field(default_factory=list)

    @property
    def all_findings(self) -> list[RiskFinding]:
        return [f for ra in self.response_assessments for f in ra.findings]
