"""Shared header detection and row extraction for tabular questionnaires.

Both the XLSX and PDF parsers feed rows through this module, so column-order
changes and alternate header spellings are tolerated uniformly.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from pydantic import Field

from saw.schemas import ParsedQuestionResponse, StrictModel

# Canonical column name -> accepted (normalized) header aliases.
_COLUMN_ALIASES: dict[str, frozenset[str]] = {
    "number": frozenset(
        {"no", "no.", "number", "num", "#", "q", "qno", "q no", "question no",
         "question number", "item", "id", "ref"}
    ),
    "answered_by": frozenset(
        {"answered by", "answeredby", "respondent", "owner", "answered", "completed by",
         "author", "responder"}
    ),
    "question": frozenset({"question", "questions", "control question", "query", "ask"}),
    "answer": frozenset(
        {"answer", "answers", "response", "responses", "vendor response", "vendor answer",
         "reply"}
    ),
    "notes": frozenset({"notes", "note", "comments", "comment", "remarks", "remark"}),
}

# A row needs at least these mapped columns to carry meaning.
_REQUIRED_COLUMNS = ("question", "answer")
# Every column we attempt to map; absences are reported as warnings.
_ALL_COLUMNS = ("number", "answered_by", "question", "answer", "notes")


class QuestionnaireParseResult(StrictModel):
    """Output of a questionnaire parser: normalized records plus document warnings."""

    source_filename: str
    records: list[ParsedQuestionResponse] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    detected_sheet: str | None = None


@dataclass
class ColumnMap:
    """Maps canonical column names to their column index in a detected header row."""

    indices: dict[str, int]
    header_row_index: int  # zero-based index of the header row within the scanned rows

    @property
    def has_minimum(self) -> bool:
        return all(col in self.indices for col in _REQUIRED_COLUMNS)


def normalize_header(value: object) -> str:
    """Normalize a header cell for alias matching: lowercased, de-punctuated."""
    text = str(value if value is not None else "").strip().lower()
    text = text.replace("_", " ").replace("-", " ").replace("/", " ")
    text = " ".join(text.split())
    return text.rstrip(":").strip()


def _cell_value(row: Sequence[object], idx: int | None) -> str:
    if idx is None or idx < 0 or idx >= len(row):
        return ""
    value = row[idx]
    return str(value).strip() if value is not None else ""


def detect_columns(
    rows: Sequence[Sequence[object]], *, max_scan: int = 15
) -> ColumnMap | None:
    """Scan the leading rows for a header row and map known columns by alias.

    Returns the candidate header row with the most matched columns (at least two),
    so column order and a non-first header row are both tolerated. Returns ``None``
    when no row resembles a header.
    """
    best: ColumnMap | None = None
    for row_idx, row in enumerate(rows[:max_scan]):
        indices: dict[str, int] = {}
        for col_idx, cell in enumerate(row):
            header = normalize_header(cell)
            if not header:
                continue
            for canonical, aliases in _COLUMN_ALIASES.items():
                if canonical not in indices and header in aliases:
                    indices[canonical] = col_idx
        if len(indices) >= 2 and (best is None or len(indices) > len(best.indices)):
            best = ColumnMap(indices=indices, header_row_index=row_idx)
    return best


def missing_column_warnings(column_map: ColumnMap) -> list[str]:
    """Return a warning for each expected column absent from the detected header."""
    return [
        f"column '{col}' was not found in the questionnaire header"
        for col in _ALL_COLUMNS
        if col not in column_map.indices
    ]


def rows_to_records(
    rows: Sequence[Sequence[object]], column_map: ColumnMap
) -> list[ParsedQuestionResponse]:
    """Convert data rows below the header into normalized question/response records."""
    indices = column_map.indices
    records: list[ParsedQuestionResponse] = []
    sequence = 0
    for row_idx in range(column_map.header_row_index + 1, len(rows)):
        row = rows[row_idx]
        question = _cell_value(row, indices.get("question"))
        answer = _cell_value(row, indices.get("answer"))
        if not question and not answer:
            continue  # blank spacer row
        sequence += 1
        row_warnings: list[str] = []
        if not question:
            row_warnings.append("row has a response but no question text")
        if not answer:
            row_warnings.append("question has no response text")
        records.append(
            ParsedQuestionResponse(
                number=_cell_value(row, indices.get("number")) or str(sequence),
                question=question or "(question text missing)",
                original_text=answer,
                answered_by=_cell_value(row, indices.get("answered_by")) or None,
                notes=_cell_value(row, indices.get("notes")) or None,
                source_row=row_idx + 1,  # 1-based, for human-readable traceability
                parse_warnings=row_warnings,
            )
        )
    return records
