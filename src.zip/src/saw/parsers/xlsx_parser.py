"""XLSX questionnaire parser (openpyxl).

Tolerates column-order changes and a header row that is not the first row. Only
the No / Answered_By / Question / Answer / Notes columns are read; everything
else is ignored. Failures degrade into ``warnings`` rather than raising.
"""

from __future__ import annotations

from io import BytesIO

import openpyxl
import structlog

from saw.parsers._tables import (
    QuestionnaireParseResult,
    detect_columns,
    missing_column_warnings,
    rows_to_records,
)
from saw.schemas import ParsedQuestionResponse

log = structlog.get_logger(__name__)


def parse_xlsx(data: bytes, *, filename: str) -> QuestionnaireParseResult:
    """Parse an XLSX questionnaire into normalized records.

    Every worksheet is scanned; the sheet yielding the most records wins.
    """
    warnings: list[str] = []
    try:
        workbook = openpyxl.load_workbook(BytesIO(data), read_only=True, data_only=True)
    except Exception as exc:  # corrupt/unsupported file — degrade gracefully
        log.warning("xlsx_open_failed", filename=filename, error=str(exc))
        warnings.append(f"could not open XLSX file: {exc}")
        return QuestionnaireParseResult(source_filename=filename, warnings=warnings)

    best_records: list[ParsedQuestionResponse] = []
    best_warnings: list[str] = []
    chosen_sheet: str | None = None
    try:
        for sheet in workbook.worksheets:
            rows = [list(row) for row in sheet.iter_rows(values_only=True)]
            column_map = detect_columns(rows)
            if column_map is None:
                continue
            records = rows_to_records(rows, column_map)
            if chosen_sheet is None or len(records) > len(best_records):
                best_records = records
                best_warnings = missing_column_warnings(column_map)
                if column_map.header_row_index > 0:
                    best_warnings.insert(
                        0,
                        f"header row was found at row {column_map.header_row_index + 1}, "
                        "not the first row",
                    )
                chosen_sheet = sheet.title
    finally:
        workbook.close()

    if chosen_sheet is None:
        warnings.append("no recognizable question/response table was found in any sheet")
        return QuestionnaireParseResult(source_filename=filename, warnings=warnings)

    warnings.extend(best_warnings)
    if not best_records:
        warnings.append("a question table was detected but it contained no data rows")
    log.info(
        "xlsx_parsed",
        filename=filename,
        sheet=chosen_sheet,
        records=len(best_records),
        warnings=len(warnings),
    )
    return QuestionnaireParseResult(
        source_filename=filename,
        records=best_records,
        warnings=warnings,
        detected_sheet=chosen_sheet,
    )
