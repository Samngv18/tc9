"""Document parsers for questionnaires and supplemental context.

Public entry points:
  * :func:`parse_xlsx` / :func:`parse_pdf` -> :class:`QuestionnaireParseResult`
  * :func:`parse_supplemental_documents` -> :class:`SupplementalContext`
  * :func:`infer_vendor_name` -> sanitized vendor name from an input filename
"""

from __future__ import annotations

import re

from saw.parsers._tables import QuestionnaireParseResult
from saw.parsers.pdf_parser import parse_pdf
from saw.parsers.supplemental import parse_supplemental_document, parse_supplemental_documents
from saw.parsers.xlsx_parser import parse_xlsx

# Filename tokens that describe the document, not the vendor.
_VENDOR_NOISE = frozenset(
    {
        "security", "questionnaire", "questionnaires", "assessment", "assessments",
        "response", "responses", "answered", "answers", "vendor", "ai", "artificial",
        "intelligence", "review", "form", "completed", "filled", "final", "draft",
        "copy", "the", "and", "llm", "genai", "survey",
    }
)
_YEAR = re.compile(r"^(?:19|20)\d{2}$")
_VERSION = re.compile(r"^v?\d+(?:\.\d+)*$")


def infer_vendor_name(filename: str) -> str:
    """Best-effort vendor name from an input filename, sanitized for display."""
    stem = filename.rsplit("/", 1)[-1]
    if "." in stem:
        stem = stem.rsplit(".", 1)[0]
    tokens = [t for t in re.split(r"[\s_\-.]+", stem) if t]
    kept = [
        token
        for token in tokens
        if token.lower() not in _VENDOR_NOISE
        and not _YEAR.match(token)
        and not _VERSION.match(token.lower())
    ]
    if not kept:
        return "Vendor"
    return " ".join(word if word.isupper() else word.capitalize() for word in kept)


__all__ = [
    "QuestionnaireParseResult",
    "infer_vendor_name",
    "parse_pdf",
    "parse_supplemental_document",
    "parse_supplemental_documents",
    "parse_xlsx",
]
