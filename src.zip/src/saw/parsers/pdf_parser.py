"""PDF questionnaire parser (pdfplumber).

Extracts tabular question/response data and records a warning when text
extraction yields suspiciously little content (a likely scanned/image PDF).
Failures degrade into ``warnings`` rather than raising.
"""

from __future__ import annotations

from collections.abc import Sequence
from io import BytesIO

import pdfplumber
import structlog

from saw.parsers._tables import (
    QuestionnaireParseResult,
    detect_columns,
    missing_column_warnings,
    rows_to_records,
)
from saw.schemas import ParsedQuestionResponse

log = structlog.get_logger(__name__)

# Below this average number of extracted characters per page, a PDF most likely
# needs OCR (it is scanned/image-based).
_LOW_TEXT_CHARS_PER_PAGE = 40


def parse_pdf(data: bytes, *, filename: str) -> QuestionnaireParseResult:
    """Parse a PDF questionnaire into normalized records."""
    warnings: list[str] = []
    tables: list[Sequence[Sequence[object]]] = []
    total_text_chars = 0
    page_count = 0

    try:
        with pdfplumber.open(BytesIO(data)) as pdf:
            page_count = len(pdf.pages)
            for page in pdf.pages:
                total_text_chars += len(page.extract_text() or "")
                for table in page.extract_tables() or []:
                    tables.append([list(row) for row in table])
    except Exception as exc:  # corrupt/unsupported file — degrade gracefully
        log.warning("pdf_open_failed", filename=filename, error=str(exc))
        warnings.append(f"could not open PDF file: {exc}")
        return QuestionnaireParseResult(source_filename=filename, warnings=warnings)

    if page_count > 0 and total_text_chars < _LOW_TEXT_CHARS_PER_PAGE * page_count:
        warnings.append(
            f"low text yield ({total_text_chars} characters across {page_count} page(s)); "
            "the PDF may be scanned or image-based and require OCR"
        )

    best_records: list[ParsedQuestionResponse] = []
    best_warnings: list[str] = []
    for candidate in tables:
        column_map = detect_columns(candidate)
        if column_map is None:
            continue
        records = rows_to_records(candidate, column_map)
        if len(records) > len(best_records):
            best_records = records
            best_warnings = missing_column_warnings(column_map)

    if not best_records:
        warnings.append("no structured question/response table was detected in the PDF")
    else:
        warnings.extend(best_warnings)

    log.info(
        "pdf_parsed",
        filename=filename,
        pages=page_count,
        records=len(best_records),
        warnings=len(warnings),
    )
    return QuestionnaireParseResult(
        source_filename=filename, records=best_records, warnings=warnings
    )
