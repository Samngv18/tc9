"""Supplemental document parser.

Extracts text from optional supporting documents (PDF, XLSX, plain text /
markdown) into a :class:`SupplementalContext`. Failures degrade into per-document
``parse_warnings`` rather than raising.
"""

from __future__ import annotations

from io import BytesIO

import openpyxl
import pdfplumber
import structlog

from saw.schemas import DocumentFormat, SupplementalContext, SupplementalDocument

log = structlog.get_logger(__name__)

_PDF_EXTENSIONS = {"pdf"}
_XLSX_EXTENSIONS = {"xlsx", "xlsm"}
_TEXT_EXTENSIONS = {"txt", "md", "markdown", "csv", "text", "log"}


def _extension(filename: str) -> str:
    name = filename.rsplit("/", 1)[-1]
    return name.rsplit(".", 1)[-1].lower() if "." in name else ""


def _extract_pdf_text(data: bytes) -> tuple[str, list[str]]:
    warnings: list[str] = []
    parts: list[str] = []
    try:
        with pdfplumber.open(BytesIO(data)) as pdf:
            for page in pdf.pages:
                parts.append(page.extract_text() or "")
    except Exception as exc:
        warnings.append(f"could not extract PDF text: {exc}")
    text = "\n".join(parts).strip()
    if not text and not warnings:
        warnings.append("no extractable text (the PDF may be scanned or image-based)")
    return text, warnings


def _extract_xlsx_text(data: bytes) -> tuple[str, list[str]]:
    warnings: list[str] = []
    parts: list[str] = []
    try:
        workbook = openpyxl.load_workbook(BytesIO(data), read_only=True, data_only=True)
        try:
            for sheet in workbook.worksheets:
                for row in sheet.iter_rows(values_only=True):
                    cells = [str(c).strip() for c in row if c is not None and str(c).strip()]
                    if cells:
                        parts.append(" | ".join(cells))
        finally:
            workbook.close()
    except Exception as exc:
        warnings.append(f"could not extract XLSX text: {exc}")
    return "\n".join(parts).strip(), warnings


def _extract_plain_text(data: bytes) -> tuple[str, list[str]]:
    text = data.decode("utf-8", errors="replace").strip()
    warnings = ["file contained undecodable bytes"] if "�" in text else []
    return text, warnings


def parse_supplemental_document(data: bytes, *, filename: str) -> SupplementalDocument:
    """Parse one supplemental document, selecting the extractor by file extension."""
    ext = _extension(filename)
    if ext in _PDF_EXTENSIONS:
        fmt = DocumentFormat.pdf
        text, warnings = _extract_pdf_text(data)
    elif ext in _XLSX_EXTENSIONS:
        fmt = DocumentFormat.xlsx
        text, warnings = _extract_xlsx_text(data)
    elif ext in _TEXT_EXTENSIONS:
        fmt = DocumentFormat.txt
        text, warnings = _extract_plain_text(data)
    else:
        fmt = DocumentFormat.txt
        text = ""
        warnings = [f"unsupported supplemental document format '{ext or 'unknown'}'; not parsed"]

    log.info(
        "supplemental_parsed", filename=filename, fmt=fmt, chars=len(text), warnings=len(warnings)
    )
    return SupplementalDocument(
        filename=filename, fmt=fmt, extracted_text=text, parse_warnings=warnings
    )


def parse_supplemental_documents(files: list[tuple[str, bytes]]) -> SupplementalContext:
    """Parse a list of ``(filename, bytes)`` pairs into a :class:`SupplementalContext`."""
    documents = [
        parse_supplemental_document(data, filename=name) for name, data in files
    ]
    return SupplementalContext(documents=documents)
