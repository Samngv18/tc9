"""security-assessment-workflow.

Multi-agent pipeline that assesses vendor AI security questionnaire responses and
produces a concise, vendor-shareable PDF report with traceable risk findings.
"""

__version__ = "0.1.0"
