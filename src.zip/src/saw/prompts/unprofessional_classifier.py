"""Prompt fragment for the unprofessional-language classifier (sub-step b)."""

from __future__ import annotations


def unprofessional_instructions() -> str:
    """Instruction block for flagging language outside B2B disclosure norms."""
    return (
        "TASK 1 — UNPROFESSIONAL CLASSIFICATION:\n"
        "Professional B2B security disclosure uses neutral, factual, "
        "business-appropriate language. Flag the response if it contains anything "
        "outside that norm, including: frustration ('this is a dumb question', "
        "'why are you asking this', 'ridiculous'), dismissive language, insults, "
        "profanity, sarcasm directed at the asker, or casual venting.\n"
        "If flagged, name the category (one of: frustration, dismissive, insult, "
        "profanity, sarcasm, casual_venting, other) and quote the offending phrase "
        "verbatim in offending_excerpt.\n"
        "A neutral 'N/A', a terse answer, or an admission of a gap is NOT "
        "unprofessional — only the tone and language are judged here."
    )
