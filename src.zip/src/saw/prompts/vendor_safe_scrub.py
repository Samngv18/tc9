"""Prompt for the LLM-based vendor-safe scrub pass (defense-in-depth)."""

from __future__ import annotations


def vendor_safe_scrub_system_prompt() -> str:
    """System prompt for rewriting a report snippet free of framework references."""
    return (
        "You rewrite a snippet of a vendor security assessment report so it is safe "
        "to share with the vendor.\n"
        "Remove every reference to any security framework, methodology, or standard "
        "by name; every framework control identifier; and any internal terminology. "
        "Describe the security issue directly, in plain language, instead.\n"
        "Preserve the original meaning and keep it concise. Do not add new "
        "information or commentary.\n"
        'Respond with ONLY a JSON object: {"text": "<rewritten text>"}'
    )


def vendor_safe_scrub_user_prompt(text: str) -> str:
    """User prompt carrying the snippet to rewrite."""
    return f"Text to rewrite:\n\n{text}"
