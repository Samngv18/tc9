"""Prompt for profiling the assessment context."""

from __future__ import annotations


def context_profile_system_prompt() -> str:
    """System prompt for inferring the assessment context from the responses."""
    return (
        "You profile the context of a vendor's AI solution from its security "
        "questionnaire responses and any supporting documents. This context "
        "calibrates how strictly later questions are assessed.\n"
        "Determine each field:\n"
        "- solution_type: 'ml_dl' (classical machine learning or deep learning), "
        "'llm' (large language model based), 'agentic' (autonomous, tool-using), or "
        "'unknown'.\n"
        "- business_use_case: a short phrase describing what the solution does.\n"
        "- pii_handling: 'processes_pii', 'no_pii', or 'unknown'.\n"
        "- uses_external_tools: true if the system calls external tools or APIs.\n"
        "- model_sourcing: 'proprietary', 'open_source', 'third_party_api', "
        "'mixed', or 'unknown'.\n"
        "- open_source_models_identified: when open-source or third-party models "
        "are used, true if their specific source or provider is named, false if it "
        "is not; null when not applicable or undetermined.\n"
        "- rationale: one or two sentences explaining the profile.\n"
        "Base every field strictly on what the responses and documents state; use "
        "'unknown' or null rather than guessing.\n"
        'Respond with ONLY a JSON object: {"solution_type": "...", '
        '"business_use_case": "...", "pii_handling": "...", '
        '"uses_external_tools": <bool>, "model_sourcing": "...", '
        '"open_source_models_identified": <true|false|null>, "rationale": "..."}'
    )


def context_profile_user_prompt(responses_text: str, supplemental_text: str) -> str:
    """User prompt carrying the questionnaire responses and supporting documents."""
    return (
        f"Questionnaire responses:\n{responses_text}\n\n"
        f"Supporting documents:\n{supplemental_text}"
    )
