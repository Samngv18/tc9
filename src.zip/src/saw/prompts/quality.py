"""Prompts for the quality node (Completeness & Quality agent, sub-steps b+c+d).

The quality node runs the unprofessional classifier, validation, and quality
assessment in a single LLM call; this module composes the three instruction
blocks into one prompt.
"""

from __future__ import annotations

from saw.prompts.unprofessional_classifier import unprofessional_instructions
from saw.prompts.validation import validation_instructions


def quality_instructions() -> str:
    """Instruction block for qualitative quality assessment (no numeric scoring)."""
    return (
        "TASK 3 — QUALITY ASSESSMENT (qualitative expert judgment, no numeric "
        "scoring):\n"
        "Judge the response across six dimensions. Rate each strong, adequate, "
        "weak, or not_assessable, with a brief comment:\n"
        "- clarity: clearly written and unambiguous?\n"
        "- relevance: addresses what was actually asked?\n"
        "- sufficiency_of_detail: enough specific detail to be meaningful?\n"
        "- internal_consistency: self-consistent, no contradictions?\n"
        "- architectural_relevance: reflects real architectural or technical "
        "substance?\n"
        "- practical_usefulness: useful for assessing security risk?"
    )


def quality_node_system_prompt() -> str:
    """Composed system prompt for the combined b+c+d quality-node LLM call."""
    return (
        "You analyze a single vendor security questionnaire response and perform "
        "three tasks.\n\n"
        f"{unprofessional_instructions()}\n\n"
        f"{validation_instructions()}\n\n"
        f"{quality_instructions()}\n\n"
        "An ASSESSMENT CONTEXT is provided with the response. Treat a reply of N/A "
        "or 'not applicable' as the valid `not_applicable` status (not "
        "`incomplete`) when the context makes the question genuinely inapplicable "
        "— for example a fine-tuning question for a classical ML/DL solution, or a "
        "personal-data question when the vendor processes no personal data.\n\n"
        "Respond with ONLY a JSON object in exactly this shape:\n"
        '{"unprofessional": {"is_flagged": <bool>, "category": "<category or null>",'
        ' "offending_excerpt": "<verbatim phrase or null>", '
        '"reasoning": "<one sentence>"},'
        ' "validation": {"status": "<status>", "rationale": "<one sentence>"},'
        ' "quality": {"clarity": {"level": "<level>", "comment": "<text>"},'
        ' "relevance": {"level": "<level>", "comment": "<text>"},'
        ' "sufficiency_of_detail": {"level": "<level>", "comment": "<text>"},'
        ' "internal_consistency": {"level": "<level>", "comment": "<text>"},'
        ' "architectural_relevance": {"level": "<level>", "comment": "<text>"},'
        ' "practical_usefulness": {"level": "<level>", "comment": "<text>"},'
        ' "overall_judgment": "<one sentence>"}}'
    )


def quality_node_user_prompt(
    question: str, response: str, completeness_state: str, context_text: str
) -> str:
    """User prompt carrying context, question, response, and prior completeness state."""
    return (
        f"Assessment context:\n{context_text}\n\n"
        f"Question:\n{question}\n\n"
        f"Vendor response:\n{response}\n\n"
        f"Completeness state already determined: {completeness_state}"
    )
