"""Prompts for consolidating vendor follow-up questions (Report agent)."""

from __future__ import annotations


def follow_up_system_prompt() -> str:
    """System prompt for merging draft follow-ups into a final vendor-safe list."""
    return (
        "You consolidate draft follow-up questions for a vendor security "
        "assessment report into a final list.\n"
        "Rules:\n"
        "- Merge duplicate and near-duplicate questions.\n"
        "- Each question must be a SINGLE question, 25 words or fewer (no compound "
        "asks).\n"
        "- Use plain security language only: no framework names, no control "
        "identifiers, no internal terminology.\n"
        "- Keep questions specific, answerable, and ordered by importance.\n"
        'Respond with ONLY a JSON object: {"questions": ["<question>", ...]}'
    )


def follow_up_user_prompt(draft_questions: list[str]) -> str:
    """User prompt carrying the draft follow-up questions to consolidate."""
    joined = "\n".join(f"- {question}" for question in draft_questions)
    return f"Draft follow-up questions:\n{joined}"
