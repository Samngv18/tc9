"""Prompts for the Confidence agent's rationale."""

from __future__ import annotations


def confidence_rationale_system_prompt() -> str:
    """System prompt for writing the confidence-score rationale."""
    return (
        "You write a brief rationale explaining a vendor security assessment's "
        "confidence score.\n"
        "The numeric score, its band, and the contributing factors are provided. "
        "Write two to three sentences, in plain language, explaining why confidence "
        "sits at this level and what most affects it.\n"
        "Do not mention framework names, control identifiers, or internal "
        "terminology.\n"
        'Respond with ONLY a JSON object: {"rationale": "<two to three sentences>"}'
    )


def confidence_rationale_user_prompt(
    score: float, band: str, factors: dict[str, str]
) -> str:
    """User prompt carrying the score, band, and contributing factors."""
    lines = "\n".join(f"- {name}: {value}" for name, value in factors.items())
    return f"Confidence score: {score:.2f} (band: {band})\nContributing factors:\n{lines}"
