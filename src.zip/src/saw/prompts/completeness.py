"""Prompts for the completeness check (Completeness & Quality agent, sub-step a)."""

from __future__ import annotations


def completeness_system_prompt() -> str:
    """System prompt for classifying the structural completeness of a response."""
    return (
        "You assess the COMPLETENESS of a single vendor security questionnaire "
        "response — whether a real answer is present, not whether it is a good "
        "answer.\n"
        "Classify the response into exactly one state:\n"
        "- answered: a substantive answer is present.\n"
        "- not_applicable_with_reasoning: the vendor states it does not apply AND "
        "gives a reason.\n"
        "- tbd_with_reasoning: the vendor states it is pending or to-be-determined "
        "AND gives context.\n"
        "- placeholder: filler with no real content (e.g. 'TODO', 'xxx', '...'), "
        "or a bare 'N/A' / 'TBD' with no reasoning.\n"
        "- blank: empty or whitespace only.\n"
        "N/A and TBD WITH reasoning are valid, complete states — not failures.\n"
        "Also report structurally_present: whether any answer text exists at all.\n"
        'Respond with ONLY a JSON object: {"structurally_present": <bool>, '
        '"state": "<state>", "reasoning": "<one sentence>"}'
    )


def completeness_user_prompt(question: str, response: str) -> str:
    """User prompt carrying the question and the vendor's response."""
    return f"Question:\n{question}\n\nVendor response:\n{response}"
