"""Prompts for the Report agent's executive summary."""

from __future__ import annotations


def executive_summary_system_prompt() -> str:
    """System prompt for writing the report's executive summary."""
    return (
        "You write the executive summary of a vendor AI security assessment "
        "report.\n"
        "Constraints:\n"
        "- 200 words maximum.\n"
        "- Plain security language describing the vendor's overall risk posture.\n"
        "- No framework names, no control identifiers, no internal terminology.\n"
        "- Factual and measured in tone; this report is shared with the vendor.\n"
        'Respond with ONLY a JSON object: {"executive_summary": "<=200 words"}'
    )


def executive_summary_user_prompt(
    vendor_name: str,
    confidence_band: str,
    severity_counts: dict[str, int],
    risk_themes: list[str],
) -> str:
    """User prompt carrying the inputs the executive summary is built from."""
    counts = ", ".join(f"{count} {severity}" for severity, count in severity_counts.items())
    themes = "\n".join(f"- {theme}" for theme in risk_themes) or "- (no findings)"
    return (
        f"Vendor: {vendor_name}\n"
        f"Assessment confidence: {confidence_band}\n"
        f"Risk findings by severity: {counts or 'none'}\n"
        f"Key risk observations:\n{themes}"
    )
