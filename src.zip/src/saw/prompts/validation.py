"""Prompt fragment for context-aware response validation (sub-step c)."""

from __future__ import annotations


def validation_instructions() -> str:
    """Instruction block for judging the semantic adequacy of a response."""
    return (
        "TASK 2 — VALIDATION (semantic adequacy):\n"
        "Judge whether the response adequately answers the question, in context. "
        "Choose exactly one status:\n"
        "- complete: fully and clearly answers the question.\n"
        "- sufficient: adequately answers it, though not exhaustively.\n"
        "- partial: answers only part of the question.\n"
        "- incomplete: does not meaningfully answer the question.\n"
        "- unclear: too vague or ambiguous to interpret.\n"
        "- not_applicable: the question genuinely does not apply and a valid reason "
        "is given — this is a valid outcome, NOT a failure.\n"
        "- pending: the answer is legitimately to-be-determined, with context.\n"
        "Be context-aware: 'N/A - we do not process PII' is not_applicable, not "
        "incomplete. Non-compliance described honestly is still a valid answer."
    )
