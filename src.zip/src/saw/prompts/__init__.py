"""Prompt builders.

Every prompt is a pure function that returns a string. Agents import these and
never embed prompt text inline.
"""
