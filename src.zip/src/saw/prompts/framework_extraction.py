"""Prompts for extracting structured controls from a framework PDF."""

from __future__ import annotations


def framework_extraction_system_prompt() -> str:
    """System prompt for extracting framework controls as structured JSON."""
    return (
        "You extract structured security controls from a security framework "
        "document.\n"
        "Read the provided document text and identify every distinct control, risk "
        "item, requirement, or threat it defines.\n"
        "For each one, produce four fields:\n"
        "- control_id: the framework's own identifier; if none exists, a short "
        "stable slug.\n"
        "- title: a concise name.\n"
        "- description: one to three sentences describing it.\n"
        "- category: a grouping label, or null.\n"
        "Rules:\n"
        "- Extract only what the document states; do not invent or infer controls.\n"
        "- Keep identifiers exactly as the document writes them.\n"
        "Respond with ONLY a JSON object and nothing else, in exactly this shape:\n"
        '{"controls": [{"control_id": "...", "title": "...", '
        '"description": "...", "category": "..."}]}'
    )


def framework_extraction_user_prompt(framework_name: str, document_text: str) -> str:
    """User prompt carrying the framework name and extracted document text."""
    return f"Framework: {framework_name}\n\nDocument text:\n\n{document_text}"
