"""Application configuration and logging bootstrap.

All settings load from environment variables (prefix ``SAW_``) and an optional
``.env`` file. Provider credentials are nested groups addressed with a double
underscore, e.g. ``SAW_AZURE_OPENAI__API_KEY``.
"""

from __future__ import annotations

import logging
from functools import lru_cache
from pathlib import Path
from typing import Literal

import structlog
from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict

ProviderName = Literal["azure_openai", "langdock", "anthropic"]


class AzureOpenAIConfig(BaseModel):
    """Azure OpenAI credentials.

    Azure requires two distinct identifiers: ``deployment`` (the resource-specific
    deployment name, used to route the request — passed to the API as ``model``)
    and ``model_name`` (the underlying model, e.g. ``gpt-4o``, recorded for
    diagnostics and token accounting). Both are required.
    """

    endpoint: str | None = None
    api_key: str | None = None
    api_version: str = "2024-12-01-preview"
    deployment: str | None = None
    model_name: str | None = None

    @property
    def is_configured(self) -> bool:
        return bool(
            self.endpoint and self.api_key and self.deployment and self.model_name
        )


class LangDockConfig(BaseModel):
    """LangDock OpenAI-compatible endpoint credentials."""

    base_url: str | None = None
    api_key: str | None = None
    model: str = "gpt-4o"

    @property
    def is_configured(self) -> bool:
        return bool(self.base_url and self.api_key)


class AnthropicConfig(BaseModel):
    """Anthropic API credentials."""

    api_key: str | None = None
    model: str = "claude-opus-4-7"

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)


class Settings(BaseSettings):
    """Process-wide configuration."""

    model_config = SettingsConfigDict(
        env_prefix="SAW_",
        env_file=".env",
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    # --- storage ---
    storage_root: Path = Path("./.saw-storage")

    # --- admin auth (Phase 8) ---
    admin_token: str | None = None

    # --- llm retry / fallback ---
    llm_default_provider: ProviderName = "azure_openai"
    llm_max_attempts: int = 4
    llm_base_delay_seconds: float = 0.5
    llm_max_delay_seconds: float = 30.0

    # --- http ---
    http_connect_timeout: float = 10.0
    http_read_timeout: float = 60.0
    http_write_timeout: float = 30.0
    http_pool_timeout: float = 10.0
    http_max_connections: int = 20
    http_max_keepalive_connections: int = 10

    # --- logging ---
    log_level: str = "INFO"
    log_json: bool = False

    # --- providers ---
    azure_openai: AzureOpenAIConfig = AzureOpenAIConfig()
    langdock: LangDockConfig = LangDockConfig()
    anthropic: AnthropicConfig = AnthropicConfig()

    def configured_providers(self) -> list[ProviderName]:
        """Return the providers that have complete credentials."""
        out: list[ProviderName] = []
        if self.azure_openai.is_configured:
            out.append("azure_openai")
        if self.langdock.is_configured:
            out.append("langdock")
        if self.anthropic.is_configured:
            out.append("anthropic")
        return out


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the cached process-wide settings instance."""
    return Settings()


def configure_logging(settings: Settings) -> None:
    """Configure structlog. Console renderer for dev, JSON for production."""
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    renderer: structlog.types.Processor = (
        structlog.processors.JSONRenderer()
        if settings.log_json
        else structlog.dev.ConsoleRenderer()
    )
    structlog.configure(
        wrapper_class=structlog.make_filtering_bound_logger(level),
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            renderer,
        ],
        cache_logger_on_first_use=True,
    )
