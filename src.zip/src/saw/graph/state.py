"""LangGraph workflow state."""

from __future__ import annotations

import operator
from typing import Annotated, TypedDict

from pydantic import BaseModel, Field

from saw.agents.reader import InputDocument
from saw.llm.diagnostics import RunTokenSummary
from saw.schemas import (
    AssessmentContext,
    AssessmentResult,
    CompletenessResult,
    ConfidenceScore,
    FinalReport,
    FrameworkRegistrySnapshot,
    LanguageSummary,
    ParsedQuestionResponse,
    QualityAssessmentResult,
    SupplementalContext,
    ValidationResult,
)


class WorkflowInputs(BaseModel):
    """The raw inputs a workflow run is invoked with."""

    sources: list[InputDocument]
    supplemental: list[InputDocument] = Field(default_factory=list)


class AssessmentState(TypedDict, total=False):
    """State threaded through the LangGraph assessment pipeline.

    ``total=False`` so each node can return a partial update. ``warnings`` uses an
    additive reducer so warnings from every node accumulate.
    """

    run_id: str
    inputs: WorkflowInputs
    vendor_name: str
    framework_snapshot: FrameworkRegistrySnapshot
    parsed_records: list[ParsedQuestionResponse]
    supplemental_context: SupplementalContext
    language_summary: LanguageSummary
    assessment_context: AssessmentContext
    completeness_results: list[CompletenessResult]
    validations: list[ValidationResult]
    quality_results: list[QualityAssessmentResult]
    assessment_results: AssessmentResult
    confidence: ConfidenceScore
    final_report: FinalReport
    warnings: Annotated[list[str], operator.add]
    token_summary: RunTokenSummary
