"""LangGraph orchestration of the assessment pipeline.

A linear nine-node graph. A state snapshot is persisted to
``<storage>/runs/{run_id}/`` after every node. The report node has no conditional
skip — it always runs, degrading gracefully on partial input.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from itertools import pairwise
from typing import Any, cast

import structlog
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel

from saw.agents import (
    AssessmentAgent,
    CompletenessQualityAgent,
    ConfidenceAgent,
    ContextProfiler,
    InputDocument,
    ReaderAgent,
    ReportAgent,
)
from saw.config import ProviderName
from saw.frameworks import FrameworkRegistry
from saw.graph.state import AssessmentState, WorkflowInputs
from saw.llm.client import LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.reporting import VendorSafeFilter
from saw.schemas import AssessmentContext
from saw.storage.interface import StorageBackend

log = structlog.get_logger(__name__)

NodeFn = Callable[[AssessmentState], dict[str, object]]

# The node backbone. profile_context infers the assessment context that
# calibrates later nodes; score_confidence gives the Confidence agent its own node.
_NODE_SEQUENCE: tuple[str, ...] = (
    "ingest_inputs",
    "load_frameworks",
    "parse_documents",
    "normalize_records",
    "profile_context",
    "validate_completeness",
    "assess_quality",
    "perform_security_assessment",
    "score_confidence",
    "generate_report",
)


def _serialize_value(value: object) -> object:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, list):
        return [_serialize_value(item) for item in value]
    return value


def _serialize_state(state: dict[str, object]) -> dict[str, object]:
    """Convert a state snapshot to a JSON-serializable dict (excluding raw bytes)."""
    out: dict[str, object] = {}
    for key, value in state.items():
        if key == "inputs" and isinstance(value, WorkflowInputs):
            out[key] = {
                "sources": [doc.filename for doc in value.sources],
                "supplemental": [doc.filename for doc in value.supplemental],
            }
        else:
            out[key] = _serialize_value(value)
    return out


class AssessmentWorkflow:
    """Builds and runs the LangGraph assessment pipeline."""

    def __init__(
        self,
        *,
        storage: StorageBackend,
        registry: FrameworkRegistry,
        llm_client: LLMClient,
        provider: ProviderName | None = None,
    ) -> None:
        self._storage = storage
        self._registry = registry
        self._llm = llm_client
        self._provider = provider

    def run(
        self,
        run_id: str,
        sources: list[InputDocument],
        supplemental: list[InputDocument] | None = None,
        assessment_context: AssessmentContext | None = None,
    ) -> AssessmentState:
        """Run the full pipeline, persisting a snapshot after each node.

        If ``assessment_context`` is supplied it is used as-is; otherwise the
        ``profile_context`` node infers it from the responses and documents.
        """
        diagnostics = RunDiagnostics(run_id)
        graph = self._build(run_id, diagnostics)
        initial: AssessmentState = {
            "run_id": run_id,
            "inputs": WorkflowInputs(sources=sources, supplemental=supplemental or []),
            "warnings": [],
        }
        if assessment_context is not None:
            initial["assessment_context"] = assessment_context
        log.info("workflow_started", run_id=run_id, sources=len(sources))
        final = cast(AssessmentState, graph.invoke(initial))
        log.info(
            "workflow_completed",
            run_id=run_id,
            findings=(
                len(final["assessment_results"].all_findings)
                if "assessment_results" in final
                else 0
            ),
        )
        return final

    def _build(self, run_id: str, diagnostics: RunDiagnostics) -> Any:
        llm, provider = self._llm, self._provider
        reader = ReaderAgent(llm, run_id=run_id, diagnostics=diagnostics, provider=provider)
        cq_agent = CompletenessQualityAgent(
            llm, run_id=run_id, diagnostics=diagnostics, provider=provider
        )
        assessment_agent = AssessmentAgent(
            llm, run_id=run_id, diagnostics=diagnostics, provider=provider
        )
        confidence_agent = ConfidenceAgent(
            llm, run_id=run_id, diagnostics=diagnostics, provider=provider
        )
        report_agent = ReportAgent(
            llm, run_id=run_id, diagnostics=diagnostics, provider=provider
        )
        context_profiler = ContextProfiler(
            llm, run_id=run_id, diagnostics=diagnostics, provider=provider
        )

        def ingest_inputs(state: AssessmentState) -> dict[str, object]:
            log.info("node_ingest", run_id=run_id, sources=len(state["inputs"].sources))
            return {}

        def load_frameworks(state: AssessmentState) -> dict[str, object]:
            self._registry.seed_if_empty()
            return {"framework_snapshot": self._registry.snapshot()}

        def parse_documents(state: AssessmentState) -> dict[str, object]:
            inputs = state["inputs"]
            result = reader.parse_documents(inputs.sources, inputs.supplemental)
            return {
                "vendor_name": result.vendor_name,
                "parsed_records": result.records,
                "supplemental_context": result.supplemental,
                "warnings": result.parse_warnings,
            }

        def normalize_records(state: AssessmentState) -> dict[str, object]:
            translated, summary = reader.normalize_records(state["parsed_records"])
            return {"parsed_records": translated, "language_summary": summary}

        def profile_context(state: AssessmentState) -> dict[str, object]:
            # A context supplied to run() is used as-is; otherwise it is inferred.
            existing = state.get("assessment_context")
            if existing is not None:
                return {"assessment_context": existing}
            context = context_profiler.profile(
                state["parsed_records"], state.get("supplemental_context")
            )
            return {"assessment_context": context}

        def validate_completeness(state: AssessmentState) -> dict[str, object]:
            return {
                "completeness_results": cq_agent.check_completeness(state["parsed_records"])
            }

        def assess_quality(state: AssessmentState) -> dict[str, object]:
            output = cq_agent.assess_quality(
                state["parsed_records"],
                state["completeness_results"],
                state.get("assessment_context"),
            )
            return {"validations": output.validations, "quality_results": output.quality}

        def perform_security_assessment(state: AssessmentState) -> dict[str, object]:
            return {
                "assessment_results": assessment_agent.assess(
                    state["parsed_records"],
                    state["framework_snapshot"],
                    state.get("supplemental_context"),
                    state.get("assessment_context"),
                )
            }

        def score_confidence(state: AssessmentState) -> dict[str, object]:
            return {
                "confidence": confidence_agent.score(
                    records=state["parsed_records"],
                    completeness=state["completeness_results"],
                    validations=state["validations"],
                    quality=state["quality_results"],
                    assessment=state["assessment_results"],
                    framework_snapshot=state["framework_snapshot"],
                )
            }

        def generate_report(state: AssessmentState) -> dict[str, object]:
            report = report_agent.build(
                vendor_name=state["vendor_name"],
                records=state["parsed_records"],
                validations=state["validations"],
                assessment=state["assessment_results"],
                confidence=state["confidence"],
                parse_warnings=list(state.get("warnings", [])),
                language_summary=state["language_summary"],
            )
            # Defense-in-depth: every section passes through the vendor-safe filter
            # (framework references stripped, brevity enforced) before persistence.
            offensive: list[str] = []
            for validation in state["validations"]:
                excerpt = (
                    validation.unprofessional.offending_excerpt_internal
                    if validation.unprofessional is not None
                    else None
                )
                if excerpt:
                    offensive.append(excerpt)
            vendor_safe_filter = VendorSafeFilter(
                state["framework_snapshot"],
                llm_client=llm,
                run_id=run_id,
                provider=provider,
                diagnostics=diagnostics,
            )
            filtered = vendor_safe_filter.filter_report(report, offensive_phrases=offensive)
            return {"final_report": filtered}

        raw_nodes: dict[str, NodeFn] = {
            "ingest_inputs": ingest_inputs,
            "load_frameworks": load_frameworks,
            "parse_documents": parse_documents,
            "normalize_records": normalize_records,
            "profile_context": profile_context,
            "validate_completeness": validate_completeness,
            "assess_quality": assess_quality,
            "perform_security_assessment": perform_security_assessment,
            "score_confidence": score_confidence,
            "generate_report": generate_report,
        }

        builder: Any = StateGraph(AssessmentState)
        for step, name in enumerate(_NODE_SEQUENCE, start=1):
            builder.add_node(name, self._wrap(step, name, raw_nodes[name], run_id, diagnostics))
        builder.add_edge(START, _NODE_SEQUENCE[0])
        for earlier, later in pairwise(_NODE_SEQUENCE):
            builder.add_edge(earlier, later)
        builder.add_edge(_NODE_SEQUENCE[-1], END)
        return builder.compile()

    def _wrap(
        self,
        step: int,
        name: str,
        fn: NodeFn,
        run_id: str,
        diagnostics: RunDiagnostics,
    ) -> NodeFn:
        """Wrap a node so it records token usage and persists a state snapshot."""

        def wrapped(state: AssessmentState) -> dict[str, object]:
            update = dict(fn(state))
            update["token_summary"] = diagnostics.summary()
            # warnings use an additive reducer; reproduce that for the snapshot.
            warnings = list(state.get("warnings", [])) + list(
                cast("list[str]", update.get("warnings", []))
            )
            snapshot: dict[str, object] = {**state, **update, "warnings": warnings}
            self._persist(run_id, step, name, snapshot)
            log.info("node_completed", run_id=run_id, node=name, step=step)
            return update

        return wrapped

    def _persist(
        self, run_id: str, step: int, name: str, snapshot: dict[str, object]
    ) -> None:
        path = f"runs/{run_id}/{step:02d}_{name}.json"
        self._storage.write_text(
            path, json.dumps(_serialize_state(snapshot), indent=2, default=str)
        )
