"""Report agent (Agent 5).

Assembles the :class:`FinalReport` using only the vendor-safe fields of each
risk finding. Internal fields are never read here. The vendor-safe filter
(Phase 7) runs as an additional defense-in-depth pass before persistence.
"""

from __future__ import annotations

import structlog
from pydantic import BaseModel, Field

from saw.agents._support import complete_structured
from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.follow_up import follow_up_system_prompt, follow_up_user_prompt
from saw.prompts.report import executive_summary_system_prompt, executive_summary_user_prompt
from saw.schemas import (
    AssessmentResult,
    ConfidenceBand,
    ConfidenceScore,
    FinalReport,
    FollowUpQuestion,
    LanguageSummary,
    ParsedQuestionResponse,
    ReliabilityNotice,
    RiskSeverity,
    TraceabilityRow,
    ValidationResult,
    ValidationStatus,
)

log = structlog.get_logger(__name__)

_EXCERPT_CHARS = 240
_MAX_THEMES = 6


class _SummaryReply(BaseModel):
    executive_summary: str = ""


class _FollowUpReply(BaseModel):
    questions: list[str] = Field(default_factory=list)


def _excerpt(record: ParsedQuestionResponse) -> str:
    text = record.assessment_text.strip()
    if not text:
        return "(no response provided)"
    if len(text) <= _EXCERPT_CHARS:
        return text
    return text[:_EXCERPT_CHARS].rstrip() + "…"


def _templated_summary(vendor_name: str, finding_count: int, band: str) -> str:
    return (
        f"This report summarizes the AI security assessment of {vendor_name}. "
        f"The review identified {finding_count} risk finding(s) across the vendor's "
        f"questionnaire responses. Overall confidence in these conclusions is {band}. "
        "See the risk summary and follow-up questions below for detail."
    )


class ReportAgent:
    """Assembles the vendor-shareable :class:`FinalReport`."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        diagnostics: RunDiagnostics | None = None,
        provider: ProviderName | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._diagnostics = diagnostics
        self._provider = provider

    def build(
        self,
        *,
        vendor_name: str,
        records: list[ParsedQuestionResponse],
        validations: list[ValidationResult],
        assessment: AssessmentResult,
        confidence: ConfidenceScore,
        parse_warnings: list[str],
        language_summary: LanguageSummary,
    ) -> FinalReport:
        rows = self._rows(records, assessment)
        follow_ups = self._follow_ups(assessment)
        summary = self._executive_summary(vendor_name, assessment, confidence)
        notice = self._notice(validations, confidence, language_summary)
        report = FinalReport(
            run_id=self._run_id,
            vendor_name=vendor_name,
            executive_summary=summary,
            confidence=confidence,
            reliability_notice=notice,
            risk_summary=rows,
            follow_up_questions=follow_ups,
            parse_warnings=parse_warnings,
            language_summary=language_summary,
        )
        log.info(
            "report_built", run_id=self._run_id, rows=len(rows), follow_ups=len(follow_ups)
        )
        return report

    @staticmethod
    def _rows(
        records: list[ParsedQuestionResponse], assessment: AssessmentResult
    ) -> list[TraceabilityRow]:
        """Build one traceability row for every question/response.

        A question with risk findings yields one row per finding; a question with
        no finding still appears, with a "no material risk" row.
        """
        assessment_by_number = {
            item.question_number: item for item in assessment.response_assessments
        }
        rows: list[TraceabilityRow] = []
        for record in records:
            response_assessment = assessment_by_number.get(record.number)
            findings = response_assessment.findings if response_assessment else []
            excerpt = _excerpt(record)
            if findings:
                for finding in findings:
                    rows.append(
                        TraceabilityRow(
                            question_number=record.number,
                            question=record.question,
                            response_excerpt=excerpt,
                            risk_observation=finding.risk_observation_vendor_safe,
                            follow_up_question=finding.vendor_safe_follow_up,
                            severity=finding.severity,
                        )
                    )
            else:
                rows.append(
                    TraceabilityRow(
                        question_number=record.number,
                        question=record.question,
                        response_excerpt=excerpt,
                        risk_observation=(
                            "No material security risk was identified for this response."
                        ),
                        follow_up_question="",
                        severity=RiskSeverity.informational,
                    )
                )
        return rows

    def _follow_ups(self, assessment: AssessmentResult) -> list[FollowUpQuestion]:
        seen: set[str] = set()
        unique: list[str] = []
        for finding in assessment.all_findings:
            draft = finding.vendor_safe_follow_up.strip()
            if draft and draft.lower() not in seen:
                seen.add(draft.lower())
                unique.append(draft)
        if not unique:
            return []
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=follow_up_system_prompt()),
                ChatMessage(role="user", content=follow_up_user_prompt(unique)),
            ],
            _FollowUpReply,
            run_id=self._run_id,
            node="generate_report",
            max_tokens=800,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        questions = reply.questions if (reply is not None and reply.questions) else unique
        return [
            FollowUpQuestion(number=index, text=question.strip())
            for index, question in enumerate(questions, start=1)
            if question.strip()
        ]

    def _executive_summary(
        self, vendor_name: str, assessment: AssessmentResult, confidence: ConfidenceScore
    ) -> str:
        findings = assessment.all_findings
        severity_counts: dict[str, int] = {}
        for finding in findings:
            key = finding.severity.value
            severity_counts[key] = severity_counts.get(key, 0) + 1
        themes = [finding.risk_observation_vendor_safe for finding in findings[:_MAX_THEMES]]
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=executive_summary_system_prompt()),
                ChatMessage(
                    role="user",
                    content=executive_summary_user_prompt(
                        vendor_name, confidence.band.value, severity_counts, themes
                    ),
                ),
            ],
            _SummaryReply,
            run_id=self._run_id,
            node="generate_report",
            max_tokens=600,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is not None and reply.executive_summary.strip():
            return reply.executive_summary.strip()
        return _templated_summary(vendor_name, len(findings), confidence.band.value)

    @staticmethod
    def _notice(
        validations: list[ValidationResult],
        confidence: ConfidenceScore,
        language_summary: LanguageSummary,
    ) -> ReliabilityNotice:
        has_unprofessional = any(
            v.status is ValidationStatus.offensive_or_unprofessional for v in validations
        )
        low_confidence = confidence.band is ConfidenceBand.low
        significant_translation = language_summary.significant_translation
        parts: list[str] = []
        if has_unprofessional:
            parts.append(
                "One or more responses contained unprofessional language; the affected "
                "content has been summarized rather than quoted."
            )
        if low_confidence:
            parts.append(
                "Overall confidence in these conclusions is low; treat the findings as "
                "indicative rather than definitive."
            )
        if significant_translation:
            parts.append(
                "A significant share of responses were translated from another language, "
                "which may affect nuance."
            )
        return ReliabilityNotice(
            confidence_band=confidence.band,
            rationale=confidence.rationale,
            has_unprofessional_responses=has_unprofessional,
            low_confidence=low_confidence,
            significant_translation=significant_translation,
            notice_text=" ".join(parts),
        )
