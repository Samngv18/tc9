"""Completeness & Quality agent (Agent 2).

Four sub-steps: (a) completeness check, (b) unprofessional classification,
(c) validation, (d) quality assessment. Sub-step (a) is its own LLM call; (b),
(c), and (d) share one combined call (the ``assess_quality`` graph node).
"""

from __future__ import annotations

from typing import cast

import structlog
from pydantic import BaseModel, Field

from saw.agents._support import complete_structured, format_context_text
from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.completeness import completeness_system_prompt, completeness_user_prompt
from saw.prompts.quality import quality_node_system_prompt, quality_node_user_prompt
from saw.schemas import (
    AssessmentContext,
    CompletenessResult,
    CompletenessState,
    ParsedQuestionResponse,
    QualityAssessmentResult,
    QualityDimension,
    QualityLevel,
    StrictModel,
    UnprofessionalCategory,
    UnprofessionalClassification,
    ValidationResult,
    ValidationStatus,
)

log = structlog.get_logger(__name__)

_CATEGORIES = {
    "frustration",
    "dismissive",
    "insult",
    "profanity",
    "sarcasm",
    "casual_venting",
    "other",
}


class QualityNodeOutput(StrictModel):
    """Combined output of the quality node (sub-steps b, c, d)."""

    unprofessional: list[UnprofessionalClassification]
    validations: list[ValidationResult]
    quality: list[QualityAssessmentResult]


class _CompletenessReply(BaseModel):
    structurally_present: bool = True
    state: str = "answered"
    reasoning: str = ""


class _DimensionReply(BaseModel):
    level: str = "not_assessable"
    comment: str = ""


class _UnprofessionalReply(BaseModel):
    is_flagged: bool = False
    category: str | None = None
    offending_excerpt: str | None = None
    reasoning: str = ""


class _ValidationReply(BaseModel):
    status: str = "pending"
    rationale: str = ""


class _QualityReply(BaseModel):
    clarity: _DimensionReply = Field(default_factory=_DimensionReply)
    relevance: _DimensionReply = Field(default_factory=_DimensionReply)
    sufficiency_of_detail: _DimensionReply = Field(default_factory=_DimensionReply)
    internal_consistency: _DimensionReply = Field(default_factory=_DimensionReply)
    architectural_relevance: _DimensionReply = Field(default_factory=_DimensionReply)
    practical_usefulness: _DimensionReply = Field(default_factory=_DimensionReply)
    overall_judgment: str = ""


class _QualityNodeReply(BaseModel):
    unprofessional: _UnprofessionalReply = Field(default_factory=_UnprofessionalReply)
    validation: _ValidationReply = Field(default_factory=_ValidationReply)
    quality: _QualityReply = Field(default_factory=_QualityReply)


def _to_completeness_state(value: str) -> CompletenessState:
    try:
        return CompletenessState(value.strip())
    except ValueError:
        return CompletenessState.answered


def _to_validation_status(value: str) -> ValidationStatus:
    try:
        return ValidationStatus(value.strip())
    except ValueError:
        return ValidationStatus.pending


def _to_quality_level(value: str) -> QualityLevel:
    try:
        return QualityLevel(value.strip())
    except ValueError:
        return QualityLevel.not_assessable


def _to_category(value: str | None) -> UnprofessionalCategory | None:
    if value is None:
        return None
    cleaned = value.strip().lower()
    if cleaned in _CATEGORIES:
        return cast(UnprofessionalCategory, cleaned)
    return "other"


def _dimension(reply: _DimensionReply) -> QualityDimension:
    return QualityDimension(level=_to_quality_level(reply.level), comment=reply.comment)


class CompletenessQualityAgent:
    """Runs the completeness check and the combined quality node."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        diagnostics: RunDiagnostics | None = None,
        provider: ProviderName | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._diagnostics = diagnostics
        self._provider = provider

    # --- sub-step (a) ----------------------------------------------------- #

    def check_completeness(
        self, records: list[ParsedQuestionResponse]
    ) -> list[CompletenessResult]:
        return [self._completeness_one(record) for record in records]

    def _completeness_one(self, record: ParsedQuestionResponse) -> CompletenessResult:
        if not record.assessment_text.strip():
            return CompletenessResult(
                question_number=record.number,
                structurally_present=False,
                state=CompletenessState.blank,
                reasoning="no response text was provided",
            )
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=completeness_system_prompt()),
                ChatMessage(
                    role="user",
                    content=completeness_user_prompt(record.question, record.assessment_text),
                ),
            ],
            _CompletenessReply,
            run_id=self._run_id,
            node="validate_completeness",
            max_tokens=400,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is None:
            return CompletenessResult(
                question_number=record.number,
                structurally_present=True,
                state=CompletenessState.answered,
                reasoning="completeness check degraded; response treated as answered",
            )
        return CompletenessResult(
            question_number=record.number,
            structurally_present=reply.structurally_present,
            state=_to_completeness_state(reply.state),
            reasoning=reply.reasoning or "completeness classified",
        )

    # --- sub-steps (b) + (c) + (d) --------------------------------------- #

    def assess_quality(
        self,
        records: list[ParsedQuestionResponse],
        completeness: list[CompletenessResult],
        context: AssessmentContext | None = None,
    ) -> QualityNodeOutput:
        state_by_number = {result.question_number: result.state for result in completeness}
        context_text = format_context_text(context)
        unprofessional: list[UnprofessionalClassification] = []
        validations: list[ValidationResult] = []
        quality: list[QualityAssessmentResult] = []
        for record in records:
            state = state_by_number.get(record.number, CompletenessState.answered)
            flagged, validation, assessed = self._quality_one(record, state, context_text)
            unprofessional.append(flagged)
            validations.append(validation)
            quality.append(assessed)
        return QualityNodeOutput(
            unprofessional=unprofessional, validations=validations, quality=quality
        )

    def _quality_one(
        self,
        record: ParsedQuestionResponse,
        completeness_state: CompletenessState,
        context_text: str,
    ) -> tuple[UnprofessionalClassification, ValidationResult, QualityAssessmentResult]:
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=quality_node_system_prompt()),
                ChatMessage(
                    role="user",
                    content=quality_node_user_prompt(
                        record.question,
                        record.assessment_text,
                        completeness_state.value,
                        context_text,
                    ),
                ),
            ],
            _QualityNodeReply,
            run_id=self._run_id,
            node="assess_quality",
            max_tokens=900,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is None:
            return self._degraded_quality(record)

        flagged = reply.unprofessional.is_flagged
        classification = UnprofessionalClassification(
            question_number=record.number,
            is_flagged=flagged,
            category=_to_category(reply.unprofessional.category) if flagged else None,
            offending_excerpt_internal=reply.unprofessional.offending_excerpt if flagged else None,
            reasoning=reply.unprofessional.reasoning or "no unprofessional language detected",
        )
        # When the classifier flags the response, validation status is overridden.
        status = (
            ValidationStatus.offensive_or_unprofessional
            if flagged
            else _to_validation_status(reply.validation.status)
        )
        validation = ValidationResult(
            question_number=record.number,
            status=status,
            rationale=reply.validation.rationale or "validation assessed",
            unprofessional=classification if flagged else None,
        )
        quality = QualityAssessmentResult(
            question_number=record.number,
            clarity=_dimension(reply.quality.clarity),
            relevance=_dimension(reply.quality.relevance),
            sufficiency_of_detail=_dimension(reply.quality.sufficiency_of_detail),
            internal_consistency=_dimension(reply.quality.internal_consistency),
            architectural_relevance=_dimension(reply.quality.architectural_relevance),
            practical_usefulness=_dimension(reply.quality.practical_usefulness),
            overall_judgment=reply.quality.overall_judgment or "quality assessed",
        )
        return classification, validation, quality

    @staticmethod
    def _degraded_quality(
        record: ParsedQuestionResponse,
    ) -> tuple[UnprofessionalClassification, ValidationResult, QualityAssessmentResult]:
        classification = UnprofessionalClassification(
            question_number=record.number,
            is_flagged=False,
            reasoning="unprofessional classifier degraded; provider unavailable",
        )
        validation = ValidationResult(
            question_number=record.number,
            status=ValidationStatus.pending,
            rationale="validation degraded; provider unavailable",
        )
        degraded = QualityDimension(
            level=QualityLevel.not_assessable, comment="quality assessment degraded"
        )
        quality = QualityAssessmentResult(
            question_number=record.number,
            clarity=degraded,
            relevance=degraded,
            sufficiency_of_detail=degraded,
            internal_consistency=degraded,
            architectural_relevance=degraded,
            practical_usefulness=degraded,
            overall_judgment="quality assessment degraded; provider unavailable",
        )
        return classification, validation, quality
