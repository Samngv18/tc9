"""Confidence agent (Agent 4).

Synthesizes the :class:`ConfidenceScore`. Factors and the numeric score are
computed deterministically (so the score is stable); only the rationale text is
LLM-generated, with a deterministic fallback.
"""

from __future__ import annotations

import structlog
from pydantic import BaseModel

from saw.agents._support import complete_structured
from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.confidence import (
    confidence_rationale_system_prompt,
    confidence_rationale_user_prompt,
)
from saw.schemas import (
    AssessmentResult,
    CompletenessResult,
    ConfidenceFactors,
    ConfidenceScore,
    FactorAssessment,
    FrameworkRegistrySnapshot,
    ParsedQuestionResponse,
    QualityAssessmentResult,
    QualityLevel,
    ValidationResult,
    ValidationStatus,
    band_for_score,
)

log = structlog.get_logger(__name__)

_FACTOR_SCORE = {
    FactorAssessment.strong: 0.9,
    FactorAssessment.adequate: 0.6,
    FactorAssessment.weak: 0.3,
}
_LEVEL_SCORE = {
    QualityLevel.strong: 0.9,
    QualityLevel.adequate: 0.6,
    QualityLevel.weak: 0.25,
    QualityLevel.not_assessable: 0.35,
}
_UNPROFESSIONAL_PENALTY = 0.12
_TRANSLATION_PENALTY = 0.06


def _to_factor(value: float) -> FactorAssessment:
    if value >= 0.75:
        return FactorAssessment.strong
    if value >= 0.5:
        return FactorAssessment.adequate
    return FactorAssessment.weak


def _templated_rationale(factors: ConfidenceFactors, band: str) -> str:
    parts = [
        f"Confidence in these conclusions is {band}.",
        f"Response completeness was {factors.parse_completeness.value}, response quality "
        f"{factors.response_quality.value}, and framework coverage "
        f"{factors.framework_coverage.value}.",
    ]
    if factors.unprofessional_content_present:
        parts.append(
            "One or more responses contained unprofessional language, reducing confidence."
        )
    if factors.translated_content_present:
        parts.append("Some responses were translated, which can affect interpretation.")
    return " ".join(parts)


class _RationaleReply(BaseModel):
    rationale: str = ""


class ConfidenceAgent:
    """Computes a stable confidence score and an explanatory rationale."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        diagnostics: RunDiagnostics | None = None,
        provider: ProviderName | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._diagnostics = diagnostics
        self._provider = provider

    def score(
        self,
        *,
        records: list[ParsedQuestionResponse],
        completeness: list[CompletenessResult],
        validations: list[ValidationResult],
        quality: list[QualityAssessmentResult],
        assessment: AssessmentResult,
        framework_snapshot: FrameworkRegistrySnapshot,
    ) -> ConfidenceScore:
        factors = self._factors(
            records, completeness, validations, quality, assessment, framework_snapshot
        )
        score = self._score(factors)
        band = band_for_score(score)
        rationale = self._rationale(factors, score, band.value)
        log.info("confidence_scored", run_id=self._run_id, score=round(score, 3), band=band.value)
        return ConfidenceScore(score=score, rationale=rationale, factors=factors)

    def _factors(
        self,
        records: list[ParsedQuestionResponse],
        completeness: list[CompletenessResult],
        validations: list[ValidationResult],
        quality: list[QualityAssessmentResult],
        assessment: AssessmentResult,
        snapshot: FrameworkRegistrySnapshot,
    ) -> ConfidenceFactors:
        complete_ratio = (
            sum(1 for result in completeness if result.is_complete) / len(completeness)
            if completeness
            else 0.0
        )
        dimension_scores: list[float] = []
        consistency_scores: list[float] = []
        for assessed in quality:
            for dimension in (
                assessed.clarity,
                assessed.relevance,
                assessed.sufficiency_of_detail,
                assessed.internal_consistency,
                assessed.architectural_relevance,
                assessed.practical_usefulness,
            ):
                dimension_scores.append(_LEVEL_SCORE[dimension.level])
            consistency_scores.append(_LEVEL_SCORE[assessed.internal_consistency.level])

        return ConfidenceFactors(
            parse_completeness=_to_factor(complete_ratio),
            response_quality=(
                _to_factor(sum(dimension_scores) / len(dimension_scores))
                if dimension_scores
                else FactorAssessment.weak
            ),
            internal_consistency=(
                _to_factor(sum(consistency_scores) / len(consistency_scores))
                if consistency_scores
                else FactorAssessment.weak
            ),
            framework_coverage=self._coverage_factor(snapshot, assessment),
            unprofessional_content_present=any(
                v.status is ValidationStatus.offensive_or_unprofessional for v in validations
            ),
            translated_content_present=any(record.is_translated for record in records),
        )

    @staticmethod
    def _coverage_factor(
        snapshot: FrameworkRegistrySnapshot, assessment: AssessmentResult
    ) -> FactorAssessment:
        if not snapshot.frameworks or not assessment.response_assessments:
            return FactorAssessment.weak
        total = len(assessment.response_assessments)
        degraded = sum(
            1
            for a in assessment.response_assessments
            if "degraded" in a.contextual_reasoning.lower()
        )
        return _to_factor(1.0 - degraded / total)

    @staticmethod
    def _score(factors: ConfidenceFactors) -> float:
        base = (
            _FACTOR_SCORE[factors.parse_completeness]
            + _FACTOR_SCORE[factors.response_quality]
            + _FACTOR_SCORE[factors.internal_consistency]
            + _FACTOR_SCORE[factors.framework_coverage]
        ) / 4.0
        penalty = 0.0
        if factors.unprofessional_content_present:
            penalty += _UNPROFESSIONAL_PENALTY
        if factors.translated_content_present:
            penalty += _TRANSLATION_PENALTY
        return max(0.0, min(1.0, base - penalty))

    def _rationale(self, factors: ConfidenceFactors, score: float, band: str) -> str:
        factor_map = {
            "parse completeness": factors.parse_completeness.value,
            "response quality": factors.response_quality.value,
            "internal consistency": factors.internal_consistency.value,
            "framework coverage": factors.framework_coverage.value,
            "unprofessional content present": str(factors.unprofessional_content_present),
            "translated content present": str(factors.translated_content_present),
        }
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=confidence_rationale_system_prompt()),
                ChatMessage(
                    role="user",
                    content=confidence_rationale_user_prompt(score, band, factor_map),
                ),
            ],
            _RationaleReply,
            run_id=self._run_id,
            node="score_confidence",
            max_tokens=400,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is not None and reply.rationale.strip():
            return reply.rationale.strip()
        return _templated_rationale(factors, band)
