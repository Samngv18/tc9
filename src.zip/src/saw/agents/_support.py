"""Shared agent helpers: JSON extraction, structured LLM calls, prompt formatting."""

from __future__ import annotations

import json
from typing import TypeVar

import structlog
from pydantic import BaseModel, ValidationError

from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.schemas import AssessmentContext, SupplementalContext

log = structlog.get_logger(__name__)

_M = TypeVar("_M", bound=BaseModel)

# Supporting-document text beyond this length is truncated before a prompt.
_MAX_SUPPLEMENTAL_CHARS = 8000


def format_supplemental_text(supplemental: SupplementalContext | None) -> str:
    """Format supporting documents into a single text block for a prompt."""
    if supplemental is None or not supplemental.documents:
        return "(no supporting documents were provided)"
    blocks = [
        f"[{document.filename}]\n{document.extracted_text.strip()}"
        for document in supplemental.documents
        if document.extracted_text.strip()
    ]
    if not blocks:
        return "(no supporting documents were provided)"
    combined = "\n\n".join(blocks)
    if len(combined) > _MAX_SUPPLEMENTAL_CHARS:
        combined = combined[:_MAX_SUPPLEMENTAL_CHARS].rstrip() + "\n…(truncated)"
    return combined


def format_context_text(context: AssessmentContext | None) -> str:
    """Format the assessment context into a labelled block for a prompt."""
    if context is None:
        return "(no assessment context was determined; assess each response on its own terms)"
    identified = context.open_source_models_identified
    if identified is True:
        identified_text = "model source identified"
    elif identified is False:
        identified_text = "model source NOT identified"
    else:
        identified_text = "model source identification not applicable"
    return (
        f"- solution type: {context.solution_type.value}\n"
        f"- business use case: {context.business_use_case}\n"
        f"- personal data handling: {context.pii_handling.value}\n"
        f"- uses external tools: {context.uses_external_tools}\n"
        f"- model sourcing: {context.model_sourcing.value} ({identified_text})\n"
        f"- context rationale: {context.rationale}"
    )


def extract_json(content: str) -> object | None:
    """Parse a JSON value from an LLM reply, tolerating code fences and prose."""
    text = content.strip()
    candidates: list[str] = [text]
    if "```" in text:
        parts = text.split("```")
        if len(parts) >= 3:
            body = parts[1]
            if body.lstrip().lower().startswith("json"):
                body = body.lstrip()[4:]
            candidates.append(body.strip())
    for opener, closer in (("{", "}"), ("[", "]")):
        start, end = text.find(opener), text.rfind(closer)
        if 0 <= start < end:
            candidates.append(text[start : end + 1])
    for candidate in candidates:
        try:
            parsed: object = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        return parsed
    return None


def complete_structured(
    llm_client: LLMClient,
    messages: list[ChatMessage],
    reply_model: type[_M],
    *,
    run_id: str,
    node: str,
    max_tokens: int,
    diagnostics: RunDiagnostics | None = None,
    provider: ProviderName | None = None,
) -> _M | None:
    """Run an LLM call and parse the reply into ``reply_model``.

    Returns ``None`` on any degradation — provider fallback, unparseable output,
    or schema mismatch — so callers can substitute a typed degraded default and
    never raise into the workflow.
    """
    result = llm_client.complete(
        messages,
        provider=provider,
        max_tokens=max_tokens,
        temperature=0.0,
        run_id=run_id,
        node=node,
        diagnostics=diagnostics,
    )
    if result.is_fallback:
        log.warning("agent_llm_fallback", node=node, run_id=run_id, error=result.last_error)
        return None
    payload = extract_json(result.content)
    if payload is None:
        log.warning("agent_llm_unparseable", node=node, run_id=run_id)
        return None
    try:
        return reply_model.model_validate(payload)
    except ValidationError as exc:
        log.warning("agent_llm_invalid_schema", node=node, run_id=run_id, error=str(exc))
        return None
