"""Reader agent (Agent 1).

Orchestrates the questionnaire and supplemental parsers and runs translation for
non-English responses. Split into two stages so the workflow can run them as
separate graph nodes: ``parse_documents`` then ``normalize_records``.
"""

from __future__ import annotations

import structlog
from pydantic import BaseModel

from saw.config import ProviderName
from saw.llm.client import LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.llm.translation import Translator
from saw.parsers import infer_vendor_name, parse_pdf, parse_supplemental_documents, parse_xlsx
from saw.schemas import (
    DocumentFormat,
    LanguageSummary,
    ParsedQuestionResponse,
    StrictModel,
    SupplementalContext,
)

log = structlog.get_logger(__name__)


class InputDocument(BaseModel):
    """A raw input file handed to the Reader agent."""

    filename: str
    content: bytes


class ReaderParseResult(StrictModel):
    """Output of the parse stage: records are parsed but not yet translated."""

    vendor_name: str
    records: list[ParsedQuestionResponse]
    supplemental: SupplementalContext
    parse_warnings: list[str]


class ReaderResult(StrictModel):
    """Fully normalized output of the Reader agent (parse + translate)."""

    vendor_name: str
    records: list[ParsedQuestionResponse]
    supplemental: SupplementalContext
    parse_warnings: list[str]
    language_summary: LanguageSummary


def _detect_format(filename: str) -> DocumentFormat | None:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in {"xlsx", "xlsm"}:
        return DocumentFormat.xlsx
    if ext == "pdf":
        return DocumentFormat.pdf
    return None


def _language_summary(records: list[ParsedQuestionResponse]) -> LanguageSummary:
    return LanguageSummary(
        total_responses=len(records),
        translated_responses=sum(1 for record in records if record.is_translated),
        detected_languages=sorted({record.original_language for record in records}),
    )


class ReaderAgent:
    """Parses questionnaire and supplemental documents and translates responses."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        diagnostics: RunDiagnostics | None = None,
        provider: ProviderName | None = None,
    ) -> None:
        self._run_id = run_id
        self._translator = Translator(
            llm_client, run_id=run_id, provider=provider, diagnostics=diagnostics
        )

    def parse_documents(
        self,
        sources: list[InputDocument],
        supplemental: list[InputDocument] | None = None,
    ) -> ReaderParseResult:
        """Parse all input documents. Records are not yet translated."""
        warnings: list[str] = []
        records: list[ParsedQuestionResponse] = []
        for source in sources:
            fmt = _detect_format(source.filename)
            if fmt is DocumentFormat.xlsx:
                result = parse_xlsx(source.content, filename=source.filename)
            elif fmt is DocumentFormat.pdf:
                result = parse_pdf(source.content, filename=source.filename)
            else:
                warnings.append(f"unsupported input document format: {source.filename}")
                continue
            records.extend(result.records)
            warnings.extend(f"[{source.filename}] {warning}" for warning in result.warnings)

        vendor_name = infer_vendor_name(sources[0].filename) if sources else "Vendor"
        if not records:
            warnings.append("no question/response records were parsed from the input documents")
        supplemental_context = parse_supplemental_documents(
            [(doc.filename, doc.content) for doc in (supplemental or [])]
        )
        log.info(
            "reader_parsed", run_id=self._run_id, vendor=vendor_name, records=len(records)
        )
        return ReaderParseResult(
            vendor_name=vendor_name,
            records=records,
            supplemental=supplemental_context,
            parse_warnings=warnings,
        )

    def normalize_records(
        self, records: list[ParsedQuestionResponse]
    ) -> tuple[list[ParsedQuestionResponse], LanguageSummary]:
        """Translate non-English responses and build the language summary."""
        translated = self._translator.translate_all(records)
        summary = _language_summary(translated)
        log.info(
            "reader_normalized",
            run_id=self._run_id,
            records=len(translated),
            translated=summary.translated_responses,
        )
        return translated, summary

    def read(
        self,
        sources: list[InputDocument],
        supplemental: list[InputDocument] | None = None,
    ) -> ReaderResult:
        """Convenience: parse and normalize in one call."""
        parsed = self.parse_documents(sources, supplemental)
        translated, summary = self.normalize_records(parsed.records)
        return ReaderResult(
            vendor_name=parsed.vendor_name,
            records=translated,
            supplemental=parsed.supplemental,
            parse_warnings=parsed.parse_warnings,
            language_summary=summary,
        )
