"""Context Profiler agent.

Infers the :class:`AssessmentContext` — solution type, personal-data handling,
model sourcing, tool usage — from the questionnaire responses and supporting
documents. This context calibrates how the Assessment and Completeness & Quality
agents reason: an undetermined context degrades to ordinary assessment.
"""

from __future__ import annotations

import structlog
from pydantic import BaseModel

from saw.agents._support import complete_structured, format_supplemental_text
from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.context import context_profile_system_prompt, context_profile_user_prompt
from saw.schemas import (
    AssessmentContext,
    ModelSourcing,
    ParsedQuestionResponse,
    PiiHandling,
    SolutionType,
    SupplementalContext,
)

log = structlog.get_logger(__name__)

_MAX_RESPONSES_CHARS = 9000


class _ContextReply(BaseModel):
    solution_type: str = "unknown"
    business_use_case: str = "not determined"
    pii_handling: str = "unknown"
    uses_external_tools: bool = False
    model_sourcing: str = "unknown"
    open_source_models_identified: bool | None = None
    rationale: str = ""


def _to_solution_type(value: str) -> SolutionType:
    try:
        return SolutionType(value.strip().lower())
    except ValueError:
        return SolutionType.unknown


def _to_model_sourcing(value: str) -> ModelSourcing:
    try:
        return ModelSourcing(value.strip().lower())
    except ValueError:
        return ModelSourcing.unknown


def _to_pii_handling(value: str) -> PiiHandling:
    try:
        return PiiHandling(value.strip().lower())
    except ValueError:
        return PiiHandling.unknown


def _format_responses(records: list[ParsedQuestionResponse]) -> str:
    blocks = [
        f"Q{record.number}: {record.question}\nA: {record.assessment_text or '(no answer)'}"
        for record in records
    ]
    combined = "\n\n".join(blocks)
    if len(combined) > _MAX_RESPONSES_CHARS:
        combined = combined[:_MAX_RESPONSES_CHARS].rstrip() + "\n…(truncated)"
    return combined or "(no responses were parsed)"


class ContextProfiler:
    """Infers the assessment context for a run from its responses and documents."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        diagnostics: RunDiagnostics | None = None,
        provider: ProviderName | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._diagnostics = diagnostics
        self._provider = provider

    def profile(
        self,
        records: list[ParsedQuestionResponse],
        supplemental: SupplementalContext | None = None,
    ) -> AssessmentContext:
        """Infer the assessment context; degrades to an all-unknown context."""
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=context_profile_system_prompt()),
                ChatMessage(
                    role="user",
                    content=context_profile_user_prompt(
                        _format_responses(records), format_supplemental_text(supplemental)
                    ),
                ),
            ],
            _ContextReply,
            run_id=self._run_id,
            node="profile_context",
            max_tokens=600,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is None:
            log.warning("context_profiling_degraded", run_id=self._run_id)
            return AssessmentContext()
        context = AssessmentContext(
            solution_type=_to_solution_type(reply.solution_type),
            business_use_case=reply.business_use_case or "not determined",
            pii_handling=_to_pii_handling(reply.pii_handling),
            uses_external_tools=reply.uses_external_tools,
            model_sourcing=_to_model_sourcing(reply.model_sourcing),
            open_source_models_identified=reply.open_source_models_identified,
            rationale=reply.rationale or "assessment context profiled",
        )
        log.info(
            "context_profiled",
            run_id=self._run_id,
            solution_type=context.solution_type.value,
            model_sourcing=context.model_sourcing.value,
            pii=context.pii_handling.value,
        )
        return context
