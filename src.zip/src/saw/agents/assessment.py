"""Assessment agent (Agent 3).

Evaluates each response against the active framework registry. Primary
frameworks weigh more than secondary; non-compliance is not an automatic
failure. Each finding carries internal-only and vendor-safe fields.
"""

from __future__ import annotations

from typing import Literal

import structlog
from pydantic import BaseModel, Field

from saw.agents._support import (
    complete_structured,
    format_context_text,
    format_supplemental_text,
)
from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.assessment import assessment_system_prompt, assessment_user_prompt
from saw.schemas import (
    AssessmentContext,
    AssessmentResult,
    FrameworkAlignment,
    FrameworkRegistrySnapshot,
    ParsedQuestionResponse,
    ResponseAssessment,
    RiskFinding,
    RiskSeverity,
    SupplementalContext,
)

log = structlog.get_logger(__name__)

_EXCERPT_CHARS = 320


class _AlignmentReply(BaseModel):
    framework_name: str = ""
    framework_tier: str = "secondary"
    control_ids: list[str] = Field(default_factory=list)
    note: str = ""


class _FindingReply(BaseModel):
    severity: str = "informational"
    risk_observation_internal: str = ""
    framework_alignment: list[_AlignmentReply] = Field(default_factory=list)
    vendor_safe_risk_observation: str = ""
    vendor_safe_follow_up: str = ""


class _AssessmentReply(BaseModel):
    findings: list[_FindingReply] = Field(default_factory=list)
    contextual_reasoning: str = ""
    no_material_risk: bool = False


def _to_severity(value: str) -> RiskSeverity:
    try:
        return RiskSeverity(value.strip().lower())
    except ValueError:
        return RiskSeverity.informational


def _to_tier(value: str) -> Literal["primary", "secondary"]:
    return "primary" if value.strip().lower() == "primary" else "secondary"


def _excerpt(text: str) -> str:
    text = text.strip()
    if len(text) <= _EXCERPT_CHARS:
        return text
    return text[:_EXCERPT_CHARS].rstrip() + "…"


def _format_frameworks(snapshot: FrameworkRegistrySnapshot) -> str:
    if not snapshot.frameworks:
        return "(no frameworks are currently active; assess on general security principles)"
    blocks: list[str] = []
    for label, frameworks in (("PRIMARY", snapshot.primary), ("SECONDARY", snapshot.secondary)):
        if not frameworks:
            continue
        blocks.append(f"=== {label} TIER ===")
        for framework in frameworks:
            blocks.append(f"[{framework.name}]")
            for control in framework.extracted_controls:
                blocks.append(
                    f"  {control.control_id}: {control.title} - {control.description}"
                )
    return "\n".join(blocks)


class AssessmentAgent:
    """Produces a :class:`ResponseAssessment` for every response."""

    def __init__(
        self,
        llm_client: LLMClient,
        *,
        run_id: str,
        diagnostics: RunDiagnostics | None = None,
        provider: ProviderName | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._diagnostics = diagnostics
        self._provider = provider

    def assess(
        self,
        records: list[ParsedQuestionResponse],
        framework_snapshot: FrameworkRegistrySnapshot,
        supplemental: SupplementalContext | None = None,
        context: AssessmentContext | None = None,
    ) -> AssessmentResult:
        frameworks_text = _format_frameworks(framework_snapshot)
        supplemental_text = format_supplemental_text(supplemental)
        context_text = format_context_text(context)
        assessments = [
            self._assess_one(record, frameworks_text, supplemental_text, context_text)
            for record in records
        ]
        log.info(
            "assessment_completed",
            run_id=self._run_id,
            responses=len(assessments),
            findings=sum(len(a.findings) for a in assessments),
            supporting_documents=len(supplemental.documents) if supplemental else 0,
        )
        return AssessmentResult(run_id=self._run_id, response_assessments=assessments)

    def _assess_one(
        self,
        record: ParsedQuestionResponse,
        frameworks_text: str,
        supplemental_text: str,
        context_text: str,
    ) -> ResponseAssessment:
        if not record.assessment_text.strip():
            # A non-answer is itself a risk signal; recorded without an LLM call.
            return ResponseAssessment(
                question_number=record.number,
                findings=[
                    RiskFinding(
                        question_number=record.number,
                        severity=RiskSeverity.medium,
                        risk_observation_internal="vendor provided no response to this question",
                        original_response_excerpt="(no response provided)",
                        risk_observation_vendor_safe=(
                            "The vendor did not provide a response to this question, leaving "
                            "the associated security risk undisclosed."
                        ),
                        vendor_safe_follow_up=(
                            "Can you provide a response describing how this area is handled?"
                        ),
                    )
                ],
                contextual_reasoning="no response text was available to assess",
            )

        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=assessment_system_prompt()),
                ChatMessage(
                    role="user",
                    content=assessment_user_prompt(
                        record.question,
                        record.assessment_text,
                        frameworks_text,
                        supplemental_text,
                        context_text,
                    ),
                ),
            ],
            _AssessmentReply,
            run_id=self._run_id,
            node="perform_security_assessment",
            max_tokens=1600,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is None:
            return ResponseAssessment(
                question_number=record.number,
                findings=[],
                contextual_reasoning="security assessment degraded; provider unavailable",
            )
        excerpt = _excerpt(record.assessment_text)
        findings = [self._finding(record.number, item, excerpt) for item in reply.findings]
        return ResponseAssessment(
            question_number=record.number,
            findings=findings,
            contextual_reasoning=reply.contextual_reasoning or "assessed",
            no_material_risk=reply.no_material_risk and not findings,
        )

    @staticmethod
    def _finding(question_number: str, reply: _FindingReply, excerpt: str) -> RiskFinding:
        alignments = [
            FrameworkAlignment(
                framework_name=item.framework_name,
                framework_tier=_to_tier(item.framework_tier),
                control_ids=item.control_ids,
                note=item.note,
            )
            for item in reply.framework_alignment
        ]
        vendor_safe = (
            reply.vendor_safe_risk_observation
            or reply.risk_observation_internal
            or "A potential security risk was identified in this response."
        )
        follow_up = (
            reply.vendor_safe_follow_up
            or "Can you provide more detail on how this risk is mitigated?"
        )
        return RiskFinding(
            question_number=question_number,
            severity=_to_severity(reply.severity),
            risk_observation_internal=reply.risk_observation_internal or vendor_safe,
            framework_alignment_internal=alignments,
            original_response_excerpt=excerpt,
            risk_observation_vendor_safe=vendor_safe,
            vendor_safe_follow_up=follow_up,
        )
