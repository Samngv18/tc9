"""Reporting layer: vendor-safe filtering, PDF rendering, internal traceability."""

from saw.reporting.pdf_writer import render_report_pdf
from saw.reporting.traceability import (
    InternalTraceabilityEntry,
    InternalTraceabilityRecord,
    build_internal_traceability,
)
from saw.reporting.vendor_safe_filter import (
    VendorSafeFilter,
    VendorSafeFilterError,
    count_sentences,
    count_words,
    truncate_sentences,
    truncate_words,
)

__all__ = [
    "InternalTraceabilityEntry",
    "InternalTraceabilityRecord",
    "VendorSafeFilter",
    "VendorSafeFilterError",
    "build_internal_traceability",
    "count_sentences",
    "count_words",
    "render_report_pdf",
    "truncate_sentences",
    "truncate_words",
]
