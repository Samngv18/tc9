"""PDF report writer (reportlab).

Renders a vendor-safe :class:`FinalReport` to a professionally formatted PDF.
Risk-summary rows are color-coded by severity.
"""

from __future__ import annotations

from io import BytesIO
from xml.sax.saxutils import escape

import structlog
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from saw.schemas import FinalReport, RiskSeverity

log = structlog.get_logger(__name__)

# Light background tints keyed to severity for the risk-summary table.
_SEVERITY_TINT = {
    RiskSeverity.critical: colors.HexColor("#f5b7b1"),
    RiskSeverity.high: colors.HexColor("#f8c9a4"),
    RiskSeverity.medium: colors.HexColor("#fdebc8"),
    RiskSeverity.low: colors.HexColor("#d5f5e3"),
    RiskSeverity.informational: colors.HexColor("#d6eaf8"),
}
_RISK_COLUMN_WIDTHS = [0.4 * inch, 1.35 * inch, 1.5 * inch, 1.7 * inch, 1.4 * inch, 0.75 * inch]


def render_report_pdf(report: FinalReport) -> bytes:
    """Render a vendor-safe FinalReport to PDF bytes."""
    buffer = BytesIO()
    document = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        title=f"AI Security Assessment - {report.vendor_name}",
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
    )
    styles = getSampleStyleSheet()
    body = styles["BodyText"]
    cell = ParagraphStyle("cell", parent=body, fontSize=8, leading=10)
    notice_style = ParagraphStyle(
        "notice",
        parent=body,
        backColor=colors.HexColor("#fcf3cf"),
        borderColor=colors.HexColor("#d4ac0d"),
        borderWidth=1,
        borderPadding=6,
        spaceBefore=6,
        spaceAfter=6,
    )

    story: list[object] = [
        Paragraph("AI Security Assessment", styles["Title"]),
        Paragraph(f"Vendor: {escape(report.vendor_name)}", styles["Heading2"]),
        Paragraph(
            f"Generated: {report.generated_at:%Y-%m-%d %H:%M} UTC "
            f"&nbsp;&middot;&nbsp; Run: {escape(report.run_id)}",
            body,
        ),
        Spacer(1, 12),
    ]

    story.append(Paragraph("Executive Summary", styles["Heading1"]))
    story.append(Paragraph(escape(report.executive_summary), body))
    story.append(Spacer(1, 12))

    story.append(Paragraph("Confidence and Reliability Notice", styles["Heading1"]))
    story.append(
        Paragraph(
            f"Confidence: <b>{report.confidence.band.value}</b> "
            f"(score {report.confidence.score:.2f})",
            body,
        )
    )
    story.append(Paragraph(escape(report.confidence.rationale), body))
    if report.reliability_notice.is_prominent and report.reliability_notice.notice_text:
        story.append(
            Paragraph(
                "<b>Reliability notice:</b> "
                + escape(report.reliability_notice.notice_text),
                notice_style,
            )
        )
    story.append(Spacer(1, 12))

    story.append(Paragraph("Question and Risk Summary", styles["Heading1"]))
    if report.risk_summary:
        header = [
            Paragraph(f"<b>{label}</b>", cell)
            for label in ("#", "Question", "Response Excerpt", "Risk Observation",
                          "Follow-Up", "Severity")
        ]
        data: list[list[object]] = [header]
        for row in report.risk_summary:
            data.append(
                [
                    Paragraph(escape(row.question_number), cell),
                    Paragraph(escape(row.question), cell),
                    Paragraph(escape(row.response_excerpt), cell),
                    Paragraph(escape(row.risk_observation), cell),
                    Paragraph(escape(row.follow_up_question), cell),
                    Paragraph(escape(row.severity.value), cell),
                ]
            )
        table = Table(data, colWidths=_RISK_COLUMN_WIDTHS, repeatRows=1)
        commands: list[tuple[object, ...]] = [
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#bdc3c7")),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#34495e")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]
        for index, row in enumerate(report.risk_summary, start=1):
            tint = _SEVERITY_TINT.get(row.severity, colors.white)
            commands.append(("BACKGROUND", (0, index), (-1, index), tint))
        table.setStyle(TableStyle(commands))
        story.append(table)
    else:
        story.append(Paragraph("No risk findings were identified.", body))
    story.append(Spacer(1, 12))

    story.append(Paragraph("Follow-Up Questions", styles["Heading1"]))
    if report.follow_up_questions:
        for question in report.follow_up_questions:
            story.append(Paragraph(f"{question.number}. {escape(question.text)}", body))
    else:
        story.append(Paragraph("No follow-up questions.", body))
    story.append(Spacer(1, 12))

    story.append(Paragraph("Appendix", styles["Heading1"]))
    summary = report.language_summary
    languages = ", ".join(summary.detected_languages) or "n/a"
    story.append(
        Paragraph(
            f"Responses: {summary.total_responses} &nbsp;&middot;&nbsp; "
            f"translated: {summary.translated_responses} &nbsp;&middot;&nbsp; "
            f"languages: {escape(languages)}",
            body,
        )
    )
    if report.parse_warnings:
        story.append(Paragraph("<b>Parse warnings:</b>", body))
        for warning in report.parse_warnings:
            story.append(Paragraph(f"&bull; {escape(warning)}", body))
    else:
        story.append(Paragraph("No parse warnings.", body))

    document.build(story)
    log.info("report_pdf_rendered", run_id=report.run_id, bytes=buffer.tell())
    return buffer.getvalue()
