"""Internal traceability record.

The company-internal audit trail for an assessment run. It carries internal-only
data — original-language response text, internal risk observations, framework
alignment, and any offensive excerpt — and is NEVER shared with the vendor. The
vendor-facing artifact is the filtered :class:`FinalReport`.
"""

from __future__ import annotations

import structlog

from saw.schemas import (
    AssessmentResult,
    FrameworkAlignment,
    ParsedQuestionResponse,
    StrictModel,
    ValidationResult,
)

log = structlog.get_logger(__name__)


class InternalTraceabilityEntry(StrictModel):
    """Internal audit record for one question/response."""

    question_number: str
    question: str
    original_language: str
    original_text: str
    translated_text: str | None
    validation_status: str
    unprofessional_excerpt: str | None
    internal_risk_observations: list[str]
    framework_alignment: list[FrameworkAlignment]


class InternalTraceabilityRecord(StrictModel):
    """The full internal traceability record for an assessment run."""

    run_id: str
    vendor_name: str
    entries: list[InternalTraceabilityEntry]


def build_internal_traceability(
    *,
    run_id: str,
    vendor_name: str,
    records: list[ParsedQuestionResponse],
    assessment: AssessmentResult,
    validations: list[ValidationResult],
) -> InternalTraceabilityRecord:
    """Assemble the internal traceability record from the run's intermediate outputs."""
    record_by_number = {record.number: record for record in records}
    validation_by_number = {item.question_number: item for item in validations}
    entries: list[InternalTraceabilityEntry] = []
    for response_assessment in assessment.response_assessments:
        number = response_assessment.question_number
        record = record_by_number.get(number)
        validation = validation_by_number.get(number)
        excerpt: str | None = None
        if validation is not None and validation.unprofessional is not None:
            excerpt = validation.unprofessional.offending_excerpt_internal
        alignments = [
            alignment
            for finding in response_assessment.findings
            for alignment in finding.framework_alignment_internal
        ]
        entries.append(
            InternalTraceabilityEntry(
                question_number=number,
                question=record.question if record else "(question unavailable)",
                original_language=record.original_language if record else "und",
                original_text=record.original_text if record else "",
                translated_text=record.translated_text if record else None,
                validation_status=validation.status.value if validation else "pending",
                unprofessional_excerpt=excerpt,
                internal_risk_observations=[
                    finding.risk_observation_internal
                    for finding in response_assessment.findings
                ],
                framework_alignment=alignments,
            )
        )
    log.info("internal_traceability_built", run_id=run_id, entries=len(entries))
    return InternalTraceabilityRecord(
        run_id=run_id, vendor_name=vendor_name, entries=entries
    )
