"""Vendor-safe filter.

The final report is a vendor-shareable artifact, so company IP — including the
fact that specific standards are applied internally — must not leak. This filter
is the defense-in-depth layer over the Report agent's vendor-safe fields:

  1. a deterministic deny-list pass over framework names + control-ID patterns,
  2. an optional LLM scrub pass (only when pass 1 found a leak),
  3. a final assertion pass that fails loudly if any banned token survives.

It also enforces the report's brevity limits (constraint #8).
"""

from __future__ import annotations

import re

import structlog
from pydantic import BaseModel

from saw.agents._support import complete_structured
from saw.config import ProviderName
from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.vendor_safe_scrub import (
    vendor_safe_scrub_system_prompt,
    vendor_safe_scrub_user_prompt,
)
from saw.schemas import (
    EXECUTIVE_SUMMARY_MAX_WORDS,
    FOLLOW_UP_MAX_WORDS,
    RISK_OBSERVATION_MAX_SENTENCES,
    FinalReport,
    FollowUpQuestion,
    FrameworkRegistrySnapshot,
    FrameworkVisibility,
    TraceabilityRow,
)

log = structlog.get_logger(__name__)

# Well-known public framework names, longest first so multi-word names strip
# before their substrings.
_PUBLIC_FRAMEWORK_TERMS: tuple[str, ...] = (
    "OWASP Agentic AI Top 10",
    "OWASP LLM Top 10",
    "OWASP Agentic",
    "OWASP Top 10",
    "MITRE ATLAS",
    "NIST AI RMF",
    "ISO/IEC 42001",
    "ISO 42001",
    "EU AI Act",
    "OWASP",
    "MITRE",
    "ATLAS",
    "NIST",
    "AI RMF",
    "AI Act",
    "ISO/IEC",
)

# Control-identifier shapes (e.g. LLM01, AML.T0051, MAP-1.1).
_CONTROL_ID_PATTERNS: tuple[str, ...] = (
    r"\bLLM\d{1,2}\b",
    r"\bAAI\d{1,3}\b",
    r"\bAML\.T\d{3,5}\b",
    r"\b(?:GOVERN|MAP|MEASURE|MANAGE)-\d+(?:\.\d+)?\b",
    r"\bINT-SEC-\d+\b",
    r"\bCL-\d+\b",
    r"\bART-\d+\b",
    r"\bGPAI\b",
    r"\bA-IMPACT\b",
    r"\bRISK-[A-Z]+\b",
)

_SENTENCE_RE = re.compile(r"[^.!?]+[.!?]+")


class VendorSafeFilterError(RuntimeError):
    """Raised when a banned token survives every filter pass (a filter bug)."""


class _ScrubReply(BaseModel):
    text: str = ""


def count_words(text: str) -> int:
    """Whitespace-delimited word count."""
    return len(text.split())


def count_sentences(text: str) -> int:
    """Approximate sentence count (terminal-punctuation segments)."""
    stripped = text.strip()
    if not stripped:
        return 0
    matches = _SENTENCE_RE.findall(stripped)
    return len(matches) if matches else 1


def truncate_words(text: str, max_words: int) -> str:
    """Truncate to at most ``max_words`` whitespace-delimited words."""
    words = text.split()
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words]) + "…"


def truncate_sentences(text: str, max_sentences: int) -> str:
    """Truncate to at most ``max_sentences`` sentences."""
    matches = _SENTENCE_RE.findall(text.strip())
    if len(matches) <= max_sentences:
        return text
    return " ".join(match.strip() for match in matches[:max_sentences])


class VendorSafeFilter:
    """Strips all framework references from a report and enforces brevity."""

    def __init__(
        self,
        framework_snapshot: FrameworkRegistrySnapshot,
        *,
        llm_client: LLMClient | None = None,
        run_id: str = "-",
        provider: ProviderName | None = None,
        diagnostics: RunDiagnostics | None = None,
    ) -> None:
        self._llm = llm_client
        self._run_id = run_id
        self._provider = provider
        self._diagnostics = diagnostics
        self._offensive: list[str] = []
        self._patterns = self._build_patterns(framework_snapshot)

    @staticmethod
    def _build_patterns(snapshot: FrameworkRegistrySnapshot) -> list[re.Pattern[str]]:
        terms: list[str] = list(_PUBLIC_FRAMEWORK_TERMS)
        id_regexes: list[str] = list(_CONTROL_ID_PATTERNS)
        for framework in snapshot.frameworks:
            if framework.visibility is FrameworkVisibility.internal:
                terms.append(framework.name)
                terms.append(framework.name.replace("_", " "))
            for control in framework.extracted_controls:
                id_regexes.append(rf"\b{re.escape(control.control_id)}\b")
        terms.sort(key=len, reverse=True)
        patterns = [re.compile(rf"\b{re.escape(term)}\b", re.IGNORECASE) for term in terms]
        patterns += [re.compile(regex, re.IGNORECASE) for regex in id_regexes]
        return patterns

    def filter_report(
        self, report: FinalReport, *, offensive_phrases: list[str] | None = None
    ) -> FinalReport:
        """Return a vendor-safe, brevity-enforced copy of ``report``."""
        self._offensive = [p for p in (offensive_phrases or []) if p and p.strip()]
        confidence = report.confidence.model_copy(
            update={"rationale": self.filter_text(report.confidence.rationale)}
        )
        notice = report.reliability_notice.model_copy(
            update={
                "rationale": self.filter_text(report.reliability_notice.rationale),
                "notice_text": self.filter_text(report.reliability_notice.notice_text),
            }
        )
        rows = [self._filter_row(row) for row in report.risk_summary]
        follow_ups = [
            FollowUpQuestion(
                number=item.number,
                text=truncate_words(self.filter_text(item.text), FOLLOW_UP_MAX_WORDS),
            )
            for item in report.follow_up_questions
        ]
        filtered = report.model_copy(
            update={
                "executive_summary": truncate_words(
                    self.filter_text(report.executive_summary), EXECUTIVE_SUMMARY_MAX_WORDS
                ),
                "confidence": confidence,
                "reliability_notice": notice,
                "risk_summary": rows,
                "follow_up_questions": follow_ups,
                "parse_warnings": [self.filter_text(w) for w in report.parse_warnings],
            }
        )
        log.info("vendor_safe_filter_applied", run_id=self._run_id, rows=len(rows))
        return filtered

    def filter_text(self, text: str) -> str:
        """Strip framework references and offensive phrases from a single string."""
        if not text or not text.strip():
            return text
        without_offensive = self._remove_offensive(text)
        leaked = self._find_banned(without_offensive)
        cleaned = self._strip(without_offensive)
        if leaked:
            log.warning(
                "vendor_safe_leak_stripped",
                run_id=self._run_id,
                tokens=sorted(set(leaked)),
            )
            cleaned = self._strip(self._llm_scrub(cleaned))
        self._assert_clean(cleaned)
        return cleaned

    def _filter_row(self, row: TraceabilityRow) -> TraceabilityRow:
        return TraceabilityRow(
            question_number=row.question_number,
            question=self.filter_text(row.question),
            response_excerpt=self.filter_text(row.response_excerpt),
            risk_observation=truncate_sentences(
                self.filter_text(row.risk_observation), RISK_OBSERVATION_MAX_SENTENCES
            ),
            follow_up_question=truncate_words(
                self.filter_text(row.follow_up_question), FOLLOW_UP_MAX_WORDS
            ),
            severity=row.severity,
        )

    def _remove_offensive(self, text: str) -> str:
        cleaned = text
        for phrase in self._offensive:
            cleaned = re.sub(re.escape(phrase), " ", cleaned, flags=re.IGNORECASE)
        return re.sub(r"\s{2,}", " ", cleaned).strip() if self._offensive else text

    def _find_banned(self, text: str) -> list[str]:
        found: list[str] = []
        for pattern in self._patterns:
            found.extend(pattern.findall(text))
        return found

    def _strip(self, text: str) -> str:
        cleaned = text
        for pattern in self._patterns:
            cleaned = pattern.sub(" ", cleaned)
        cleaned = re.sub(r"\s+([,.;:)])", r"\1", cleaned)
        cleaned = re.sub(r"\(\s*\)", "", cleaned)
        cleaned = re.sub(r"\s{2,}", " ", cleaned)
        return cleaned.strip()

    def _llm_scrub(self, text: str) -> str:
        if self._llm is None:
            return text
        reply = complete_structured(
            self._llm,
            [
                ChatMessage(role="system", content=vendor_safe_scrub_system_prompt()),
                ChatMessage(role="user", content=vendor_safe_scrub_user_prompt(text)),
            ],
            _ScrubReply,
            run_id=self._run_id,
            node="vendor_safe_scrub",
            max_tokens=700,
            diagnostics=self._diagnostics,
            provider=self._provider,
        )
        if reply is not None and reply.text.strip():
            return reply.text.strip()
        return text

    def _assert_clean(self, text: str) -> None:
        remaining = self._find_banned(text)
        if remaining:
            raise VendorSafeFilterError(
                f"banned tokens survived the vendor-safe filter: {sorted(set(remaining))}"
            )
