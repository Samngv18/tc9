"""Storage backend abstraction.

A single ``StorageBackend`` protocol with a filesystem implementation. The same
code path serves local development and a mounted Azure Files share — only the
root path differs, so no Blob Storage SDK is needed.
"""

from saw.storage.filesystem import FilesystemStorage, build_storage
from saw.storage.interface import StorageBackend, read_json, write_json

__all__ = [
    "FilesystemStorage",
    "StorageBackend",
    "build_storage",
    "read_json",
    "write_json",
]
