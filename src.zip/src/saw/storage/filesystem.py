"""Filesystem ``StorageBackend`` implementation.

Identical code path for local disk and a mounted Azure Files share at
``SAW_STORAGE_ROOT`` — only the root differs. All access is confined to the
configured root; paths that would escape it are rejected.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import structlog

from saw.config import Settings

log = structlog.get_logger(__name__)


class FilesystemStorage:
    """A ``StorageBackend`` rooted at a single directory tree."""

    def __init__(self, root: str | Path) -> None:
        self._root = Path(root).expanduser().resolve()
        self._root.mkdir(parents=True, exist_ok=True)
        log.info("storage_initialized", backend="filesystem", root=str(self._root))

    @property
    def root(self) -> Path:
        return self._root

    def _resolve(self, path: str) -> Path:
        if not path or not path.strip():
            raise ValueError("path must be non-empty")
        candidate = (self._root / path).resolve()
        if candidate != self._root and self._root not in candidate.parents:
            raise ValueError(f"path escapes storage root: {path!r}")
        return candidate

    def write_bytes(self, path: str, data: bytes) -> None:
        target = self._resolve(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

    def read_bytes(self, path: str) -> bytes:
        return self._resolve(path).read_bytes()

    def write_text(self, path: str, text: str) -> None:
        target = self._resolve(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")

    def read_text(self, path: str) -> str:
        return self._resolve(path).read_text(encoding="utf-8")

    def exists(self, path: str) -> bool:
        return self._resolve(path).exists()

    def delete(self, path: str) -> None:
        target = self._resolve(path)
        if target.is_dir():
            shutil.rmtree(target)
        elif target.exists():
            target.unlink()

    def list_dir(self, path: str = ".") -> list[str]:
        target = self._resolve(path)
        if not target.exists():
            return []
        return sorted(p.name for p in target.iterdir())

    def makedirs(self, path: str) -> None:
        self._resolve(path).mkdir(parents=True, exist_ok=True)

    def local_path(self, path: str) -> Path:
        """Concrete filesystem path — for libraries that require a real file path."""
        return self._resolve(path)


def build_storage(settings: Settings) -> FilesystemStorage:
    """Build the filesystem backend and warn if the root looks ephemeral."""
    configured = settings.storage_root
    storage = FilesystemStorage(configured)
    looks_ephemeral = (
        not configured.is_absolute()
        or str(storage.root).startswith("/tmp")
        or str(storage.root).startswith("/var/folders")
    )
    if looks_ephemeral:
        log.warning(
            "storage_possibly_ephemeral",
            root=str(storage.root),
            detail=(
                "framework updates may not survive container restarts; "
                "mount an Azure Files volume and point SAW_STORAGE_ROOT at it"
            ),
        )
    return storage
