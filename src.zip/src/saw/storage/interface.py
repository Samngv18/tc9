"""Storage backend protocol and JSON convenience helpers."""

from __future__ import annotations

import json
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class StorageBackend(Protocol):
    """Primitive byte/text storage.

    Filesystem-backed in v1 (local disk in dev, a mounted Azure Files share in
    production). All paths are relative to a backend-owned root; implementations
    must reject paths that escape that root.
    """

    def write_bytes(self, path: str, data: bytes) -> None: ...

    def read_bytes(self, path: str) -> bytes: ...

    def write_text(self, path: str, text: str) -> None: ...

    def read_text(self, path: str) -> str: ...

    def exists(self, path: str) -> bool: ...

    def delete(self, path: str) -> None: ...

    def list_dir(self, path: str) -> list[str]: ...

    def makedirs(self, path: str) -> None: ...


def write_json(backend: StorageBackend, path: str, obj: Any) -> None:
    """Serialize ``obj`` to deterministic JSON and store it at ``path``."""
    backend.write_text(
        path,
        json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True, default=str),
    )


def read_json(backend: StorageBackend, path: str) -> Any:
    """Load and parse JSON stored at ``path``."""
    return json.loads(backend.read_text(path))
