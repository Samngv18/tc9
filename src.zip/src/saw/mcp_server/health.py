"""Liveness and readiness checks for the MCP server."""

from __future__ import annotations

from saw.config import Settings
from saw.frameworks import FrameworkRegistry


def liveness() -> dict[str, str]:
    """Liveness probe: the process is running."""
    return {"status": "ok"}


def readiness(
    registry: FrameworkRegistry, settings: Settings
) -> tuple[bool, dict[str, object]]:
    """Readiness probe: the framework registry is loaded and a provider is configured.

    Returns ``(ready, detail)``. Provider *reachability* is checked as
    "credentials configured" rather than a live network call, so the probe stays
    cheap and does not consume tokens.
    """
    framework_count = len(registry.snapshot().frameworks)
    providers = settings.configured_providers()
    registry_loaded = framework_count > 0
    ready = registry_loaded and len(providers) > 0
    detail: dict[str, object] = {
        "status": "ready" if ready else "not_ready",
        "registry_loaded": registry_loaded,
        "active_frameworks": framework_count,
        "providers_configured": list(providers),
    }
    return ready, detail
