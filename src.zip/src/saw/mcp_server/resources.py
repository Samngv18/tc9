"""MCP resources: the active framework registry view (admin-only)."""

from __future__ import annotations

from saw.frameworks import FrameworkRegistry

# The spec names this 'framework_registry://active'; an underscore is not a valid
# URI scheme character (RFC 3986), and FastMCP rejects it — a hyphen is used.
ACTIVE_FRAMEWORKS_URI = "framework-registry://active"


def active_frameworks_view(registry: FrameworkRegistry) -> dict[str, object]:
    """Return a JSON-safe summary of the active framework set."""
    snapshot = registry.snapshot()
    return {
        "loaded_at": snapshot.loaded_at.isoformat(),
        "count": len(snapshot.frameworks),
        "frameworks": [
            {
                "name": framework.name,
                "tier": framework.tier.value,
                "visibility": framework.visibility.value,
                "version": framework.version,
                "control_count": len(framework.extracted_controls),
            }
            for framework in snapshot.frameworks
        ],
    }
