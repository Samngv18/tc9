"""Bearer-token authentication for framework-management MCP tools.

A single shared admin token (``SAW_ADMIN_TOKEN``) in v1; the validation seam is
pluggable to JWT / Entra ID later. Auth failures surface as generic MCP errors
with no information leakage.
"""

from __future__ import annotations

import functools
import hmac
from collections.abc import Callable, Mapping

import structlog
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_headers

from saw.config import get_settings

log = structlog.get_logger(__name__)

_BEARER_PREFIX = "bearer "


class AuthError(Exception):
    """Raised internally when admin authentication fails."""


def extract_bearer_token(headers: Mapping[str, str]) -> str | None:
    """Extract the bearer token from an Authorization header (case-insensitive)."""
    for key, value in headers.items():
        if key.lower() == "authorization" and value.lower().startswith(_BEARER_PREFIX):
            return value[len(_BEARER_PREFIX) :].strip() or None
    return None


def is_valid_admin_token(token: str | None, expected: str | None) -> bool:
    """Constant-time comparison of a presented token against the configured one."""
    if not token or not expected:
        return False
    return hmac.compare_digest(token, expected)


def check_admin_access(headers: Mapping[str, str], expected_token: str | None) -> None:
    """Raise :class:`AuthError` unless the request carries a valid admin token."""
    token = extract_bearer_token(headers)
    if not is_valid_admin_token(token, expected_token):
        raise AuthError("admin authentication failed")


def require_admin(func: Callable[..., object]) -> Callable[..., object]:
    """Decorator: require a valid admin bearer token before the handler runs."""

    @functools.wraps(func)
    def wrapper(*args: object, **kwargs: object) -> object:
        headers = get_http_headers(include={"authorization"})
        try:
            check_admin_access(headers, get_settings().admin_token)
        except AuthError:
            log.warning("admin_auth_rejected")
            raise ToolError(
                "Unauthorized: a valid admin bearer token is required for this operation."
            ) from None
        return func(*args, **kwargs)

    return wrapper
