"""FastMCP server exposing the assessment workflow with selective authentication."""

from saw.mcp_server.server import create_server, main

__all__ = ["create_server", "main"]
