"""FastMCP server wiring with selective bearer-token authentication.

  run_assessment                          - open (no authentication)
  list_active_frameworks                  - admin bearer token required
  update_framework                        - admin bearer token required
  framework_registry://active  (resource) - admin bearer token required
  /healthz, /readyz                       - open (no authentication)
"""

from __future__ import annotations

import base64

import structlog
from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from starlette.requests import Request
from starlette.responses import JSONResponse

from saw.agents import InputDocument
from saw.config import Settings, configure_logging, get_settings
from saw.frameworks import init_registry
from saw.http.client import build_sync_client
from saw.llm.client import LLMClient
from saw.mcp_server.auth import require_admin
from saw.mcp_server.health import liveness, readiness
from saw.mcp_server.resources import ACTIVE_FRAMEWORKS_URI, active_frameworks_view
from saw.mcp_server.tools import AssessmentTools
from saw.schemas import SourceFormat
from saw.storage.filesystem import build_storage

log = structlog.get_logger(__name__)


def _decode_documents(items: list[dict[str, str]]) -> list[InputDocument]:
    documents: list[InputDocument] = []
    for item in items:
        filename = item.get("filename", "")
        content_b64 = item.get("content_base64", "")
        if not filename or not content_b64:
            raise ToolError("each input document requires 'filename' and 'content_base64'")
        try:
            content = base64.b64decode(content_b64, validate=True)
        except Exception:
            raise ToolError(f"invalid base64 content for '{filename}'") from None
        documents.append(InputDocument(filename=filename, content=content))
    return documents


def _build_llm_client(settings: Settings) -> LLMClient:
    if settings.configured_providers():
        return LLMClient(settings, build_sync_client(settings))
    # No providers configured: the server still starts (readiness reports not-ready);
    # run_assessment is guarded separately.
    log.warning("mcp_server_no_provider_configured")
    return LLMClient(settings, http_client=None, providers={})


def create_server(settings: Settings | None = None) -> FastMCP:
    """Build the FastMCP server: seed the registry and register tools/resources/routes."""
    settings = settings or get_settings()
    storage = build_storage(settings)
    llm_client = _build_llm_client(settings)
    registry = init_registry(storage, llm_client=llm_client)
    registry.seed_if_empty()
    tools = AssessmentTools(
        storage=storage, registry=registry, llm_client=llm_client, settings=settings
    )

    mcp: FastMCP = FastMCP("security-assessment-workflow")

    @mcp.tool
    def run_assessment(
        inputs: list[dict[str, str]], supplemental: list[dict[str, str]] | None = None
    ) -> dict[str, object]:
        """Assess a vendor security questionnaire. Open — no authentication required.

        Each input is an object with 'filename' and base64 'content_base64'.
        """
        if not settings.configured_providers():
            raise ToolError("the server has no LLM provider configured; assessment is unavailable")
        sources = _decode_documents(inputs)
        extra = _decode_documents(supplemental) if supplemental else None
        return tools.run_assessment(sources, extra)

    @mcp.tool
    @require_admin
    def list_active_frameworks() -> dict[str, object]:
        """List the active security frameworks. Requires an admin bearer token."""
        return tools.list_active_frameworks()

    @mcp.tool
    @require_admin
    def update_framework(
        framework_name: str, artifact_base64: str, format: str
    ) -> dict[str, object]:
        """Upload a new framework version (pdf or json). Requires an admin bearer token."""
        try:
            artifact = base64.b64decode(artifact_base64, validate=True)
        except Exception:
            raise ToolError("invalid base64 artifact content") from None
        try:
            source_format = SourceFormat(format)
        except ValueError:
            raise ToolError("format must be 'pdf' or 'json'") from None
        return tools.update_framework(framework_name, artifact, source_format)

    @mcp.resource(ACTIVE_FRAMEWORKS_URI)
    @require_admin
    def active_frameworks_resource() -> dict[str, object]:
        """The active framework set. Requires an admin bearer token."""
        return active_frameworks_view(registry)

    @mcp.custom_route("/healthz", methods=["GET"])
    async def healthz(request: Request) -> JSONResponse:
        return JSONResponse(liveness())

    @mcp.custom_route("/readyz", methods=["GET"])
    async def readyz(request: Request) -> JSONResponse:
        ready, detail = readiness(registry, settings)
        return JSONResponse(detail, status_code=200 if ready else 503)

    log.info("mcp_server_created", active_frameworks=len(registry.active_frameworks()))
    return mcp


def main() -> None:
    """Console entry point: run the MCP server over HTTP."""
    settings = get_settings()
    configure_logging(settings)
    create_server(settings).run(transport="http", host="0.0.0.0", port=8000)


if __name__ == "__main__":
    main()
