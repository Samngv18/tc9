"""MCP tool logic: assessment runs and framework management.

This module holds the testable tool logic. The FastMCP wiring — decoration,
base64 decoding, and authentication — lives in :mod:`saw.mcp_server.server`.
"""

from __future__ import annotations

import uuid

import structlog

from saw.agents import InputDocument
from saw.config import ProviderName, Settings
from saw.frameworks import FrameworkRegistry
from saw.graph import AssessmentWorkflow
from saw.llm.client import LLMClient
from saw.reporting import build_internal_traceability, render_report_pdf
from saw.schemas import SourceFormat
from saw.storage.interface import StorageBackend

log = structlog.get_logger(__name__)


def new_run_id() -> str:
    """Generate a fresh run identifier."""
    return f"run-{uuid.uuid4().hex[:12]}"


class AssessmentTools:
    """Backing logic for the MCP tools."""

    def __init__(
        self,
        *,
        storage: StorageBackend,
        registry: FrameworkRegistry,
        llm_client: LLMClient,
        settings: Settings,
        provider: ProviderName | None = None,
    ) -> None:
        self._storage = storage
        self._registry = registry
        self._llm = llm_client
        self._settings = settings
        self._provider = provider

    def run_assessment(
        self,
        sources: list[InputDocument],
        supplemental: list[InputDocument] | None = None,
        *,
        run_id: str | None = None,
    ) -> dict[str, object]:
        """Run the assessment workflow, render the PDF, and persist all artifacts."""
        run_id = run_id or new_run_id()
        workflow = AssessmentWorkflow(
            storage=self._storage,
            registry=self._registry,
            llm_client=self._llm,
            provider=self._provider,
        )
        final = workflow.run(run_id, sources, supplemental)
        report = final["final_report"]

        pdf_path = f"runs/{run_id}/report.pdf"
        self._storage.write_bytes(pdf_path, render_report_pdf(report))
        report_path = f"runs/{run_id}/report.json"
        self._storage.write_text(report_path, report.model_dump_json(indent=2))

        # Internal traceability is persisted internally and never shared.
        traceability = build_internal_traceability(
            run_id=run_id,
            vendor_name=report.vendor_name,
            records=final["parsed_records"],
            assessment=final["assessment_results"],
            validations=final["validations"],
        )
        self._storage.write_text(
            f"runs/{run_id}/traceability_internal.json",
            traceability.model_dump_json(indent=2),
        )

        severity_counts: dict[str, int] = {}
        for finding in final["assessment_results"].all_findings:
            key = finding.severity.value
            severity_counts[key] = severity_counts.get(key, 0) + 1
        token_summary = final.get("token_summary")
        log.info("run_assessment_completed", run_id=run_id, vendor=report.vendor_name)
        return {
            "run_id": run_id,
            "vendor_name": report.vendor_name,
            "confidence_band": report.confidence.band.value,
            "confidence_score": round(report.confidence.score, 3),
            "risk_finding_count": len(report.risk_summary),
            "severity_counts": severity_counts,
            "follow_up_count": len(report.follow_up_questions),
            "report_pdf_path": pdf_path,
            "report_json_path": report_path,
            "executive_summary": report.executive_summary,
            "token_summary": token_summary.model_dump() if token_summary else None,
        }

    def list_active_frameworks(self) -> dict[str, object]:
        """Summarize the active framework set."""
        frameworks = self._registry.active_frameworks()
        return {
            "count": len(frameworks),
            "frameworks": [
                {
                    "name": framework.name,
                    "tier": framework.tier.value,
                    "visibility": framework.visibility.value,
                    "version": framework.version,
                    "control_count": len(framework.extracted_controls),
                }
                for framework in frameworks
            ],
        }

    def update_framework(
        self, framework_name: str, artifact_bytes: bytes, fmt: SourceFormat
    ) -> dict[str, object]:
        """Commit a new framework version (the registry reloads synchronously)."""
        framework = self._registry.update_framework(framework_name, artifact_bytes, fmt)
        return {
            "framework_name": framework.name,
            "version": framework.version,
            "source_format": framework.source_format.value,
            "control_count": len(framework.extracted_controls),
            "tier": framework.tier.value,
            "visibility": framework.visibility.value,
        }
