"""Versioned, event-driven framework registry.

The active framework set is held in memory. It is reloaded only when
:meth:`FrameworkRegistry.update_framework` (the call backing the MCP
``update_framework`` tool) commits a new version, or on an explicit
:meth:`FrameworkRegistry.reload`. There is no polling thread and no file watcher.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from importlib.resources import files

import structlog
from pydantic import ValidationError

from saw.frameworks.loader import (
    FrameworkLoadError,
    extract_controls_from_pdf,
    parse_controls_from_json,
)
from saw.llm.client import LLMClient
from saw.schemas import (
    ActiveVersionPointer,
    FrameworkControl,
    FrameworkRegistrySnapshot,
    FrameworkTier,
    FrameworkVisibility,
    SecurityFramework,
    SourceFormat,
)
from saw.storage.interface import StorageBackend

log = structlog.get_logger(__name__)

_FRAMEWORKS_ROOT = "frameworks"
_NAME_PATTERN = re.compile(r"^[a-z0-9_]+$")
_CONTROLS_FILE_PATTERN = re.compile(r"^v(\d+)_[0-9a-f]+\.controls\.json$")
_HASH_PREFIX_LENGTH = 16


@dataclass(frozen=True)
class FrameworkDefinition:
    """Static identity of a known framework. Tier and visibility are intrinsic."""

    name: str
    tier: FrameworkTier
    visibility: FrameworkVisibility


# The closed catalog of known frameworks. Tier and visibility for a first upload
# (and for seeding) come from here; later updates preserve the committed values.
_CATALOG: dict[str, FrameworkDefinition] = {
    definition.name: definition
    for definition in (
        FrameworkDefinition("owasp_llm_top10", FrameworkTier.primary, FrameworkVisibility.public),
        FrameworkDefinition(
            "owasp_agentic_top10", FrameworkTier.primary, FrameworkVisibility.public
        ),
        FrameworkDefinition("mitre_atlas", FrameworkTier.primary, FrameworkVisibility.public),
        FrameworkDefinition(
            "internal_company_standards", FrameworkTier.primary, FrameworkVisibility.internal
        ),
        FrameworkDefinition("nist_ai_rmf", FrameworkTier.secondary, FrameworkVisibility.public),
        FrameworkDefinition("eu_ai_act", FrameworkTier.secondary, FrameworkVisibility.public),
        FrameworkDefinition("iso_iec_42001", FrameworkTier.secondary, FrameworkVisibility.public),
    )
}

CATALOG_FRAMEWORK_NAMES: tuple[str, ...] = tuple(_CATALOG)


def _validate_name(name: str) -> str:
    cleaned = name.strip().lower()
    if not _NAME_PATTERN.match(cleaned):
        raise FrameworkLoadError(f"invalid framework name: {name!r}")
    return cleaned


def _load_seed_bytes(name: str) -> bytes:
    resource = files("saw.frameworks").joinpath("seed", f"{name}.json")
    try:
        return resource.read_bytes()
    except (FileNotFoundError, OSError) as exc:
        raise FrameworkLoadError(f"missing bundled seed file for framework '{name}'") from exc


class FrameworkRegistry:
    """Holds the active framework set; reloads only on an explicit event."""

    def __init__(self, storage: StorageBackend, *, llm_client: LLMClient | None = None) -> None:
        self._storage = storage
        self._llm = llm_client
        self._snapshot: FrameworkRegistrySnapshot | None = None

    # --- public API ------------------------------------------------------- #

    def snapshot(self) -> FrameworkRegistrySnapshot:
        """Return the in-memory active framework set, loading it once if needed."""
        if self._snapshot is None:
            return self.reload()
        return self._snapshot

    def active_frameworks(self) -> list[SecurityFramework]:
        """Return the list of active frameworks from the current snapshot."""
        return self.snapshot().frameworks

    def reload(self) -> FrameworkRegistrySnapshot:
        """Re-read the active framework set from storage into memory."""
        frameworks: list[SecurityFramework] = []
        for name in self._storage.list_dir(_FRAMEWORKS_ROOT):
            framework = self._read_active_framework(name)
            if framework is None:
                log.warning("framework_skipped_on_reload", framework=name)
                continue
            frameworks.append(framework)
        frameworks.sort(key=lambda framework: framework.name)
        self._snapshot = FrameworkRegistrySnapshot(frameworks=frameworks)
        log.info("framework_registry_reloaded", frameworks=len(frameworks))
        return self._snapshot

    def seed_if_empty(self) -> list[str]:
        """First-startup seeding. Idempotent: seeds only frameworks with no version."""
        seeded: list[str] = []
        for name in _CATALOG:
            if self._version_numbers(name):
                continue
            self._commit_version(name, _load_seed_bytes(name), SourceFormat.json)
            seeded.append(name)
        if seeded:
            log.info("framework_registry_seeded", frameworks=seeded)
        self.reload()
        return seeded

    def update_framework(
        self, framework_name: str, artifact_bytes: bytes, fmt: SourceFormat | str
    ) -> SecurityFramework:
        """Commit a new framework version, then reload the active set synchronously.

        This is the call the MCP ``update_framework`` tool wraps. The reload is
        event-driven: it runs here, before returning. No polling, no watcher.
        """
        name = _validate_name(framework_name)
        framework = self._commit_version(name, artifact_bytes, SourceFormat(fmt))
        self.reload()
        log.info(
            "framework_updated",
            framework=name,
            version=framework.version,
            controls=len(framework.extracted_controls),
        )
        return framework

    # --- internals -------------------------------------------------------- #

    def _commit_version(
        self, name: str, data: bytes, fmt: SourceFormat
    ) -> SecurityFramework:
        tier, visibility = self._resolve_metadata(name)
        # Extract first: a failed extraction must leave nothing on disk.
        if fmt is SourceFormat.pdf:
            controls = self._extract_pdf_controls(name, data)
        else:
            controls = parse_controls_from_json(data)

        full_hash = hashlib.sha256(data).hexdigest()
        version = f"v{self._next_version_number(name)}"
        versions_dir = f"{_FRAMEWORKS_ROOT}/{name}/versions"
        stem = f"{version}_{full_hash[:_HASH_PREFIX_LENGTH]}"
        artifact_ext = "pdf" if fmt is SourceFormat.pdf else "json"

        framework = SecurityFramework(
            name=name,
            tier=tier,
            visibility=visibility,
            version=version,
            source_artifact_hash=full_hash,
            source_format=fmt,
            extracted_controls=controls,
            uploaded_at=datetime.now(UTC),
        )
        self._storage.write_bytes(f"{versions_dir}/{stem}.{artifact_ext}", data)
        self._storage.write_text(
            f"{versions_dir}/{stem}.controls.json", framework.model_dump_json(indent=2)
        )
        self._storage.write_text(
            f"{_FRAMEWORKS_ROOT}/{name}/active.json",
            ActiveVersionPointer(active_version=version).model_dump_json(indent=2),
        )
        return framework

    def _extract_pdf_controls(self, name: str, data: bytes) -> list[FrameworkControl]:
        return extract_controls_from_pdf(
            data,
            framework_name=name,
            llm_client=self._llm,
            run_id=f"framework-update:{name}",
        )

    def _resolve_metadata(self, name: str) -> tuple[FrameworkTier, FrameworkVisibility]:
        # Existing committed metadata wins, so tier/visibility persist across updates.
        existing = self._read_active_framework(name)
        if existing is not None:
            return existing.tier, existing.visibility
        definition = _CATALOG.get(name)
        if definition is None:
            raise FrameworkLoadError(
                f"unknown framework '{name}'; it is not in the framework catalog"
            )
        return definition.tier, definition.visibility

    def _version_numbers(self, name: str) -> list[int]:
        versions_dir = f"{_FRAMEWORKS_ROOT}/{name}/versions"
        if not self._storage.exists(versions_dir):
            return []
        numbers: list[int] = []
        for filename in self._storage.list_dir(versions_dir):
            match = _CONTROLS_FILE_PATTERN.match(filename)
            if match:
                numbers.append(int(match.group(1)))
        return sorted(numbers)

    def _next_version_number(self, name: str) -> int:
        numbers = self._version_numbers(name)
        return numbers[-1] + 1 if numbers else 1

    def _read_active_framework(self, name: str) -> SecurityFramework | None:
        active_path = f"{_FRAMEWORKS_ROOT}/{name}/active.json"
        if not self._storage.exists(active_path):
            return None
        try:
            pointer = ActiveVersionPointer.model_validate_json(
                self._storage.read_text(active_path)
            )
        except ValidationError as exc:
            log.warning("framework_active_pointer_invalid", framework=name, error=str(exc))
            return None

        versions_dir = f"{_FRAMEWORKS_ROOT}/{name}/versions"
        if not self._storage.exists(versions_dir):
            return None
        prefix = f"{pointer.active_version}_"
        for filename in self._storage.list_dir(versions_dir):
            if filename.startswith(prefix) and filename.endswith(".controls.json"):
                try:
                    return SecurityFramework.model_validate_json(
                        self._storage.read_text(f"{versions_dir}/{filename}")
                    )
                except ValidationError as exc:
                    log.warning("framework_controls_invalid", framework=name, error=str(exc))
                    return None
        log.warning(
            "framework_active_version_missing",
            framework=name,
            version=pointer.active_version,
        )
        return None


_GLOBAL_REGISTRY: FrameworkRegistry | None = None


def init_registry(
    storage: StorageBackend, *, llm_client: LLMClient | None = None
) -> FrameworkRegistry:
    """Create and install the process-wide registry singleton."""
    global _GLOBAL_REGISTRY
    _GLOBAL_REGISTRY = FrameworkRegistry(storage, llm_client=llm_client)
    return _GLOBAL_REGISTRY


def get_registry() -> FrameworkRegistry:
    """Return the process-wide registry singleton (initialize it first)."""
    if _GLOBAL_REGISTRY is None:
        raise RuntimeError("framework registry is not initialized; call init_registry() first")
    return _GLOBAL_REGISTRY
