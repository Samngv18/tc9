"""Self-contained, versioned framework registry with event-driven hot reload.

Frameworks are stored as a source artifact (PDF or JSON) plus an LLM-extracted
structured form. The in-process :class:`FrameworkRegistry` reloads its active set
only when a new version is committed — there is no polling thread or file watcher.
"""

from saw.frameworks.loader import FrameworkLoadError
from saw.frameworks.registry import (
    CATALOG_FRAMEWORK_NAMES,
    FrameworkDefinition,
    FrameworkRegistry,
    get_registry,
    init_registry,
)

__all__ = [
    "CATALOG_FRAMEWORK_NAMES",
    "FrameworkDefinition",
    "FrameworkLoadError",
    "FrameworkRegistry",
    "get_registry",
    "init_registry",
]
