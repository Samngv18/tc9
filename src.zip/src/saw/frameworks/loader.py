"""Framework artifact ingestion.

PDF artifacts are extracted into structured controls via the LLM; JSON artifacts
are validated against the :class:`FrameworkControl` schema and used as-is.
Ingestion failures raise :class:`FrameworkLoadError` — framework updates are an
admin operation and must fail loudly rather than commit a broken version.
"""

from __future__ import annotations

import json
from io import BytesIO

import pdfplumber
import structlog
from pydantic import ValidationError

from saw.llm.client import ChatMessage, LLMClient
from saw.llm.diagnostics import RunDiagnostics
from saw.prompts.framework_extraction import (
    framework_extraction_system_prompt,
    framework_extraction_user_prompt,
)
from saw.schemas import FrameworkControl

log = structlog.get_logger(__name__)

# PDF text beyond this length is truncated before extraction.
_MAX_PDF_CHARS = 60_000
_MAX_EXTRACTION_TOKENS = 4096


class FrameworkLoadError(RuntimeError):
    """Raised when a framework artifact cannot be ingested into structured controls."""


def _pdf_text(data: bytes) -> str:
    parts: list[str] = []
    with pdfplumber.open(BytesIO(data)) as pdf:
        for page in pdf.pages:
            parts.append(page.extract_text() or "")
    return "\n".join(parts).strip()


def _braced(text: str) -> str | None:
    start, end = text.find("{"), text.rfind("}")
    return text[start : end + 1] if 0 <= start < end else None


def _extract_json_object(content: str) -> dict[str, object] | None:
    text = content.strip()
    for candidate in (text, _braced(text)):
        if candidate is None:
            continue
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return parsed
    return None


def _coerce_controls(items: object, *, strict: bool) -> list[FrameworkControl]:
    """Validate raw items into FrameworkControls.

    ``strict`` raises on the first invalid item (JSON uploads); otherwise invalid
    items are skipped with a warning (lenient LLM-extraction output).
    """
    if not isinstance(items, list):
        raise FrameworkLoadError("expected a JSON array of controls")
    controls: list[FrameworkControl] = []
    for index, item in enumerate(items):
        try:
            controls.append(FrameworkControl.model_validate(item))
        except ValidationError as exc:
            if strict:
                raise FrameworkLoadError(
                    f"control #{index + 1} failed schema validation: {exc}"
                ) from exc
            log.warning("framework_control_skipped", index=index, error=str(exc))
    return controls


def parse_controls_from_json(data: bytes) -> list[FrameworkControl]:
    """Parse and strictly validate a JSON control upload.

    Accepts either a JSON array of controls or an object with a ``controls`` key.
    """
    try:
        parsed: object = json.loads(data.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise FrameworkLoadError(f"artifact is not valid JSON: {exc}") from exc
    if isinstance(parsed, dict) and "controls" in parsed:
        parsed = parsed["controls"]
    controls = _coerce_controls(parsed, strict=True)
    if not controls:
        raise FrameworkLoadError("JSON artifact contained no controls")
    return controls


def extract_controls_from_pdf(
    data: bytes,
    *,
    framework_name: str,
    llm_client: LLMClient | None,
    run_id: str = "-",
    diagnostics: RunDiagnostics | None = None,
) -> list[FrameworkControl]:
    """Extract structured controls from a framework PDF using the LLM."""
    if llm_client is None:
        raise FrameworkLoadError("an LLM client is required to extract controls from a PDF")
    try:
        text = _pdf_text(data)
    except Exception as exc:  # corrupt/unsupported PDF
        raise FrameworkLoadError(f"could not read the PDF artifact: {exc}") from exc
    if not text:
        raise FrameworkLoadError(
            f"no extractable text in the PDF for '{framework_name}' (it may require OCR)"
        )
    if len(text) > _MAX_PDF_CHARS:
        log.warning("framework_pdf_truncated", framework=framework_name, chars=len(text))
        text = text[:_MAX_PDF_CHARS]

    messages = [
        ChatMessage(role="system", content=framework_extraction_system_prompt()),
        ChatMessage(
            role="user", content=framework_extraction_user_prompt(framework_name, text)
        ),
    ]
    result = llm_client.complete(
        messages,
        max_tokens=_MAX_EXTRACTION_TOKENS,
        temperature=0.0,
        run_id=run_id,
        node="framework_extraction",
        diagnostics=diagnostics,
    )
    if result.is_fallback:
        raise FrameworkLoadError(
            f"control extraction failed: LLM provider unavailable ({result.last_error})"
        )
    payload = _extract_json_object(result.content)
    if payload is None:
        raise FrameworkLoadError("the LLM did not return a parseable JSON object of controls")
    controls = _coerce_controls(payload.get("controls", []), strict=False)
    if not controls:
        raise FrameworkLoadError(
            f"no valid controls could be extracted from the PDF for '{framework_name}'"
        )
    return controls
