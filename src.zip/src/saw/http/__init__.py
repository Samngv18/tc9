"""HTTP client factory: OS trust store integration plus explicitly injected httpx clients."""
