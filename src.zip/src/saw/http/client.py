"""httpx client factory.

The OS trust store is injected via ``truststore`` so corporate TLS interception
works without bundling a custom CA file. Every client is built here with explicit
timeouts and connection pooling, then injected into the SDK clients that need it.
"""

from __future__ import annotations

import threading

import httpx
import structlog

from saw.config import Settings

log = structlog.get_logger(__name__)

_truststore_lock = threading.Lock()
_truststore_installed = False


def install_truststore() -> None:
    """Inject the OS trust store into the stdlib ``ssl`` module. Idempotent."""
    global _truststore_installed
    with _truststore_lock:
        if _truststore_installed:
            return
        import truststore

        truststore.inject_into_ssl()
        _truststore_installed = True
        log.info("truststore_installed")


def _timeout(settings: Settings) -> httpx.Timeout:
    return httpx.Timeout(
        connect=settings.http_connect_timeout,
        read=settings.http_read_timeout,
        write=settings.http_write_timeout,
        pool=settings.http_pool_timeout,
    )


def _limits(settings: Settings) -> httpx.Limits:
    return httpx.Limits(
        max_connections=settings.http_max_connections,
        max_keepalive_connections=settings.http_max_keepalive_connections,
    )


def build_sync_client(settings: Settings) -> httpx.Client:
    """Build a synchronous httpx client with trust store, timeouts, and pooling."""
    install_truststore()
    return httpx.Client(timeout=_timeout(settings), limits=_limits(settings))


def build_async_client(settings: Settings) -> httpx.AsyncClient:
    """Build an asynchronous httpx client with trust store, timeouts, and pooling."""
    install_truststore()
    return httpx.AsyncClient(timeout=_timeout(settings), limits=_limits(settings))
